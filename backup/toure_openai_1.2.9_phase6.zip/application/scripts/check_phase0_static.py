#!/usr/bin/env python3
"""Offline/static Phase 0 preflight. Does not claim runtime/security acceptance."""
from __future__ import annotations
import compileall
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DJANGO = ROOT / "backend" / "django_core"
FRONTEND = ROOT / "frontend"
required_tests = [
    DJANGO / "tests" / "test_phase0_hardening.py",
    DJANGO / "tests" / "test_phase0_security_hardening.py",
    DJANGO / "tests" / "test_phase0_additional_controls.py",
]
checks = []
def add(name, ok, detail):
    checks.append({"name": name, "status": "PASS" if ok else "FAIL", "detail": detail})

py_dirs = [ROOT / "backend"]
compile_ok = all(compileall.compile_dir(str(p), quiet=1, force=False) for p in py_dirs)
add("Python syntax compilation", compile_ok, "compileall over backend Python sources")
missing = [str(p.relative_to(ROOT)) for p in required_tests if not p.is_file()]
add("Phase 0 focused test files", not missing, "present" if not missing else "missing: " + ", ".join(missing))
package_file = FRONTEND / "package.json"
try:
    package = json.loads(package_file.read_text(encoding="utf-8"))
    scripts = package.get("scripts", {})
    has_build = bool(scripts.get("build"))
    has_typecheck = bool(scripts.get("lint"))
    has_test = bool(scripts.get("test"))
    add("Frontend build/typecheck/test scripts", has_build and has_typecheck and has_test,
        "build=" + str(scripts.get("build")) + "; lint=" + str(scripts.get("lint")) + "; test=" + str(scripts.get("test")))
except Exception as exc:
    add("Frontend build/typecheck scripts", False, f"package.json parse error: {exc}")
print(json.dumps({"check_type": "static_preflight_only", "checks": checks}, indent=2, ensure_ascii=False))
sys.exit(1 if any(c["status"] == "FAIL" for c in checks) else 0)
