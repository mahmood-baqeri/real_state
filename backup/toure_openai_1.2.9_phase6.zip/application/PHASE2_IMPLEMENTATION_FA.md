# بنیان ملک — Phase 2 Daily Work Hub

## Scope implemented
- Operational daily-work API: `GET /api/v1/reports/daily-work`
- Today and overdue open follow-up tasks (bounded to 100), with assignment visibility.
- Hot/priority customers (readiness `HOT` or lead score >= 80), using the existing customer visibility service.
- Properties created within the last seven days, using the existing agency/branch/property-visibility service.
- Today's non-cancelled/non-rejected viewing appointments, using existing appointment visibility rules.
- Next-action heuristics for overdue tasks, hot customers without an open task in the returned task window, and today's viewings.
- Dashboard page `/dashboard/work-hub`, responsive summary tiles, section lists, empty/loading/error states, manual refresh.
- Link from the main dashboard header to Daily Work Hub.
- Optional API filters `branch_id` and `agent_membership_id`. Unauthorized role filters are ignored; the underlying querysets remain agency and role scoped.

## Security and privacy approach
- The endpoint requires agency context (`require_agency_context`).
- Tasks are scoped to assigned membership by default; branch managers receive branch-scoped tasks; users with the existing customer-view-all permission receive agency scope.
- Customers are fetched through `list_customers`, preserving current assigned/share/branch visibility and share expiry rules.
- Properties are fetched through `list_agency_properties`, preserving existing property view scope and branch restrictions.
- Viewings are fetched through `list_appointments`, preserving existing appointment visibility rules.
- Query filters only narrow scoped querysets; they do not independently grant access.
- Output is capped (tasks 100, hot customers 50, new properties 50, today's appointments 100).
- This phase adds no database schema and therefore no new migration is required.

## Files changed
- `backend/django_core/apps/reports/daily_work.py` (new aggregation service)
- `backend/fastapi_core/app/api/v1/reports_audit.py` (new API endpoint)
- `frontend/src/app/dashboard/work-hub/page.tsx` (new UI route)
- `frontend/src/app/dashboard/page.tsx` (navigation link)

## Validation performed
- Backend `compileall`: passed (syntax only).
- TypeScript parser diagnostics for both changed TSX pages: 0 syntax diagnostics.
- Existing frontend unit suite: 12/12 passed (these are existing general tests, not new endpoint integration tests).
- ZIP archive integrity checked after packaging.

## Not run / release cautions
- Django service/ORM tests and API integration tests were not executed in this environment; Django runtime/database dependencies are not available here.
- Full TypeScript typecheck, Next build, and browser/role tests were not run because frontend dependencies are not installed in this environment.
- Role/branch isolation requires runtime integration testing with at least two agencies and multiple branches before release.
- “Hot customer” is currently an explicit rule (HOT readiness or score >= 80), not an ML score. “Next action” is a rule-based suggestion, not an autonomous action.
