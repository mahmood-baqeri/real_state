# BonyanMelk Phase 4 — Matching & Property Quality

Base: 1.2.6 (Phase 3 Syntax Fix)

## Implemented

- Customer-to-property matching now uses the active CustomerRequirement when a customer is selected in CRM.
- Fixed `DealType.id` / `PropertyType.id` lookup to use their actual primary keys (`pk`); these models use `code` as primary key.
- Matching includes sale/rent-aware price selection, area, bedroom, city, district preferences, property/deal type and amenities.
- Match score is deterministic, capped at 100, and returns reasons and mismatches.
- Strict results are attempted first. If no results remain, matching returns ranked alternatives while preserving agency/public visibility scope and type filters; city, area and budget are relaxed for the fallback pass.
- Matching normalizes currencies into the customer's selected currency using active ExchangeRate rows updated within the last 30 days; direct, inverse and chained rate paths are supported. If a conversion path is unavailable, the score reports a currency conversion mismatch instead of comparing unrelated currency amounts.
- Persian text search normalizes Arabic/Persian characters, diacritics, punctuation and ZWNJ/ZWJ spacing; common property terms expand to synonym variants.
- Property Quality Score includes completeness, location, size, price, amenities, public cover/photography, verification and price validity; possible duplicate checks are scoped to the caller-visible property set.
- Price-alert dashboard shows recent price-history records and prices expiring/expired within the requested window.
- Market Opportunity Radar uses only published public-portal listings and requires at least five comparables; it flags price-per-square-metre values at least 15% below the comparable group average.
- Sale and rental price changes are recorded separately in the existing history model. Saved-search notifications are best-effort, only for published public-portal properties, and require an active agency membership.
- New frontend route: `/dashboard/property-intelligence` (linked from Properties page). CRM Matching tab now supports selecting an existing customer requirement or manual filters.

## API additions

- `GET /api/v1/matching/property-quality`
- `GET /api/v1/matching/price-alerts?days=30`
- `GET /api/v1/matching/search?q=...&limit=20`
- `GET /api/v1/matching/market-opportunities?city=...&currency_code=IRT`

## Important constraints / not claimed as complete

- Matching considers at most 500 candidate properties per pass; a true load/performance test on tens of thousands of properties has not been run.
- Market opportunity radar is a transparent heuristic, not a property appraisal or guaranteed investment opportunity; it uses one city and currency per request.
- Currency conversion requires an active exchange-rate path with `effective_at` in the last 30 days. No external rates are fetched automatically.
- Price expiration is surfaced in the dashboard; automatic timed expiration reminder jobs are not configured here.
- Possible duplicate detection is a heuristic (postal code or close coordinates plus similar area), not a confirmed merge/deduplication workflow.
- The Phase 4 backend Django tests and full Next.js build have not run because Django dependencies and a complete frontend install are unavailable in this environment.
- No database schema migrations were added.
