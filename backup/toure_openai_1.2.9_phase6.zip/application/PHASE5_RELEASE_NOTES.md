# BonyanMelk Phase 5 — Support, Feedback, Push & AI Hardening

Base: 1.2.7 (Phase 4 Matching & Property Quality)
Release: 1.2.8

## Phase 5 scope
- Ticketing and support conversations, including status history, assignment, internal notes, SLA, ratings and canned replies.
- Confidential complaints with public submission and phone-verified tracking.
- Public/agency surveys and response analytics.
- Push notification endpoints and per-user preferences.
- Tenant-scoped AI assistant tools, draft-only SEO output and portfolio insights.

## Hardening included in 1.2.8
- Fixed ticket detail lookup: QuerySet `.first()` is now invoked, preventing ticket detail retrieval from returning a method instead of a record.
- Ticket numbers use a short random suffix rather than count-based numbering, reducing collisions under concurrent ticket creation.
- Ticket request schema validates scope, category, priority and status against supported enum values.
- Ticket attachment metadata is bounded (filename/URL/MIME lengths and 25 MiB per attachment metadata size).
- Regression test now retrieves a newly created ticket and rejects an invalid status.

## Validation limitations
- Python syntax compilation is run for the source tree.
- Full backend tests require the project's Django dependencies and configured test database; these were not available in the current environment.
- Frontend production build is not claimed unless dependency installation and build succeed.
