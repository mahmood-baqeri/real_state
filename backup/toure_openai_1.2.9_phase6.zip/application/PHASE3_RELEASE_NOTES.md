# BonyanMelk 1.2.4 — Phase 3 Sales Intelligence

## Added
- CRM sales-intelligence endpoint: `GET /api/v1/crm/intelligence`
- Rule-based, explainable customer scoring (0–100) and readiness bands.
- Next-best-action recommendations based on visible interaction recency, open/overdue tasks, active requirements, and negotiations.
- Suggested follow-up creation endpoint: `POST /api/v1/crm/intelligence/follow-up` (creates a normal CRM task; does not send messages automatically).
- Heuristic conversion-probability estimate, clearly labeled as non-trained/non-calibrated.
- Inactive-customer list (30+ days since visible interaction or creation, and no open task or active negotiation).
- Aggregated outcome reasons from unsuccessful/closed negotiations where the reason was recorded.
- CRM Sales Intelligence tab showing score factors, recommended next action, inactivity, follow-up overdue counts, and lost-reason summary.
- Fixed CRM task completion frontend status to send `COMPLETED` rather than `DONE`.
- Added unit test cases for scoring rules.

## Notes / limitations
- The probability value is a transparent rule-based estimate, not a statistically trained or calibrated prediction.
- Loss reasons remain based on the existing free-text `outcome_reason`; no controlled taxonomy has been imposed on historical data.
- Suggested follow-up creates a CRM task only after the user clicks the action; no automatic customer message is sent.
- No schema changes or migrations were introduced.
- Runtime Django tests and Next.js build were not executed in this environment (Django dependencies unavailable and `npm ci` timed out).
