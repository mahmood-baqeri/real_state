# Phase 6 – Deal Room (v1.2.9)

## UI smoke test
1. Run backend and frontend using the existing project startup instructions.
2. Log in as a user with an active agency and property-edit permission.
3. Open Dashboard → معاملات (`/dashboard/deals`). Create a deal linked to an existing contract if there is no test deal.
4. Click the deal code to open `/dashboard/deals/<deal-id>`.
5. Under **اتاق معامله — چک‌لیست و تقویم**, check a checklist item. Confirm it remains checked after refresh.
6. Add a calendar event (title + date + optional note). Confirm it appears in date order and persists after refresh.
7. Delete that event. Confirm it disappears after refresh.
8. Log in as a member without property-edit permission; attempt to update the room and confirm API rejects the update.

## API smoke test
- GET `/api/v1/deals/{deal_id}` — response includes `deal_room.checklist` and `deal_room.events`.
- PUT `/api/v1/deals/{deal_id}/room` with agency header and auth token:
  `{ "checklist": [{"id":"docs","title":"Document review","done":true}], "events": [{"id":"ev1","title":"Notary appointment","date":"2026-12-01","note":"Bring original documents"}] }`
- GET the deal again; both values should be persisted in the linked contract's `obligations_json.deal_room`.

## Validation performed during packaging
- Python syntax compilation for modified FastAPI route and Django contracts service.
- ZIP integrity check.
- Frontend typecheck/build not run: dependencies (`node_modules`) are not installed in this environment.
