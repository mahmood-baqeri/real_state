from datetime import timedelta
from typing import Optional
from datetime import datetime
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from django.utils import timezone
from app.core.django_bridge import run_django
from app.dependencies.auth import RequestContext, require_agency_context
from app.schemas.common import ok

router = APIRouter(prefix="/phase9", tags=["Phase 9 — Collaboration, Trust & After-Deal"])

class CaseCreate(BaseModel):
    customer_id: UUID
    contract_id: Optional[UUID] = None
    title: str = Field(min_length=2, max_length=180)
    description: str = ""
    category: str = "GENERAL"
    priority: str = "MEDIUM"
    due_at: Optional[datetime] = None
    assigned_membership_id: Optional[UUID] = None

class CasePatch(BaseModel):
    title: Optional[str] = Field(default=None, min_length=2, max_length=180)
    description: Optional[str] = None
    category: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[str] = None
    due_at: Optional[datetime] = None
    assigned_membership_id: Optional[UUID] = None
    update_note: str = ""


def _case_data(c):
    return {"id": str(c.id), "customer_id": str(c.customer_id), "customer_name": c.customer.full_name,
        "contract_id": str(c.contract_id) if c.contract_id else None, "title": c.title,
        "description": c.description, "category": c.category, "status": c.status,
        "priority": c.priority, "due_at": c.due_at.isoformat() if c.due_at else None,
        "assigned_membership_id": str(c.assigned_membership_id) if c.assigned_membership_id else None,
        "resolved_at": c.resolved_at.isoformat() if c.resolved_at else None,
        "updates": [{"id": str(u.id), "body": u.body, "status_from": u.status_from,
                     "status_to": u.status_to, "created_at": u.created_at.isoformat()} for u in c.updates.all()],
        "created_at": c.created_at.isoformat()}

@router.get("/after-deal/cases")
async def list_after_deal_cases(status: Optional[str] = None, page: int = Query(1, ge=1),
                                page_size: int = Query(20, ge=1, le=100),
                                ctx: RequestContext = Depends(require_agency_context)):
    def op():
        from apps.phase9.models import AfterDealCase
        qs = AfterDealCase.objects.filter(agency_id=ctx.agency_id).select_related("customer").prefetch_related("updates")
        if status: qs = qs.filter(status=status)
        total = qs.count(); rows = qs[(page-1)*page_size:page*page_size]
        return {"items": [_case_data(x) for x in rows], "meta": {"page":page,"page_size":page_size,"total":total}}
    result = await run_django(op, agency_id=ctx.agency_id, user_id=ctx.user.id)
    return ok(result["items"], meta=result["meta"])

@router.post("/after-deal/cases", status_code=201)
async def create_after_deal_case(body: CaseCreate, ctx: RequestContext = Depends(require_agency_context)):
    def op():
        from apps.phase9.models import AfterDealCase, AfterDealUpdate
        from apps.customers.models import Customer
        from apps.accounts.models import AgencyMembership
        customer = Customer.objects.filter(id=body.customer_id, agency_id=ctx.agency_id, is_deleted=False).first()
        if not customer: raise HTTPException(404, "مشتری در آژانس فعال یافت نشد.")
        membership = None
        if body.assigned_membership_id:
            membership = AgencyMembership.objects.filter(id=body.assigned_membership_id, agency_id=ctx.agency_id, status=AgencyMembership.Status.ACTIVE).first()
            if not membership: raise HTTPException(400, "عضو انتخاب‌شده معتبر نیست.")
        if body.priority not in AfterDealCase.Priority.values: raise HTTPException(400, "اولویت نامعتبر است.")
        c = AfterDealCase.objects.create(agency_id=ctx.agency_id, customer=customer, contract_id=body.contract_id,
            title=body.title, description=body.description, category=body.category, priority=body.priority,
            due_at=body.due_at, assigned_membership=membership, created_by=ctx.user)
        AfterDealUpdate.objects.create(case=c, body="پرونده خدمات پس از معامله ایجاد شد.", created_by=ctx.user)
        return _case_data(c)
    return ok(await run_django(op, agency_id=ctx.agency_id, user_id=ctx.user.id))

@router.patch("/after-deal/cases/{case_id}")
async def update_after_deal_case(case_id: UUID, body: CasePatch, ctx: RequestContext = Depends(require_agency_context)):
    def op():
        from apps.phase9.models import AfterDealCase, AfterDealUpdate
        from apps.accounts.models import AgencyMembership
        c = AfterDealCase.objects.filter(id=case_id, agency_id=ctx.agency_id).select_related("customer").first()
        if not c: raise HTTPException(404, "پرونده خدمات یافت نشد.")
        data = body.model_dump(exclude_unset=True); note = data.pop("update_note", "")
        if "status" in data and data["status"] not in AfterDealCase.Status.values: raise HTTPException(400, "وضعیت نامعتبر است.")
        if "priority" in data and data["priority"] not in AfterDealCase.Priority.values: raise HTTPException(400, "اولویت نامعتبر است.")
        if "assigned_membership_id" in data:
            mid = data.pop("assigned_membership_id")
            m = AgencyMembership.objects.filter(id=mid, agency_id=ctx.agency_id, status=AgencyMembership.Status.ACTIVE).first() if mid else None
            if mid and not m: raise HTTPException(400, "عضو انتخاب‌شده معتبر نیست.")
            c.assigned_membership = m
        old_status = c.status
        for k,v in data.items(): setattr(c,k,v)
        if c.status == AfterDealCase.Status.RESOLVED and not c.resolved_at: c.resolved_at = timezone.now()
        if c.status != AfterDealCase.Status.RESOLVED: c.resolved_at = None
        c.updated_by = ctx.user; c.save()
        if note or old_status != c.status:
            AfterDealUpdate.objects.create(case=c, body=note or "وضعیت پرونده تغییر کرد.", status_from=old_status, status_to=c.status, created_by=ctx.user)
        return _case_data(c)
    return ok(await run_django(op, agency_id=ctx.agency_id, user_id=ctx.user.id))

@router.get("/trust-score")
async def agency_trust_score(ctx: RequestContext = Depends(require_agency_context)):
    def op():
        from apps.agencies.models import Agency, AgencyCooperation
        from apps.phase9.models import AfterDealCase
        from django.db.models import Count, Q
        agency = Agency.objects.get(id=ctx.agency_id)
        cases = AfterDealCase.objects.filter(agency_id=ctx.agency_id)
        total = cases.count(); resolved = cases.filter(status="RESOLVED").count()
        overdue = cases.filter(due_at__lt=timezone.now()).exclude(status__in=["RESOLVED","CANCELLED"]).count()
        active_partners = AgencyCooperation.objects.filter(Q(requester_agency_id=ctx.agency_id)|Q(provider_agency_id=ctx.agency_id), status="ACTIVE").count()
        resolution = round((resolved/total)*100) if total else 0
        overdue_rate = round((overdue/total)*100) if total else 0
        score = max(0, min(100, (65 if agency.status in ["ACTIVE","APPROVED"] else 25) + round(resolution*.25) - round(overdue_rate*.2) + min(active_partners*2,10)))
        return {"agency_id":str(agency.id),"score":score,"label":"شاخص داخلی عملکرد" if total else "امتیاز اولیه",
            "methodology":"شاخص داخلی و غیرعمومی؛ بر پایه وضعیت آژانس، پیگیری خدمات پس از معامله و همکاری‌های فعال. با نبود داده، امتیاز اولیه است.",
            "metrics":{"after_deal_cases":total,"resolved_cases":resolved,"overdue_cases":overdue,"active_partners":active_partners}}
    return ok(await run_django(op, agency_id=ctx.agency_id, user_id=ctx.user.id))

@router.get("/market/summary")
async def phase9_market_summary(city: str = "تهران", ctx: RequestContext = Depends(require_agency_context)):
    def op():
        from apps.properties.models import Property
        from django.db.models import Avg, Count, Min, Max
        qs = Property.objects.filter(agency_id=ctx.agency_id, is_deleted=False, status=Property.Status.PUBLISHED, location__city=city)
        agg = qs.aggregate(count=Count("id"), avg_price=Avg("total_price"), min_price=Min("total_price"), max_price=Max("total_price"), avg_area=Avg("built_area_sqm"))
        return {"city":city,"currency":"IRT","inventory_count":agg["count"] or 0,
            "average_price":str(agg["avg_price"]) if agg["avg_price"] is not None else None,
            "minimum_price":str(agg["min_price"]) if agg["min_price"] is not None else None,
            "maximum_price":str(agg["max_price"]) if agg["max_price"] is not None else None,
            "average_area_sqm":str(agg["avg_area"]) if agg["avg_area"] is not None else None,
            "scope":"آگهی‌های منتشرشده همین آژانس؛ نه کل بازار شهر"}
    return ok(await run_django(op, agency_id=ctx.agency_id, user_id=ctx.user.id))
