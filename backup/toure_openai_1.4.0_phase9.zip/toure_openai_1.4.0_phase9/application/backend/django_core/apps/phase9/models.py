from django.conf import settings
from django.db import models
from common.models import BaseModel

class AfterDealCase(BaseModel):
    class Status(models.TextChoices):
        OPEN = "OPEN", "باز"
        IN_PROGRESS = "IN_PROGRESS", "در حال پیگیری"
        WAITING = "WAITING", "در انتظار پاسخ"
        RESOLVED = "RESOLVED", "حل‌شده"
        CANCELLED = "CANCELLED", "لغوشده"
    class Priority(models.TextChoices):
        LOW = "LOW", "عادی"
        MEDIUM = "MEDIUM", "متوسط"
        HIGH = "HIGH", "زیاد"
        URGENT = "URGENT", "فوری"
    agency = models.ForeignKey("agencies.Agency", on_delete=models.CASCADE, related_name="after_deal_cases")
    customer = models.ForeignKey("customers.Customer", on_delete=models.PROTECT, related_name="after_deal_cases")
    contract_id = models.UUIDField(null=True, blank=True, db_index=True)
    title = models.CharField(max_length=180)
    description = models.TextField(blank=True, default="")
    category = models.CharField(max_length=40, default="GENERAL")
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.OPEN, db_index=True)
    priority = models.CharField(max_length=12, choices=Priority.choices, default=Priority.MEDIUM)
    due_at = models.DateTimeField(null=True, blank=True, db_index=True)
    assigned_membership = models.ForeignKey("accounts.AgencyMembership", null=True, blank=True, on_delete=models.SET_NULL)
    resolved_at = models.DateTimeField(null=True, blank=True)
    class Meta:
        db_table = "phase9_after_deal_case"
        ordering = ["-created_at"]

class AfterDealUpdate(BaseModel):
    case = models.ForeignKey(AfterDealCase, on_delete=models.CASCADE, related_name="updates")
    body = models.TextField()
    status_from = models.CharField(max_length=20, blank=True, default="")
    status_to = models.CharField(max_length=20, blank=True, default="")
    class Meta:
        db_table = "phase9_after_deal_update"
        ordering = ["-created_at"]
