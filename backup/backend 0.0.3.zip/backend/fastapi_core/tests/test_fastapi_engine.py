import os
import sys
from decimal import Decimal
from pathlib import Path
import pytest
from fastapi.testclient import TestClient

ROOT_DIR = Path(__file__).resolve().parent.parent.parent
BACKEND_DIR = ROOT_DIR / "backend"
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

os.environ.setdefault("USE_LOCAL_SANDBOX_DB", "1")
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.development")

from app.main import app  # noqa: E402
from app.services.matching_service import score_property_for_requirement  # noqa: E402


@pytest.fixture(scope="module", autouse=True)
def bootstrap_db():
    from django.core.management import call_command

    call_command("migrate", verbosity=0)
    call_command("bootstrap_platform", verbosity=0)


def _login(client: TestClient, phone: str, password: str) -> dict:
    res = client.post("/api/v1/auth/login", json={"phone_number": phone, "password": password})
    assert res.status_code == 200, res.text
    return res.json()["data"]


def test_matching_scorer_deterministic():
    prop = {
        "id": "11111111-1111-1111-1111-111111111111",
        "property_code": "PN-1001",
        "title": "Sample Penthouse",
        "deal_type_id": "SALE",
        "property_type_id": "APARTMENT",
        "city": "تهران",
        "district": "زعفرانیه",
        "total_price": Decimal("38000000000"),
        "built_area_sqm": Decimal("185"),
        "bedrooms": 3,
    }
    req = {
        "deal_type_id": "SALE",
        "property_type_id": "APARTMENT",
        "target_city": "تهران",
        "target_districts": ["زعفرانیه"],
        "min_budget": Decimal("20000000000"),
        "max_budget": Decimal("40000000000"),
        "min_area_sqm": Decimal("150"),
        "max_area_sqm": Decimal("220"),
        "min_bedrooms": 3,
    }
    result = score_property_for_requirement(prop, req)
    assert result["match_score"] == 100


def test_fastapi_health():
    client = TestClient(app)
    res = client.get("/api/v1/health")
    assert res.status_code == 200
    assert res.json()["data"]["service"] == "fastapi-django-orm"


def test_auth_login_refresh_and_profile():
    client = TestClient(app)
    auth_data = _login(client, "09121111111", "Manager@12345")
    access = auth_data["access"]
    refresh = auth_data["refresh"]
    assert auth_data["user"]["full_name"]

    me_res = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {access}"})
    assert me_res.status_code == 200
    assert me_res.json()["data"]["phone_number"] == "09121111111"

    ref_res = client.post("/api/v1/auth/refresh", json={"refresh": refresh})
    assert ref_res.status_code == 200
    assert ref_res.json()["data"]["access"] != ""


def test_tenant_isolation_and_rbac_enforcement():
    client = TestClient(app)
    manager_a = _login(client, "09121111111", "Manager@12345")
    agency_a_id = manager_a["user"]["memberships"][0]["agency_id"]

    # Manager A tries to query Agency B via X-Agency-ID -> fallback/rejected from seeing Agency B items
    from apps.agencies.models import Agency

    agency_b = Agency.objects.filter(slug="arya-home").first()
    assert agency_b is not None
    assert str(agency_b.id) != agency_a_id

    # Manager A sending X-Agency-ID for Agency B falls back to A (cannot see Agency B properties)
    b_props = client.get(
        "/api/v1/properties",
        headers={"Authorization": f"Bearer {manager_a['access']}", "X-Agency-ID": str(agency_b.id)},
    )
    assert b_props.status_code == 200
    for item in b_props.json()["data"]:
        assert item["agency_id"] == agency_a_id

    # Customer cannot access accounting
    customer = _login(client, "09124444444", "Customer@12345")
    acc_res = client.get(
        "/api/v1/accounting/coa",
        headers={"Authorization": f"Bearer {customer['access']}"},
    )
    assert acc_res.status_code == 403

    # Agent cannot access admin users or create commission policies
    agent = _login(client, "09122222222", "Agent@12345")
    admin_res = client.get(
        "/api/v1/admin/users",
        headers={"Authorization": f"Bearer {agent['access']}"},
    )
    assert admin_res.status_code == 403

    pol_res = client.post(
        "/api/v1/commissions/policies",
        headers={"Authorization": f"Bearer {agent['access']}", "X-Agency-ID": agency_a_id},
        json={"name": "Unauthorized Policy", "deal_type_id": "SALE"},
    )
    assert pol_res.status_code == 403


def test_subscriptions_and_payroll_endpoints():
    client = TestClient(app)
    manager = _login(client, "09121111111", "Manager@12345")
    headers = {
        "Authorization": f"Bearer {manager['access']}",
        "X-Agency-ID": manager["user"]["memberships"][0]["agency_id"],
    }
    plans_res = client.get("/api/v1/subscriptions/plans")
    assert plans_res.status_code == 200
    assert len(plans_res.json()["data"]) >= 1

    checkout_res = client.post(
        "/api/v1/subscriptions/checkout",
        headers=headers,
        json={"plan_code": "PRO", "billing_cycle": "MONTHLY", "provider_key": "sandbox"},
    )
    assert checkout_res.status_code == 201, checkout_res.text
    authority = checkout_res.json()["data"]["authority"]
    verify_res = client.post(
        "/api/v1/subscriptions/verify",
        headers=headers,
        json={"authority": authority},
    )
    assert verify_res.status_code == 200
    assert verify_res.json()["data"]["status"] == "PAID"

    payroll_res = client.get("/api/v1/payroll/cycles", headers=headers)
    assert payroll_res.status_code == 200
    assert len(payroll_res.json()["data"]) >= 1


def test_public_search_address_masking_and_matching():
    client = TestClient(app)
    res = client.get("/api/v1/search/properties?city=تهران")
    assert res.status_code == 200
    body = res.json()
    assert body["success"] is True
    assert len(body["data"]) >= 1
    first = body["data"][0]
    assert "full_address" not in first
    assert "owners" not in first

    prop_id = first["id"]
    det = client.get(f"/api/v1/properties/{prop_id}")
    assert det.status_code == 200
    det_data = det.json()["data"]
    assert "owners" not in det_data
    assert "full_address" not in (det_data.get("location") or {})

    match_res = client.get("/api/v1/matching/customer-to-properties?target_city=تهران")
    assert match_res.status_code == 200
    assert isinstance(match_res.json()["data"], list)

    trends_res = client.get("/api/v1/matching/analytics/price-trends?city=تهران")
    assert trends_res.status_code == 200
    assert isinstance(trends_res.json()["data"], list)


def test_double_entry_accounting_and_lead_conversion():
    client = TestClient(app)
    manager = _login(client, "09121111111", "Manager@12345")
    headers = {
        "Authorization": f"Bearer {manager['access']}",
        "X-Agency-ID": manager["user"]["memberships"][0]["agency_id"],
    }

    coa_res = client.get("/api/v1/accounting/coa", headers=headers)
    assert coa_res.status_code == 200
    coa = coa_res.json()["data"]
    assert len(coa) >= 2

    # Unbalanced journal entry fails with 400
    bad_je = client.post(
        "/api/v1/accounting/journal-entries",
        headers=headers,
        json={
            "entry_number": "JE-BAD-999",
            "description": "Unbalanced test",
            "lines": [
                {"account_id": coa[0]["id"], "description": "Debit", "debit": "500000", "credit": "0"},
                {"account_id": coa[1]["id"], "description": "Credit", "debit": "0", "credit": "300000"},
            ],
        },
    )
    assert bad_je.status_code == 400

    # Balanced journal entry succeeds
    import uuid

    entry_num = f"JE-FA-{uuid.uuid4().hex[:8]}"
    good_je = client.post(
        "/api/v1/accounting/journal-entries",
        headers=headers,
        json={
            "entry_number": entry_num,
            "description": "Balanced test from FastAPI",
            "lines": [
                {"account_id": coa[0]["id"], "description": "Debit", "debit": "500000", "credit": "0"},
                {"account_id": coa[1]["id"], "description": "Credit", "debit": "0", "credit": "500000"},
            ],
        },
    )
    assert good_je.status_code == 201, good_je.text
    je_id = good_je.json()["data"]["id"]

    # Reverse succeeds
    rev_res = client.post(f"/api/v1/accounting/journal-entries/{je_id}/reverse", headers=headers)
    assert rev_res.status_code == 200

    # Create & convert lead
    test_phone = f"0919{uuid.uuid4().int % 10000000:07d}"
    lead_res = client.post(
        "/api/v1/leads",
        headers=headers,
        json={"full_name": "سهراب سپهری", "phone_number": test_phone, "request_type": "BUY"},
    )
    assert lead_res.status_code == 201
    lead_id = lead_res.json()["data"]["id"]
    conv_res = client.post(f"/api/v1/leads/{lead_id}/convert", headers=headers)
    assert conv_res.status_code == 200
    assert conv_res.json()["data"]["customer_id"]
