#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DJANGO_DIR="$ROOT_DIR/backend/django_core"
FASTAPI_DIR="$ROOT_DIR/backend/fastapi"

if [ -f "$ROOT_DIR/.env" ]; then
  set -a
  # shellcheck disable=SC1091
  source "$ROOT_DIR/.env"
  set +a
fi

if [ -x "$ROOT_DIR/.venv/bin/python" ]; then
  PY_BIN="$ROOT_DIR/.venv/bin/python"
elif [ -x "/opt/pyvenv/bin/python" ]; then
  PY_BIN="/opt/pyvenv/bin/python"
else
  PY_BIN="$(command -v python3)"
fi

export DJANGO_SETTINGS_MODULE="${DJANGO_SETTINGS_MODULE:-config.settings.development}"
export BACKEND_DIR="$DJANGO_DIR"
export INTERNAL_FASTAPI_URL="http://127.0.0.1:8020"
export DATABASE_URL="${DATABASE_URL:-postgresql://realestate_user:realestate_pass@127.0.0.1:5432/realestate_db}"

if "$PY_BIN" - <<'PYEOF' >/dev/null 2>&1
import os, psycopg2
conn = psycopg2.connect(os.environ["DATABASE_URL"], connect_timeout=2)
conn.close()
PYEOF
then
  unset USE_LOCAL_SANDBOX_DB || true
  export FORCE_POSTGRESQL=1
else
  export USE_LOCAL_SANDBOX_DB=1
fi

(cd "$DJANGO_DIR" && "$PY_BIN" manage.py migrate --noinput && "$PY_BIN" manage.py seed_all --quiet)

pkill -f "uvicorn .* --host 127.0.0.1 --port 8020" >/dev/null 2>&1 || true

(cd "$FASTAPI_DIR" && exec "$PY_BIN" -m uvicorn main:app --host 127.0.0.1 --port 8020) &
FASTAPI_PID=$!

cleanup() {
  kill "$FASTAPI_PID" >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM

for _ in $(seq 1 20); do
  if curl -fsS "http://127.0.0.1:8020/api/v1/health" >/dev/null 2>&1; then
    break
  fi
  sleep 0.5
done

exec npm --prefix "$ROOT_DIR/frontend" run start
