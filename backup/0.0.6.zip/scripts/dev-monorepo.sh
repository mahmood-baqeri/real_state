#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DJANGO_DIR="$ROOT_DIR/backend/django_core"
FASTAPI_DIR="$ROOT_DIR/backend/fastapi"

# Load root .env if present (gives PostgreSQL DATABASE_URL priority)
if [ -f "$ROOT_DIR/.env" ]; then
  set -a
  # shellcheck disable=SC1091
  source "$ROOT_DIR/.env"
  set +a
fi

# Resolve Python interpreter cleanly: workspace .venv -> /opt/pyvenv -> python3
if [ -x "$ROOT_DIR/.venv/bin/python" ]; then
  PY_BIN="$ROOT_DIR/.venv/bin/python"
elif [ -x "/opt/pyvenv/bin/python" ]; then
  PY_BIN="/opt/pyvenv/bin/python"
else
  PY_BIN="$(command -v python3)"
fi

# Auto-heal workspace .venv if Python lacks Django/FastAPI/pydantic-settings/psycopg2 (e.g. cold container)
if ! "$PY_BIN" -c "import django, fastapi, pydantic_settings, uvicorn, psycopg2" >/dev/null 2>&1; then
  echo "[bonyan-melk] Bootstrapping local .venv Python environment..."
  python3 -m venv --without-pip "$ROOT_DIR/.venv"
  curl -sS https://bootstrap.pypa.io/get-pip.py -o /tmp/get-pip.py
  "$ROOT_DIR/.venv/bin/python" /tmp/get-pip.py --no-warn-script-location
  rm -f /tmp/get-pip.py
  if [ -f "$ROOT_DIR/backend/requirements.txt" ]; then
    "$ROOT_DIR/.venv/bin/pip" install --no-cache-dir --quiet -r "$ROOT_DIR/backend/requirements.txt"
  else
    "$ROOT_DIR/.venv/bin/pip" install --no-cache-dir --quiet -r "$DJANGO_DIR/requirements.txt" -r "$FASTAPI_DIR/requirements.txt"
  fi
  PY_BIN="$ROOT_DIR/.venv/bin/python"
fi

# Ensure frontend dependencies exist after container cold starts
if [ ! -x "$ROOT_DIR/frontend/node_modules/.bin/next" ]; then
  echo "[bonyan-melk] Installing frontend dependencies..."
  npm --prefix "$ROOT_DIR/frontend" install --no-audit --no-fund
fi

export DJANGO_SETTINGS_MODULE="config.settings.development"
export BACKEND_DIR="$DJANGO_DIR"
export INTERNAL_FASTAPI_URL="http://127.0.0.1:8020"
export DATABASE_URL="${DATABASE_URL:-postgresql://realestate_user:realestate_pass@127.0.0.1:5432/realestate_db}"

# Probe PostgreSQL reachability (2s timeout). Use PostgreSQL whenever reachable; fall back to local sandbox only if unavailable.
if "$PY_BIN" - <<'PYEOF' >/dev/null 2>&1
import os, psycopg2
dsn = os.environ["DATABASE_URL"]
conn = psycopg2.connect(dsn, connect_timeout=2)
conn.close()
PYEOF
then
  unset USE_LOCAL_SANDBOX_DB || true
  export FORCE_POSTGRESQL=1
  echo "[bonyan-melk] Connected to PostgreSQL via DATABASE_URL."
else
  if [ "${FORCE_POSTGRESQL:-0}" = "1" ]; then
    echo "[bonyan-melk] ERROR: FORCE_POSTGRESQL=1 is set, but PostgreSQL is unreachable at DATABASE_URL." >&2
    exit 1
  fi
  export USE_LOCAL_SANDBOX_DB=1
  echo "[bonyan-melk] PostgreSQL is not running/reachable in this preview container; falling back to local sandbox DB."
fi

# Migrate and idempotently seed all 29 domain apps / 83 tables
(cd "$DJANGO_DIR" && "$PY_BIN" manage.py migrate --noinput && "$PY_BIN" manage.py seed_all --quiet)

# Stop any stale listeners
pkill -f "manage.py runserver" >/dev/null 2>&1 || true
pkill -f "uvicorn .* --host 127.0.0.1 --port 8020" >/dev/null 2>&1 || true

# Start FastAPI Web API Service (Port 8020) — Sole Web API Layer backed by Django Core ORM
(cd "$FASTAPI_DIR" && exec "$PY_BIN" -m uvicorn main:app --host 127.0.0.1 --port 8020) &
FASTAPI_PID=$!

cleanup() {
  kill "$FASTAPI_PID" >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM

# Wait briefly for FastAPI healthcheck before starting Next.js
for _ in $(seq 1 20); do
  if curl -fsS "http://127.0.0.1:8020/api/v1/health" >/dev/null 2>&1; then
    break
  fi
  sleep 0.5
done

# Exec Next.js Frontend on Port 3000
exec npm --prefix "$ROOT_DIR/frontend" run dev
