# برنامه تکمیل Phase 0 — بنیان ملک (نسخه 1.0.3)

## وضعیت انتشار — نسخه 1.0.4
این بسته شامل اصلاحات واقعی مالی و release gate علاوه بر preflight است؛ **Phase 0 هنوز PASS نهایی نشده**. محیط بررسی فاقد Django و pytest-django بوده و PostgreSQL، Redis، Node dependencies و سرویس‌های Production در دسترس نیستند.

## تغییرات اعمال‌شده
- کمیسیون: validation برای معامله/تعارض عضویت مشاور، تعرفه منتشرنشده، نوع فرمول و مبلغ ثابت منفی؛ قفل ردیف هنگام تغییر وضعیت.
- Payroll: رد حقوق/ضریب منفی و enum صریح FINANCE_APPROVED برای shares.
- Frontend test runner: shimهای TypeScript برای APIهای Node test در محیط بدون @types/node؛ 12 تست unit اجرا و پاس شدند.
- Release gate: اجرای lint/test/build فرانت و وضعیت BLOCKED در صورت skip شدن gate الزامی.
- رفع مسیر اشتباه در `check_phase0.ps1` برای اجرای static preflight (پیش از این مسیر `scripts/check_phase0_static.py` وجود نداشت).
- اضافه شدن `scripts/check_phase0_static.py`: بررسی syntax پایتون، وجود سه تست Phase 0، و تعریف اسکریپت build/type-check فرانت. این تست **جایگزین** تست Django یا بررسی امنیت عملیاتی نیست.
- این بسته به عنوان نسخه 1.0.3 (Phase 0 validation harness repair) علامت‌گذاری شده؛ نه release نهایی Phase 0.

## بلوک‌کننده‌های باقی‌مانده (Release blockers)
1. اجرای focused Django tests با محیط dependency کامل؛ علت اختلاف run قبلی check script با اجرای 18 تست مستقل را ثبت و بازتولید کنید.
2. Django system checks، migration drift check، migration plan و dry-run مهاجرت media/private storage.
3. تست tenant isolation با دو agency و دو branch (read/list/detail/search/create/update/delete/export).
4. اثبات SSRF: IPv4/IPv6، DNS rebinding، redirect chain، localhost، private ranges و cloud metadata؛ با mock network و egress policy.
5. Upload abuse: سقف درخواست در reverse proxy و app، streaming، فایل ناقص cleanup، MIME/signature، path traversal.
6. مالی: accounting reversal و trial balance؛ کمیسیون percent/fixed/tiered، validation، rounding، transitions و idempotency؛ payroll eligibility، cancel/recompute.
7. Race test رزرو هم‌زمان روی PostgreSQL واقعی: barrier-driven concurrent requests و constraint/locking. SQLite یا تست ترتیبی برای اثبات race کافی نیست.
8. Matching، price analytics و property verification با نقش‌های مختلف و branch/agency scope.
9. WebSocket revoked session، one-time ticket، expiry، origin، connection limit و token leakage در logs.
10. Production startup guard: secret keys، مستقل بودن key material، payment provider، sandbox ممنوع، config completeness.
11. Frontend `npm ci`, `npm run lint`, `npm run test`, `npm run build`; route audit برای صفحات `use client`.
12. بررسی seed/idempotency: پاکسازی یا اصلاح permissions قدیمی مدیر شعبه؛ آزمون دیتابیس واقعی پس از backup در migration staging.

## Release Gate / معیار Go-No-Go
- [ ] هیچ P0 باز؛ تمام P0ها owner، evidence، test و resolution ثبت شده
- [ ] تست‌های Django focused و regression سبز
- [ ] تست tenant isolation دو آژانس/دو شعبه سبز
- [ ] تست‌های مالی و concurrency روی PostgreSQL سبز
- [ ] SSRF/upload/WebSocket security tests سبز
- [ ] Django checks و migrations بدون drift؛ migration rehearsal و backup/restore موفق
- [ ] Frontend lint، unit tests و production build موفق
- [ ] گزارش خروجی قابل بازبینی، commit hash و نسخه artifact ثبت شده
- [ ] rollback plan و عملیات deploy/monitoring آماده

## توالی اجرا
**Wave A (P0):** secret/payment/startup guard، tenant/cross-tenant، private storage/CRM/document permissions، reports scope، accounting reversal/payroll.
**Wave B (P1):** commissions، appointment locking، uploads، SSRF، matching/price/verification، WebSocket، branch permissions/seeding.
**Wave C (Proof):** full test matrix، migration rehearsal، frontend production build، two-tenant acceptance.
**Wave D:** freeze، review evidence، release candidate و Go/No-Go رسمی.

Phase 1 CRM development remains frozen until this gate passes.
