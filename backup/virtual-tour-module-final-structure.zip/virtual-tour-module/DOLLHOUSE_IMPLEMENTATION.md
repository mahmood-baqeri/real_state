# Dollhouse implementation

The Dollhouse viewer is an editable, plan-derived architectural shell. Room layout is persisted in Django `RoomGeometry`; optional explicit `WallSegment` and `WallOpening` records refine the shell. The viewer uses Three.js and supports room selection, floor separation and navigation to each room's 360 panorama.

The backend build job exports a versioned GLB file. Geometry is generated in `building_local_meters`, with X/Z as the floor plane and Y as elevation. Floor slabs, room boundary walls and explicit wall segments are exported. Door/window openings are represented as surface cut-outs. This is a useful lightweight digital-building model, not a detailed BIM model or photogrammetric reconstruction.

A point-cloud upload can produce a separate GLB point preview. Point-cloud preview and architectural mesh generation are different products: the preview does not infer rooms, walls or openings automatically.

## Accurate reconstruction boundary

For a real-world, scan-derived architectural mesh, add a dedicated reconstruction adapter (for example Open3D/COLMAP or a LiDAR-specific pipeline) that performs scan alignment, denoising, segmentation, plane extraction, wall/ceiling/floor reconstruction and manual correction. Store the resulting mesh as a new `GeneratedModelAsset` version and preserve the original scan. Never silently replace reviewed manual geometry with an unverified scan estimate.
