# Next.js Frontend

Next.js 15 + React 19 + TypeScript interface for the standalone real-estate virtual-tour module.

```bash
npm install
cp .env.example .env.local
npm run dev
```

Routes:
- `/` — tour dashboard
- `/tours/[id]` — tour, floor, scene, capture, navigation and hotspot management
- `/capture/[sceneId]?tour=<tourId>` — guided mobile capture and image-quality feedback
- `/geometry/[tourId]` — floor-plan calibration, metric room geometry, walls and openings, measurements, scan upload and GLB build
- `/dollhouse/[tourId]` — interactive 3D Dollhouse, room navigation, scan previews and model export/review
- `/viewer/[tourId]` — interactive 360 panorama experience

The frontend talks to FastAPI. Persistent data models and migrations remain exclusively in Django.
