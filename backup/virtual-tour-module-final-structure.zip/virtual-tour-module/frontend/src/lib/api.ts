const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";
export async function api<T>(path:string, init:RequestInit={}):Promise<T>{
 const response=await fetch(`${API}${path}`,{...init,headers:{...(init.body instanceof FormData?{}:{"Content-Type":"application/json"}),...init.headers},cache:"no-store"});
 const body=await response.json().catch(()=>({detail:"پاسخ نامعتبر سرور"}));
 if(!response.ok) throw new Error(body.detail || `HTTP ${response.status}`);
 return body as T;
}
export const mediaUrl=(key:string)=>`${process.env.NEXT_PUBLIC_MEDIA_URL || "http://localhost:8000/media"}/${key}`;
