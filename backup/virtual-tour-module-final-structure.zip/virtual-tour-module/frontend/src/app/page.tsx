"use client";
import {useEffect,useState} from "react";
import Link from "next/link";
import {api} from "@/lib/api";
type TourItem={id:string;title:string;description:string;status:string;resource_id:string;updated_at:string};
export default function Home(){
 const [resource,setResource]=useState("property-001"),[title,setTitle]=useState("تور مجازی ملک"),[busy,setBusy]=useState(false),[error,setError]=useState(""),[tours,setTours]=useState<TourItem[]>([]);
 async function load(){try{setTours(await api<TourItem[]>("/tours"));}catch(e){setError((e as Error).message);}}
 useEffect(()=>{load();},[]);
 async function create(){setBusy(true);setError("");try{const r=await api<{id:string}>("/tours",{method:"POST",body:JSON.stringify({resource_type:"property",resource_id:resource,title})});location.href=`/tours/${r.id}`;}catch(e){setError((e as Error).message);}finally{setBusy(false);}}
 return <main className="container"><header style={{marginBottom:28}}><div className="muted">VIRTUAL TOUR STUDIO</div><h1>ساخت تور مجازی ۳۶۰ درجه</h1><p className="muted">عکاسی هدایت‌شده، پردازش تصاویر و ساخت تجربه بازدید مجازی ملک</p></header><section className="grid"><div className="panel"><h2>ایجاد تور جدید</h2><label>شناسه ملک / منبع</label><input className="field" value={resource} onChange={e=>setResource(e.target.value)}/><label>عنوان تور</label><input className="field" value={title} onChange={e=>setTitle(e.target.value)}/><button className="btn" disabled={busy||!resource||!title} onClick={create}>{busy?"در حال ایجاد…":"ایجاد تور و شروع"}</button>{error&&<p style={{color:"#c33"}}>{error}</p>}<p className="muted">شناسه منبع فقط یک مرجع خارجی است؛ مدیریت ملک در این ماژول انجام نمی‌شود.</p></div><div className="panel"><h2>مراحل کار</h2><ol><li>ساخت طبقات و فضاها</li><li>عکاسی هدایت‌شده با موبایل</li><li>کنترل کیفیت تصاویر</li><li>ساخت پانوراما با صف پردازش</li><li>اتصال فضاها و انتشار تور</li></ol></div></section>
 <section style={{marginTop:28}}><h2>تورهای ساخته‌شده</h2>{tours.length===0?<div className="panel muted">هنوز توری ساخته نشده است.</div>:<div className="grid">{tours.map(t=><div className="scene" key={t.id}><b>{t.title}</b><p className="muted">شناسه ملک: {t.resource_id} · وضعیت: {t.status}</p><Link className="btn secondary" href={`/tours/${t.id}`}>مدیریت تور</Link><Link className="btn" style={{marginRight:8}} href={`/viewer/${t.id}`}>پیش‌نمایش</Link><button className="btn secondary" style={{marginRight:8}} onClick={async()=>{if(!confirm("این تور و تمام تصاویر و فایل‌های مرتبط حذف شوند؟"))return;try{await api(`/tours/${t.id}`,{method:"DELETE"});await load();}catch(e){setError((e as Error).message);}}}>حذف تور</button></div>)}</div>}</section>
 <p className="muted" style={{marginTop:20}}>این ماژول مستقل است و از طریق API به سامانه میزبان متصل می‌شود.</p></main>;
}
