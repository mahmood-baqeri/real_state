import "./globals.css";
import type { Metadata } from "next";
export const metadata:Metadata={title:"Virtual Tour Studio",description:"Create and publish interactive 360 virtual tours"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="fa" dir="rtl"><body>{children}</body></html>}
