"use client";
import {useEffect,useRef} from "react";
import * as THREE from "three";
import {OrbitControls} from "three/examples/jsm/controls/OrbitControls.js";

export type DollhouseRoom={id:string;floor_id:string;floor_title:string;title:string;room_type:string;x:number;z:number;width:number;depth:number;height:number;rotation:number;polygon?:number[][];panorama_url:string|null;thumbnail_url:string|null};
export type DollhouseWall={id:string;floor_id:string;room_id:string|null;start_x_m:number;start_z_m:number;end_x_m:number;end_z_m:number;height_m:number;thickness_m:number;kind:string;material:string;openings:{id:string;kind:string;offset_m:number;width_m:number;height_m:number;sill_height_m:number}[]};
export type DollhouseFloor={id:string;title:string;elevation:number};

function labelSprite(text:string){
 const canvas=document.createElement("canvas");canvas.width=512;canvas.height=128;const ctx=canvas.getContext("2d")!;
 ctx.fillStyle="rgba(16,24,39,.82)";ctx.beginPath();ctx.roundRect(8,8,496,112,24);ctx.fill();ctx.fillStyle="#fff";ctx.font="bold 42px Arial";ctx.textAlign="center";ctx.textBaseline="middle";ctx.fillText(text.slice(0,24),256,64);
 const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:texture,transparent:true,depthTest:false}));sprite.scale.set(2.7,.68,1);return sprite;
}
function addBox(parent:THREE.Group,w:number,h:number,d:number,x:number,y:number,z:number,color:number,material?:THREE.Material){const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material||new THREE.MeshStandardMaterial({color,roughness:.78}));mesh.position.set(x,y,z);mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh;}

function projectedWallTexture(image:HTMLImageElement,centerYaw:number){
 const canvas=document.createElement("canvas");canvas.width=640;canvas.height=420;const ctx=canvas.getContext("2d")!;const source=document.createElement("canvas");source.width=image.naturalWidth;source.height=image.naturalHeight;source.getContext("2d")!.drawImage(image,0,0);const src=source.getContext("2d")!.getImageData(0,0,source.width,source.height).data;const out=ctx.createImageData(canvas.width,canvas.height);const hfov=THREE.MathUtils.degToRad(100),vfov=THREE.MathUtils.degToRad(76);
 for(let y=0;y<canvas.height;y++){const ny=(1-2*(y+.5)/canvas.height)*Math.tan(vfov/2);for(let x=0;x<canvas.width;x++){const nx=(2*(x+.5)/canvas.width-1)*Math.tan(hfov/2);const yaw=centerYaw+Math.atan(nx);const pitch=Math.atan(ny/Math.sqrt(1+nx*nx));let u=((yaw/(Math.PI*2)+.5)%1+1)%1;let v=Math.max(0,Math.min(1,.5-pitch/Math.PI));const sx=Math.min(source.width-1,Math.max(0,Math.floor(u*source.width)));const sy=Math.min(source.height-1,Math.max(0,Math.floor(v*source.height)));const si=(sy*source.width+sx)*4,di=(y*canvas.width+x)*4;out.data[di]=src[si];out.data[di+1]=src[si+1];out.data[di+2]=src[si+2];out.data[di+3]=255;}}
 ctx.putImageData(out,0,0);const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=8;return texture;
}
function applyPanoramaWalls(room:DollhouseRoom,wallMeshes:{mesh:THREE.Mesh;yaw:number}[]){
 if(!room.panorama_url)return;const loader=new THREE.TextureLoader();loader.setCrossOrigin("anonymous");loader.load(room.panorama_url,loaded=>{const image=loaded.image as HTMLImageElement;for(const item of wallMeshes){const mat=new THREE.MeshStandardMaterial({map:projectedWallTexture(image,item.yaw),roughness:.95});item.mesh.material=mat;mat.needsUpdate=true;}loaded.dispose();});
}
function furniture(group:THREE.Group,room:DollhouseRoom){
 const w=room.width,d=room.depth, type=(room.room_type||"").toLowerCase();
 const wood=new THREE.MeshStandardMaterial({color:0x9a7654,roughness:.8}), fabric=new THREE.MeshStandardMaterial({color:0xc3b6a4,roughness:1}), dark=new THREE.MeshStandardMaterial({color:0x6f777d,roughness:.7});
 if(/bed|خواب/.test(type)){
  addBox(group,w*.48,.32,d*.42,-w*.12,.22,-d*.08,0x8e735d,wood);addBox(group,w*.44,.13,d*.38,-w*.12,.45,-d*.08,0xe9e3d9,fabric);addBox(group,w*.16,.12,d*.12,-w*.23,.57,-d*.22,0xffffff);addBox(group,w*.16,.12,d*.12,-w*.01,.57,-d*.22,0xffffff);
  addBox(group,.45,.48,.45,w*.32,.28,-d*.34,0x98785b,wood);
 }else if(/living|lounge|پذیر|نشیم/.test(type)){
  addBox(group,w*.5,.48,.85,-w*.12,.42,-d*.22,0xb8a995,fabric);addBox(group,w*.5,.25,.18,-w*.12,.78,-d*.57,0xa89986,fabric);addBox(group,.72,.28,.65,w*.22,.16,d*.16,0x8e6f50,wood);
 }else if(/kitchen|آشپز/.test(type)){
  addBox(group,w*.72,.88,.58,0,.47,-d*.35,0xaaa9a4,dark);addBox(group,w*.72,.08,.6,0,.94,-d*.35,0xf0eee9);addBox(group,.72,.86,.52,-w*.34,.46,d*.12,0xaaa9a4,dark);
 }else if(/bath|حمام|سرویس/.test(type)){
  addBox(group,.85,.42,.72,-w*.18,.22,-d*.22,0xf3f4f2);addBox(group,.55,.42,.55,w*.25,.22,d*.18,0xd9e6e8);addBox(group,.7,.08,.7,0,.06,0,0xcbd7d8);
 }else{
  addBox(group,Math.min(1.5,w*.35),.72,.72,0,.4,0,0x9c8063,wood);addBox(group,Math.min(1.65,w*.38),.08,.78,0,.8,0,0xd6c5ad);
 }
}

export default function Dollhouse3D({rooms,floors,walls=[],onSelect}:{rooms:DollhouseRoom[];floors:DollhouseFloor[];walls?:DollhouseWall[];onSelect:(id:string)=>void}){
 const host=useRef<HTMLDivElement>(null), selectRef=useRef(onSelect);selectRef.current=onSelect;
 useEffect(()=>{
  const el=host.current;if(!el)return;
  const scene=new THREE.Scene();scene.background=new THREE.Color(0xe9edf2);
  const camera=new THREE.PerspectiveCamera(42,el.clientWidth/Math.max(el.clientHeight,1),.1,1000);camera.position.set(15,17,19);
  const renderer=new THREE.WebGLRenderer({antialias:true,alpha:false});renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));renderer.setSize(el.clientWidth,el.clientHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;el.appendChild(renderer.domElement);
  scene.add(new THREE.HemisphereLight(0xffffff,0x9aa3ad,2.1));const sun=new THREE.DirectionalLight(0xffffff,2.2);sun.position.set(8,18,10);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);scene.add(sun);
  const ground=new THREE.Mesh(new THREE.PlaneGeometry(300,300),new THREE.MeshStandardMaterial({color:0xe9edf2,roughness:1}));ground.rotation.x=-Math.PI/2;ground.position.y=-.18;ground.receiveShadow=true;scene.add(ground);
  const root=new THREE.Group();scene.add(root);
  const floorColors=[0xd7c4a7,0xcbbba5,0xd8d0c1,0xbfc9c7];
  rooms.forEach((r,index)=>{
   const floorIndex=Math.max(0,floors.findIndex(f=>f.id===r.floor_id));const elevation=floors[floorIndex]?.elevation||0;
   const g=new THREE.Group();g.position.set(r.x,elevation,r.z);g.rotation.y=THREE.MathUtils.degToRad(r.rotation||0);g.userData.roomId=r.id;root.add(g);
   const w=r.width,d=r.depth,h=r.height;
   const floorMat=new THREE.MeshStandardMaterial({color:floorColors[floorIndex%floorColors.length],roughness:.92,side:THREE.DoubleSide});
   const polygon=r.polygon&&r.polygon.length>=3?r.polygon:[[-w/2,-d/2],[w/2,-d/2],[w/2,d/2],[-w/2,d/2]];
   const floorShape=new THREE.Shape();floorShape.moveTo(polygon[0][0],polygon[0][1]);polygon.slice(1).forEach(p=>floorShape.lineTo(p[0],p[1]));floorShape.closePath();
   const slabGeometry=new THREE.ExtrudeGeometry(floorShape,{depth:.16,bevelEnabled:false});slabGeometry.rotateX(Math.PI/2);
   const slab=new THREE.Mesh(slabGeometry,floorMat);slab.position.y=.16;slab.receiveShadow=true;slab.userData.roomId=r.id;g.add(slab);
   const explicitWalls=walls.filter(wall=>wall.room_id===r.id);
   if(explicitWalls.length<4){
    // Derive roofless wall segments from the room polygon; the front-most edge is a low cut-away parapet.
    const plainWall=new THREE.MeshStandardMaterial({color:0xf0eee8,roughness:.92,side:THREE.DoubleSide});
    const frontIndex=polygon.reduce((best,p,i)=>((p[1]+polygon[(i+1)%polygon.length][1])>(polygon[best][1]+polygon[(best+1)%polygon.length][1])?i:best),0);
    const projected=[];
    polygon.forEach((p,i)=>{const q=polygon[(i+1)%polygon.length],dx=q[0]-p[0],dz=q[1]-p[1],length=Math.hypot(dx,dz);if(length<.05)return;const wallHeight = i === frontIndex ? 0.78 : h;const mesh=addBox(g,length,wallHeight,.13,(p[0]+q[0])/2,wallHeight/2,(p[1]+q[1])/2,0xffffff,plainWall);mesh.rotation.y=-Math.atan2(dz,dx);projected.push({mesh,yaw:-Math.atan2(dz,dx)});});
    applyPanoramaWalls(r,projected);
   }
   furniture(g,r);
   const label=labelSprite(r.title);label.position.set(0,h+.55,0);g.add(label);
   // Invisible pick surface covers the room floor for reliable selection.
   const pick=new THREE.Mesh(new THREE.PlaneGeometry(w,d),new THREE.MeshBasicMaterial({transparent:true,opacity:0,side:THREE.DoubleSide}));pick.rotation.x=-Math.PI/2;pick.position.y=.18;pick.userData.roomId=r.id;g.add(pick);
  });
  // Explicit walls use metric endpoints and cut-outs for doors/windows.
  walls.forEach(wall=>{
   const dx=wall.end_x_m-wall.start_x_m,dz=wall.end_z_m-wall.start_z_m,length=Math.hypot(dx,dz);if(length<.05)return;
   const shape=new THREE.Shape();shape.moveTo(0,0);shape.lineTo(length,0);shape.lineTo(length,wall.height_m);shape.lineTo(0,wall.height_m);shape.closePath();
   (wall.openings||[]).forEach(opening=>{const x=Math.max(0,opening.offset_m),x2=Math.min(length,x+opening.width_m),y=Math.max(0,opening.sill_height_m),y2=Math.min(wall.height_m,y+opening.height_m);if(x2<=x||y2<=y)return;const hole=new THREE.Path();hole.moveTo(x,y);hole.lineTo(x,y2);hole.lineTo(x2,y2);hole.lineTo(x2,y);hole.closePath();shape.holes.push(hole);});
   const geometry=new THREE.ExtrudeGeometry(shape,{depth:Math.max(.05,wall.thickness_m),bevelEnabled:false});geometry.computeVertexNormals();
   const material=new THREE.MeshStandardMaterial({color:wall.kind==="glass"?0x9bb8c8:0xf0eee8,roughness:wall.kind==="glass"?.25:.92,metalness:wall.kind==="glass"?.08:0,transparent:wall.kind==="glass",opacity:wall.kind==="glass"?.48:1,side:THREE.DoubleSide});
   const mesh=new THREE.Mesh(geometry,material);const floorIndex=Math.max(0,floors.findIndex(f=>f.id===wall.floor_id));const elevation=floors[floorIndex]?.elevation||0;
   mesh.position.set(wall.start_x_m,elevation,wall.start_z_m);mesh.rotation.y=-Math.atan2(dz,dx);mesh.castShadow=true;mesh.receiveShadow=true;if(wall.room_id){mesh.userData.roomId=wall.room_id;const room=rooms.find(r=>r.id===wall.room_id);if(room)applyPanoramaWalls(room,[{mesh,yaw:-Math.atan2(dz,dx)}]);}root.add(mesh);
  });
  // Floor plates keep storeys visually separate and readable.
  floors.forEach((f,i)=>{const floorRooms=rooms.filter(r=>r.floor_id===f.id);if(!floorRooms.length)return;const minX=Math.min(...floorRooms.map(r=>r.x-r.width/2))-1,maxX=Math.max(...floorRooms.map(r=>r.x+r.width/2))+1,minZ=Math.min(...floorRooms.map(r=>r.z-r.depth/2))-1,maxZ=Math.max(...floorRooms.map(r=>r.z+r.depth/2))+1;const plate=addBox(root,maxX-minX,.12,maxZ-minZ,(minX+maxX)/2,(f.elevation||i*3.25)-.12,(minZ+maxZ)/2,0xd6d9dc);plate.material=new THREE.MeshStandardMaterial({color:0xd6d9dc,roughness:.95});});
  const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.dampingFactor=.06;controls.maxPolarAngle=Math.PI*.49;controls.minDistance=5;controls.maxDistance=90;controls.target.set(0,1.3,0);controls.update();
  const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();const onClick=(event:MouseEvent)=>{const rect=renderer.domElement.getBoundingClientRect();pointer.x=((event.clientX-rect.left)/rect.width)*2-1;pointer.y=-((event.clientY-rect.top)/rect.height)*2+1;raycaster.setFromCamera(pointer,camera);const hits=raycaster.intersectObjects(root.children,true);for(const hit of hits){let obj:THREE.Object3D|null=hit.object;while(obj){if(obj.userData.roomId){selectRef.current(String(obj.userData.roomId));return;}obj=obj.parent;}}};renderer.domElement.addEventListener("click",onClick);
  const resize=new ResizeObserver(()=>{if(!host.current)return;const w=host.current.clientWidth,h=host.current.clientHeight;camera.aspect=w/Math.max(h,1);camera.updateProjectionMatrix();renderer.setSize(w,h);});resize.observe(el);
  let frame=0;const animate=()=>{frame=requestAnimationFrame(animate);controls.update();renderer.render(scene,camera);};animate();
  return()=>{cancelAnimationFrame(frame);resize.disconnect();renderer.domElement.removeEventListener("click",onClick);controls.dispose();root.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();const m=o.material;if(Array.isArray(m))m.forEach(x=>{(x as THREE.Material & {map?:THREE.Texture|null}).map?.dispose();x.dispose();});else {(m as THREE.Material & {map?:THREE.Texture|null}).map?.dispose();m.dispose();}}if(o instanceof THREE.Sprite){o.material.map?.dispose();o.material.dispose();}});renderer.dispose();el.removeChild(renderer.domElement);};
 },[rooms,floors,walls]);
 return <div ref={host} style={{width:"100%",height:"min(72vh,760px)",minHeight:440,borderRadius:16,overflow:"hidden",background:"#e9edf2",touchAction:"pan-y"}}/>;
}
