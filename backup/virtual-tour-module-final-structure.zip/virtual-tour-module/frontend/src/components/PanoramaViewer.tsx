"use client";
import {useEffect,useRef} from "react";
import {Viewer} from "@photo-sphere-viewer/core";
import {MarkersPlugin} from "@photo-sphere-viewer/markers-plugin";
import "@photo-sphere-viewer/core/index.css";
import "@photo-sphere-viewer/markers-plugin/index.css";
export type TourMarker={id:string;title:string;body?:string;yaw:number;pitch:number;target_scene_id?:string|null};
export default function PanoramaViewer({src,yaw=0,pitch=0,markers=[],onMarkerSelect,onPositionSelect}:{src:string;yaw?:number;pitch?:number;markers?:TourMarker[];onMarkerSelect?:(targetId:string)=>void;onPositionSelect?:(yaw:number,pitch:number)=>void}){
 const host=useRef<HTMLDivElement>(null);
 useEffect(()=>{
  if(!host.current||!src)return;
  const viewer=new Viewer({container:host.current,panorama:src,navbar:["zoom","fullscreen"],defaultYaw:`${yaw}deg`,defaultPitch:`${pitch}deg`,mousewheel:true,plugins:[[MarkersPlugin,{markers:markers.map(m=>({id:m.id,position:{yaw:`${m.yaw}deg`,pitch:`${m.pitch}deg`},html:`<div class="vt-marker">${escapeHtml(m.title)}</div>`,tooltip:{content:`<strong>${escapeHtml(m.title)}</strong>${m.body?`<br/>${escapeHtml(m.body)}`:""}`,position:"top"},data:{targetSceneId:m.target_scene_id||null}}))}]]});
  const plugin=viewer.getPlugin(MarkersPlugin);
  const handle=(event:any)=>{const target=event.marker?.data?.targetSceneId;if(target)onMarkerSelect?.(target);};
  const handleClick=(event:any)=>{const point=event.data;if(point&&typeof point.yaw==="number"&&typeof point.pitch==="number")onPositionSelect?.(point.yaw*180/Math.PI,point.pitch*180/Math.PI);};
  plugin.addEventListener("select-marker",handle);
  viewer.addEventListener("click",handleClick);
  return()=>{plugin.removeEventListener("select-marker",handle);viewer.removeEventListener("click",handleClick);viewer.destroy();};
 },[src,yaw,pitch,markers,onMarkerSelect,onPositionSelect]);
 return <div ref={host} className="viewer" aria-label="نمایش پانورامای ۳۶۰ درجه"/>;
}
function escapeHtml(value:string){return value.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]!));}
