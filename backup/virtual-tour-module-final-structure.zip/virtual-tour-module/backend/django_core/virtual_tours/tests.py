"""آزمون‌های مدل‌های ماژول تور مجازی در محیط پروژه اصلی Django."""
from django.test import TestCase
from .models import Tour, Floor, Scene, RoomGeometry


class VirtualTourModelTests(TestCase):
    """رفتار پایه مدل‌ها و ارتباط بین تور، طبقه و فضای داخلی را بررسی می‌کند."""

    def test_create_tour_floor_and_scene(self):
        """ساخت تور، طبقه و فضا باید با ارتباط‌های درست انجام شود."""
        tour = Tour.objects.create(title="تور آزمایشی", resource_id="property-1")
        floor = Floor.objects.create(tour=tour, title="همکف")
        scene = Scene.objects.create(tour=tour, floor=floor, title="پذیرایی")
        self.assertEqual(scene.tour_id, tour.id)
        self.assertEqual(scene.floor_id, floor.id)

    def test_room_geometry_uses_meter_based_coordinates(self):
        """هندسه اتاق باید با واحد متر و سیستم مختصات ساختمان ذخیره شود."""
        tour = Tour.objects.create(title="تور هندسه", resource_id="property-2")
        floor = Floor.objects.create(tour=tour, title="طبقه اول")
        scene = Scene.objects.create(tour=tour, floor=floor, title="اتاق خواب")
        geometry = RoomGeometry.objects.create(scene=scene, width_m=3.5, depth_m=4.0)
        self.assertEqual(geometry.coordinate_system, "building_local_meters")
        self.assertEqual(geometry.width_m, 3.5)
