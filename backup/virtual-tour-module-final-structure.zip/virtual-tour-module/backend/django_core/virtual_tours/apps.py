"""تنظیمات ثبت ماژول تور مجازی در پروژه اصلی Django."""
from django.apps import AppConfig


class VirtualToursConfig(AppConfig):
    """ماژول تور مجازی را به فهرست برنامه‌های پروژه میزبان معرفی می‌کند."""
    default_auto_field = "django.db.models.BigAutoField"
    name = "virtual_tours"
    label = "virtual_tours"
    verbose_name = "تور مجازی املاک"
