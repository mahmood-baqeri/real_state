# -*- coding: utf-8 -*-
"""مدل‌های دیتابیس ماژول تور مجازی؛ مالک تمام داده‌های پایدار این قابلیت، Django است."""

import uuid
from django.db import models

class TimestampedModel(models.Model):
    """مدل پایه برای نگهداری زمان ایجاد و آخرین ویرایش رکوردها."""
    created_at = models.DateTimeField(auto_now_add=True, help_text='زمان ایجاد این رکورد؛ به\u200cصورت خودکار ثبت می\u200cشود.')
    updated_at = models.DateTimeField(auto_now=True, help_text='آخرین زمان ویرایش این رکورد؛ به\u200cصورت خودکار به\u200cروزرسانی می\u200cشود.')

    class Meta:
        abstract = True

class Tour(TimestampedModel):
    """اطلاعات اصلی تور مجازی که به یک ملک یا موجودیت سامانه میزبان متصل است."""

    class Status(models.TextChoices):
        DRAFT = 'draft'
        CAPTURING = 'capturing'
        PROCESSING = 'processing'
        REVIEW = 'review'
        EDITING = 'editing'
        READY = 'ready'
        PUBLISHED = 'published'
        ARCHIVED = 'archived'
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    resource_type = models.CharField(max_length=80, default='property', help_text='نوع موجودیت اصلی که تور به آن متصل است؛ معمولاً ملک.')
    resource_id = models.CharField(max_length=128, db_index=True, help_text='شناسه ملک یا موجودیت اصلی در سامانه میزبان.')
    tenant_id = models.CharField(max_length=128, null=True, blank=True, db_index=True, help_text='شناسه سازمان یا مالک داده در سامانه میزبان؛ برای جداسازی اطلاعات.')
    title = models.CharField(max_length=255, help_text='عنوان قابل نمایش برای این مورد.')
    description = models.TextField(blank=True, help_text='توضیحات تکمیلی که برای کاربر نمایش داده می\u200cشود.')
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT, help_text='وضعیت فعلی این مورد در روند کار.')
    settings = models.JSONField(default=dict, blank=True, help_text='تنظیمات اختصاصی این تور به\u200cصورت داده ساختاریافته.')

    def __str__(self):
        return self.title

class Floor(TimestampedModel):
    """طبقه\u200cهای یک تور را نگهداری می\u200cکند و هر طبقه می\u200cتواند پلان و چند فضای داخلی داشته باشد."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    tour = models.ForeignKey(Tour, on_delete=models.CASCADE, related_name='floors', help_text='توری که این اطلاعات به آن تعلق دارد.')
    title = models.CharField(max_length=150, help_text='عنوان قابل نمایش برای این مورد.')
    order = models.PositiveIntegerField(default=0, help_text='ترتیب نمایش این مورد در فهرست یا روی نقشه.')
    plan_key = models.CharField(max_length=700, null=True, blank=True, help_text='مسیر فایل پلان این طبقه در فضای ذخیره\u200cسازی.')
    elevation_m = models.FloatField(default=0, help_text='ارتفاع کف این طبقه نسبت به مبدأ ساختمان، بر حسب متر.')

    class Meta:
        ordering = ['order']

class Scene(TimestampedModel):
    """هر فضای قابل بازدید در تور؛ مانند اتاق، سالن یا آشپزخانه را نگهداری می\u200cکند."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    tour = models.ForeignKey(Tour, on_delete=models.CASCADE, related_name='scenes', help_text='توری که این اطلاعات به آن تعلق دارد.')
    floor = models.ForeignKey(Floor, on_delete=models.CASCADE, related_name='scenes', help_text='طبقه\u200cای که این فضا یا داده در آن قرار دارد.')
    title = models.CharField(max_length=150, help_text='عنوان قابل نمایش برای این مورد.')
    room_type = models.CharField(max_length=40, default='other', help_text='نوع فضای داخلی؛ مانند پذیرایی، اتاق خواب یا آشپزخانه.')
    description = models.TextField(blank=True, help_text='توضیحات تکمیلی که برای کاربر نمایش داده می\u200cشود.')
    order = models.PositiveIntegerField(default=0, help_text='ترتیب نمایش این مورد در فهرست یا روی نقشه.')
    start_scene = models.BooleanField(default=False, help_text='مشخص می\u200cکند این فضا نقطه شروع تور باشد یا خیر.')
    active = models.BooleanField(default=True, help_text='مشخص می\u200cکند این فضا در تور فعال و قابل نمایش باشد یا خیر.')
    floor_x = models.FloatField(null=True, blank=True, help_text='مختصات افقی محل دوربین روی پلان طبقه.')
    floor_y = models.FloatField(null=True, blank=True, help_text='مختصات عمودی محل دوربین روی پلان طبقه.')
    initial_yaw = models.FloatField(default=0, help_text='زاویه افقی اولیه نمایش پانوراما، بر حسب درجه.')
    initial_pitch = models.FloatField(default=0, help_text='زاویه عمودی اولیه نمایش پانوراما، بر حسب درجه.')
    panorama_key = models.CharField(max_length=700, null=True, blank=True, help_text='مسیر فایل پانورامای نهایی این فضا.')
    thumbnail_key = models.CharField(max_length=700, null=True, blank=True, help_text='مسیر تصویر بندانگشتی این فضا.')
    width_m = models.FloatField(null=True, blank=True, help_text='عرض بازشو بر حسب متر.')
    length_m = models.FloatField(null=True, blank=True, help_text='طول فضا بر حسب متر.')
    height_m = models.FloatField(default=2.8, help_text='ارتفاع بازشو بر حسب متر.')
    polygon = models.JSONField(default=list, blank=True, help_text='نقاط مرزی فضای اتاق در مختصات پلان؛ برای ساخت هندسه دقیق\u200cتر.')
    geometry_source = models.CharField(max_length=32, default='manual_plan', help_text='منبعی که ابعاد یا شکل هندسی فضا از آن به دست آمده است.')

    class Meta:
        ordering = ['order']

class CaptureSession(TimestampedModel):
    """یک نوبت عکاسی هدایت\u200cشده از یک فضای مشخص را مدیریت می\u200cکند."""

    class Status(models.TextChoices):
        CREATED = 'created'
        CAPTURING = 'capturing'
        VALIDATING = 'validating'
        NEEDS_RETAKE = 'needs_retake'
        READY = 'ready'
        COMPLETED = 'completed'
        CANCELLED = 'cancelled'
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    tour = models.ForeignKey(Tour, on_delete=models.CASCADE, help_text='توری که این اطلاعات به آن تعلق دارد.')
    scene = models.ForeignKey(Scene, on_delete=models.CASCADE, related_name='capture_sessions', help_text='فضایی که این تصویر یا داده به آن تعلق دارد.')
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.CREATED, help_text='وضعیت فعلی این مورد در روند کار.')
    plan = models.JSONField(default=dict, help_text='راهنمای مرحله\u200cها و زاویه\u200cهای موردنیاز برای عکاسی.')
    device = models.JSONField(default=dict, help_text='اطلاعات گوشی و دوربین مورد استفاده برای ثبت تصاویر.')

class CaptureImage(TimestampedModel):
    """تصاویر خام ثبت\u200cشده در جلسه عکاسی و نتیجه بررسی کیفیت هر تصویر را نگهداری می\u200cکند."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    session = models.ForeignKey(CaptureSession, on_delete=models.CASCADE, related_name='images', help_text='جلسه عکاسی که این تصویر در آن ثبت شده است.')
    scene = models.ForeignKey(Scene, on_delete=models.CASCADE, related_name='capture_images', help_text='فضایی که این تصویر یا داده به آن تعلق دارد.')
    storage_key = models.CharField(max_length=700, help_text='مسیر فایل ذخیره\u200cشده در فضای فایل\u200cها.')
    filename = models.CharField(max_length=255, help_text='نام اصلی فایل بارگذاری\u200cشده.')
    sequence = models.PositiveIntegerField(help_text='شماره ترتیب ثبت تصویر در جلسه عکاسی.')
    size = models.BigIntegerField(default=0, help_text='حجم فایل بر حسب بایت.')
    width = models.PositiveIntegerField(default=0, help_text='عرض تصویر بر حسب پیکسل.')
    height = models.PositiveIntegerField(default=0, help_text='ارتفاع تصویر بر حسب پیکسل.')
    status = models.CharField(max_length=20, default='uploaded', help_text='وضعیت فعلی این مورد در روند کار.')
    analysis = models.JSONField(default=dict, help_text='نتیجه بررسی کیفیت تصویر؛ مانند تاری، نور و وضوح.')
    yaw = models.FloatField(null=True, blank=True, help_text='زاویه افقی ثبت تصویر، بر حسب درجه.')
    pitch = models.FloatField(null=True, blank=True, help_text='زاویه عمودی ثبت تصویر، بر حسب درجه.')

    class Meta:
        constraints = [models.UniqueConstraint(fields=['session', 'sequence'], name='uq_vt_image_sequence')]

class SceneLink(TimestampedModel):
    """مسیر حرکت کاربر بین دو فضای تور را تعریف می\u200cکند."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    tour = models.ForeignKey(Tour, on_delete=models.CASCADE, help_text='توری که این اطلاعات به آن تعلق دارد.')
    source_scene = models.ForeignKey(Scene, on_delete=models.CASCADE, related_name='outgoing_links', help_text='فضایی که حرکت از آن آغاز می\u200cشود.')
    target_scene = models.ForeignKey(Scene, on_delete=models.CASCADE, related_name='incoming_links', help_text='فضایی که کاربر با انتخاب این مسیر به آن منتقل می\u200cشود.')
    yaw = models.FloatField(default=0, help_text='زاویه افقی ثبت تصویر، بر حسب درجه.')
    pitch = models.FloatField(default=0, help_text='زاویه عمودی ثبت تصویر، بر حسب درجه.')
    title = models.CharField(max_length=120, default='رفتن به فضای بعدی', help_text='عنوان قابل نمایش برای این مورد.')
    bidirectional = models.BooleanField(default=False, help_text='اگر فعال باشد، مسیر رفت و برگشت بین دو فضا ایجاد می\u200cشود.')

class Hotspot(TimestampedModel):
    """نقطه قابل انتخاب روی پانوراما برای نمایش اطلاعات یا رفتن به فضای دیگر است."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    scene = models.ForeignKey(Scene, on_delete=models.CASCADE, related_name='hotspots', help_text='فضایی که این تصویر یا داده به آن تعلق دارد.')
    kind = models.CharField(max_length=30, default='info', help_text='نوع نقطه یا بازشو؛ برای تعیین رفتار و ظاهر آن.')
    title = models.CharField(max_length=150, help_text='عنوان قابل نمایش برای این مورد.')
    body = models.TextField(blank=True, help_text='متن توضیحی که با انتخاب نقطه اطلاعاتی نمایش داده می\u200cشود.')
    yaw = models.FloatField(default=0, help_text='زاویه افقی ثبت تصویر، بر حسب درجه.')
    pitch = models.FloatField(default=0, help_text='زاویه عمودی ثبت تصویر، بر حسب درجه.')
    target_scene = models.ForeignKey(Scene, on_delete=models.SET_NULL, null=True, blank=True, related_name='targeted_hotspots', help_text='فضایی که کاربر با انتخاب این مسیر به آن منتقل می\u200cشود.')

class ProcessingJob(TimestampedModel):
    """وضعیت و نتیجه پردازش تصاویر یک فضا برای ساخت پانوراما را نگهداری می\u200cکند."""

    class State(models.TextChoices):
        QUEUED = 'queued'
        RUNNING = 'running'
        COMPLETED = 'completed'
        FAILED = 'failed'
        REVIEW = 'review'
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    tour = models.ForeignKey(Tour, on_delete=models.CASCADE, help_text='توری که این اطلاعات به آن تعلق دارد.')
    scene = models.ForeignKey(Scene, on_delete=models.CASCADE, related_name='processing_jobs', help_text='فضایی که این تصویر یا داده به آن تعلق دارد.')
    state = models.CharField(max_length=20, choices=State.choices, default=State.QUEUED, help_text='وضعیت فعلی فایل یا عملیات.')
    progress = models.PositiveSmallIntegerField(default=0, help_text='درصد پیشرفت عملیات؛ عددی بین صفر تا صد.')
    step = models.CharField(max_length=100, default='queued', help_text='نام مرحله\u200cای که عملیات اکنون در حال انجام آن است.')
    error = models.TextField(blank=True, help_text='شرح خطایی که هنگام اجرای عملیات رخ داده است.')
    result = models.JSONField(default=dict, help_text='خروجی\u200cها و اطلاعات تکمیلی عملیات به\u200cصورت داده ساختاریافته.')

class ScanAsset(TimestampedModel):
    """فایل\u200cهای ورودی اسکن عمقی، لیدار، ابرنقاط یا داده\u200cهای فتوگرامتری را ثبت می\u200cکند."""

    class Source(models.TextChoices):
        MANUAL_PLAN = 'manual_plan'
        PANORAMA_ESTIMATED = 'panorama_estimated'
        DEPTH_SCAN = 'depth_scan'
        LIDAR_DEPTH = 'lidar_depth'
        DEPTH_MAP = 'depth_map'
        POINT_CLOUD = 'point_cloud'
        PHOTOGRAMMETRY = 'photogrammetry'
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    tour = models.ForeignKey(Tour, on_delete=models.CASCADE, related_name='scan_assets', help_text='توری که این اطلاعات به آن تعلق دارد.')
    source = models.CharField(max_length=32, choices=Source.choices, help_text='روش یا منبعی که داده هندسی از آن تهیه شده است.')
    storage_key = models.CharField(max_length=700, help_text='مسیر فایل ذخیره\u200cشده در فضای فایل\u200cها.')
    original_filename = models.CharField(max_length=255, help_text='نام فایل اولیه\u200cای که کاربر بارگذاری کرده است.')
    coordinate_unit = models.CharField(max_length=20, default='meter', help_text='واحد اندازه\u200cگیری مختصات فایل ورودی.')
    notes = models.TextField(blank=True, help_text='یادداشت\u200cهای تکمیلی درباره فایل یا عملیات.')
    metadata = models.JSONField(default=dict, help_text='اطلاعات فنی تکمیلی که به فیلدهای ثابت نیاز ندارد.')
    status = models.CharField(max_length=20, default='uploaded', help_text='وضعیت فعلی این مورد در روند کار.')

class BuildingGeometry(TimestampedModel):
    """هندسه مرجع کل ساختمان و سیستم مختصات مشترک بین پلان و مدل سه\u200cبعدی را نگهداری می\u200cکند."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    tour = models.OneToOneField(Tour, on_delete=models.CASCADE, related_name='geometry', help_text='توری که این اطلاعات به آن تعلق دارد.')
    coordinate_system = models.CharField(max_length=40, default='building_local_meters', help_text='سیستم مختصاتی مورد استفاده برای ثبت هندسه؛ واحد استاندارد پروژه متر است.')
    source = models.CharField(max_length=32, default='manual_plan', help_text='روش یا منبعی که داده هندسی از آن تهیه شده است.')
    accuracy_m = models.FloatField(null=True, blank=True, help_text='برآورد خطای اندازه\u200cگیری هندسه، بر حسب متر؛ در صورت نامشخص بودن خالی می\u200cماند.')
    user_reviewed = models.BooleanField(default=False, help_text='مشخص می\u200cکند هندسه توسط کاربر بازبینی و تأیید شده است یا خیر.')
    geometry = models.JSONField(default=dict, help_text='اطلاعات کامل هندسی ساختمان به\u200cصورت داده ساختاریافته.')

class ModelBuildJob(TimestampedModel):
    """وضعیت و نتیجه ساخت مدل سه\u200cبعدی Dollhouse را مدیریت می\u200cکند."""

    class State(models.TextChoices):
        QUEUED = 'queued'
        RUNNING = 'running'
        COMPLETED = 'completed'
        FAILED = 'failed'
        REVIEW = 'review'
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    tour = models.ForeignKey(Tour, on_delete=models.CASCADE, related_name='model_jobs', help_text='توری که این اطلاعات به آن تعلق دارد.')
    state = models.CharField(max_length=20, choices=State.choices, default=State.QUEUED, help_text='وضعیت فعلی فایل یا عملیات.')
    progress = models.PositiveSmallIntegerField(default=0, help_text='درصد پیشرفت عملیات؛ عددی بین صفر تا صد.')
    step = models.CharField(max_length=100, default='queued', help_text='نام مرحله\u200cای که عملیات اکنون در حال انجام آن است.')
    error = models.TextField(blank=True, help_text='شرح خطایی که هنگام اجرای عملیات رخ داده است.')
    source = models.CharField(max_length=32, default='manual_plan', help_text='روش یا منبعی که داده هندسی از آن تهیه شده است.')
    output_key = models.CharField(max_length=700, null=True, blank=True, help_text='مسیر فایل مدل سه\u200cبعدی تولیدشده.')
    metadata = models.JSONField(default=dict, help_text='اطلاعات فنی تکمیلی که به فیلدهای ثابت نیاز ندارد.')

class FloorPlanAsset(TimestampedModel):
    """نسخه\u200cهای پلان هر طبقه و اطلاعات کالیبراسیون مقیاس و چرخش آن را نگهداری می\u200cکند."""

    class State(models.TextChoices):
        UPLOADED = 'uploaded'
        CALIBRATED = 'calibrated'
        SUPERSEDED = 'superseded'
        FAILED = 'failed'
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    floor = models.ForeignKey(Floor, on_delete=models.CASCADE, related_name='plan_assets', help_text='طبقه\u200cای که این فضا یا داده در آن قرار دارد.')
    version = models.PositiveIntegerField(default=1, help_text='شماره نسخه این فایل یا خروجی؛ با هر تولید جدید افزایش می\u200cیابد.')
    state = models.CharField(max_length=20, choices=State.choices, default=State.UPLOADED, help_text='وضعیت فعلی فایل یا عملیات.')
    original_key = models.CharField(max_length=700, help_text='مسیر فایل اصلی پلان بارگذاری\u200cشده.')
    normalized_key = models.CharField(max_length=700, blank=True, help_text='مسیر نسخه اصلاح\u200cشده و استانداردشده فایل پلان.')
    original_filename = models.CharField(max_length=255, help_text='نام فایل اولیه\u200cای که کاربر بارگذاری کرده است.')
    mime_type = models.CharField(max_length=100, blank=True, help_text='نوع محتوای فایل؛ مانند image/png یا image/jpeg.')
    width_px = models.PositiveIntegerField(default=0, help_text='عرض فایل پلان بر حسب پیکسل.')
    height_px = models.PositiveIntegerField(default=0, help_text='ارتفاع فایل پلان بر حسب پیکسل.')
    scale_m_per_px = models.FloatField(null=True, blank=True, help_text='مقیاس پلان؛ مقدار متر متناظر با هر پیکسل.')
    origin_x_m = models.FloatField(default=0, help_text='مختصات مبدأ افقی پلان در فضای ساختمان، بر حسب متر.')
    origin_z_m = models.FloatField(default=0, help_text='مختصات مبدأ عمودی پلان در فضای ساختمان، بر حسب متر.')
    rotation_deg = models.FloatField(default=0, help_text='زاویه چرخش پلان نسبت به محورهای ساختمان، بر حسب درجه.')
    metadata = models.JSONField(default=dict, blank=True, help_text='اطلاعات فنی تکمیلی که به فیلدهای ثابت نیاز ندارد.')
    is_current = models.BooleanField(default=True, help_text='مشخص می\u200cکند این نسخه، نسخه فعال و جاری باشد یا خیر.')

    class Meta:
        ordering = ['-version']
        constraints = [models.UniqueConstraint(fields=['floor', 'version'], name='uq_vt_floor_plan_version')]
        indexes = [models.Index(fields=['floor', 'is_current'], name='vt_plan_floor_current')]

class RoomGeometry(TimestampedModel):
    """ابعاد، محل قرارگیری و شکل هندسی هر اتاق را در مختصات مشترک ساختمان ثبت می\u200cکند."""

    class Source(models.TextChoices):
        MANUAL = 'manual_plan'
        PLAN_TRACE = 'plan_trace'
        DEPTH = 'depth_scan'
        LIDAR = 'lidar_depth'
        PHOTOGRAMMETRY = 'photogrammetry'
        DEPTH_MAP = 'depth_map'
        POINT_CLOUD = 'point_cloud'
        ESTIMATED = 'panorama_estimated'
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    scene = models.OneToOneField(Scene, on_delete=models.CASCADE, related_name='room_geometry', help_text='فضایی که این تصویر یا داده به آن تعلق دارد.')
    coordinate_system = models.CharField(max_length=40, default='building_local_meters', help_text='سیستم مختصاتی مورد استفاده برای ثبت هندسه؛ واحد استاندارد پروژه متر است.')
    origin_x_m = models.FloatField(default=0, help_text='مختصات مبدأ افقی پلان در فضای ساختمان، بر حسب متر.')
    origin_z_m = models.FloatField(default=0, help_text='مختصات مبدأ عمودی پلان در فضای ساختمان، بر حسب متر.')
    width_m = models.FloatField(default=4, help_text='عرض بازشو بر حسب متر.')
    depth_m = models.FloatField(default=4, help_text='اطلاعات تکمیلی این فیلد را مشخص می\u200cکند.')
    height_m = models.FloatField(default=2.8, help_text='ارتفاع بازشو بر حسب متر.')
    rotation_deg = models.FloatField(default=0, help_text='زاویه چرخش پلان نسبت به محورهای ساختمان، بر حسب درجه.')
    polygon = models.JSONField(default=list, blank=True, help_text='نقاط مرزی فضای اتاق در مختصات پلان؛ برای ساخت هندسه دقیق\u200cتر.')
    source = models.CharField(max_length=32, choices=Source.choices, default=Source.MANUAL, help_text='روش یا منبعی که داده هندسی از آن تهیه شده است.')
    confidence = models.FloatField(null=True, blank=True, help_text='میزان اطمینان سامانه به صحت داده؛ عددی بین صفر و یک.')
    is_reviewed = models.BooleanField(default=False, help_text='مشخص می\u200cکند هندسه اتاق توسط کاربر بررسی شده است یا خیر.')
    review_notes = models.TextField(blank=True, help_text='توضیحات کاربر درباره اصلاح یا تأیید هندسه اتاق.')

    class Meta:
        indexes = [models.Index(fields=['coordinate_system', 'source'], name='vt_room_coord_source')]

class WallSegment(TimestampedModel):
    """یک قطعه دیوار را با ابتدا، انتها، ارتفاع، ضخامت و جنس آن تعریف می\u200cکند."""

    class Kind(models.TextChoices):
        INTERIOR = 'interior'
        EXTERIOR = 'exterior'
        PARTITION = 'partition'
        GLASS = 'glass'
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    floor = models.ForeignKey(Floor, on_delete=models.CASCADE, related_name='walls', help_text='طبقه\u200cای که این فضا یا داده در آن قرار دارد.')
    room = models.ForeignKey(Scene, on_delete=models.SET_NULL, null=True, blank=True, related_name='wall_segments', help_text='اتاقی که این دیوار به آن مربوط است؛ ممکن است دیوار مشترک باشد و اتاق مشخصی نداشته باشد.')
    order = models.PositiveIntegerField(default=0, help_text='ترتیب نمایش این مورد در فهرست یا روی نقشه.')
    start_x_m = models.FloatField(help_text='مختصات افقی ابتدای دیوار بر حسب متر.')
    start_z_m = models.FloatField(help_text='مختصات عمودی ابتدای دیوار روی پلان بر حسب متر.')
    end_x_m = models.FloatField(help_text='مختصات افقی انتهای دیوار بر حسب متر.')
    end_z_m = models.FloatField(help_text='مختصات عمودی انتهای دیوار روی پلان بر حسب متر.')
    height_m = models.FloatField(default=2.8, help_text='ارتفاع بازشو بر حسب متر.')
    thickness_m = models.FloatField(default=0.14, help_text='ضخامت دیوار بر حسب متر.')
    kind = models.CharField(max_length=20, choices=Kind.choices, default=Kind.INTERIOR, help_text='نوع نقطه یا بازشو؛ برای تعیین رفتار و ظاهر آن.')
    material = models.CharField(max_length=80, default='plaster', help_text='جنس یا پوشش دیوار؛ برای نمایش در مدل سه\u200cبعدی.')
    metadata = models.JSONField(default=dict, blank=True, help_text='اطلاعات فنی تکمیلی که به فیلدهای ثابت نیاز ندارد.')

    class Meta:
        ordering = ['order']
        indexes = [models.Index(fields=['floor', 'order'], name='vt_wall_floor_order')]

class WallOpening(TimestampedModel):
    """در، پنجره یا بازشوی قرارگرفته روی یک دیوار را تعریف می\u200cکند."""

    class Kind(models.TextChoices):
        DOOR = 'door'
        WINDOW = 'window'
        ARCH = 'arch'
        PASSAGE = 'passage'
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    wall = models.ForeignKey(WallSegment, on_delete=models.CASCADE, related_name='openings', help_text='دیوار میزبان این در، پنجره یا بازشو است.')
    kind = models.CharField(max_length=20, choices=Kind.choices, default=Kind.DOOR, help_text='نوع نقطه یا بازشو؛ برای تعیین رفتار و ظاهر آن.')
    offset_m = models.FloatField(default=0, help_text='فاصله شروع بازشو از ابتدای دیوار، بر حسب متر.')
    width_m = models.FloatField(default=0.9, help_text='عرض بازشو بر حسب متر.')
    height_m = models.FloatField(default=2.1, help_text='ارتفاع بازشو بر حسب متر.')
    sill_height_m = models.FloatField(default=0, help_text='ارتفاع لبه پایینی پنجره از کف، بر حسب متر.')
    metadata = models.JSONField(default=dict, blank=True, help_text='اطلاعات فنی تکمیلی که به فیلدهای ثابت نیاز ندارد.')

class CaptureGuideStep(TimestampedModel):
    """یک زاویه مشخص از راهنمای عکاسی را تعریف می\u200cکند و وضعیت ثبت آن را نگه می\u200cدارد."""

    class State(models.TextChoices):
        PENDING = 'pending'
        CAPTURED = 'captured'
        RETAKE = 'retake'
        SKIPPED = 'skipped'
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    session = models.ForeignKey(CaptureSession, on_delete=models.CASCADE, related_name='guide_steps', help_text='جلسه عکاسی که این تصویر در آن ثبت شده است.')
    sequence = models.PositiveIntegerField(help_text='شماره ترتیب ثبت تصویر در جلسه عکاسی.')
    yaw = models.FloatField(help_text='زاویه افقی ثبت تصویر، بر حسب درجه.')
    pitch = models.FloatField(default=0, help_text='زاویه عمودی ثبت تصویر، بر حسب درجه.')
    label = models.CharField(max_length=120, help_text='عنوان مرحله عکاسی که به کاربر نمایش داده می\u200cشود.')
    required = models.BooleanField(default=True, help_text='مشخص می\u200cکند ثبت این زاویه برای تکمیل تور الزامی است یا خیر.')
    expected_overlap_percent = models.PositiveSmallIntegerField(default=35, help_text='درصد هم\u200cپوشانی مورد انتظار تصویر با تصویر قبلی برای اتصال بهتر.')
    state = models.CharField(max_length=16, choices=State.choices, default=State.PENDING, help_text='وضعیت فعلی فایل یا عملیات.')
    image = models.ForeignKey(CaptureImage, on_delete=models.SET_NULL, null=True, blank=True, related_name='guide_step', help_text='تصویری که برای این مرحله ثبت شده است.')
    guidance = models.JSONField(default=dict, blank=True, help_text='راهنمای تکمیلی این مرحله؛ مانند جهت حرکت یا نکته عکاسی.')

    class Meta:
        ordering = ['sequence']
        constraints = [models.UniqueConstraint(fields=['session', 'sequence'], name='uq_vt_capture_guide_step')]

class PanoramaVersion(TimestampedModel):
    """نسخه\u200cهای مختلف پانورامای هر فضا و وضعیت تأیید یا رد آن\u200cها را نگهداری می\u200cکند."""

    class State(models.TextChoices):
        PROCESSING = 'processing'
        REVIEW = 'review'
        APPROVED = 'approved'
        REJECTED = 'rejected'
        SUPERSEDED = 'superseded'
        FAILED = 'failed'
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    scene = models.ForeignKey(Scene, on_delete=models.CASCADE, related_name='panorama_versions', help_text='فضایی که این تصویر یا داده به آن تعلق دارد.')
    capture_session = models.ForeignKey(CaptureSession, on_delete=models.SET_NULL, null=True, blank=True, related_name='panorama_versions', help_text='جلسه عکاسی که این نسخه پانوراما از آن ساخته شده است.')
    version = models.PositiveIntegerField(default=1, help_text='شماره نسخه این فایل یا خروجی؛ با هر تولید جدید افزایش می\u200cیابد.')
    state = models.CharField(max_length=20, choices=State.choices, default=State.PROCESSING, help_text='وضعیت فعلی فایل یا عملیات.')
    storage_key = models.CharField(max_length=700, help_text='مسیر فایل ذخیره\u200cشده در فضای فایل\u200cها.')
    thumbnail_key = models.CharField(max_length=700, blank=True, help_text='مسیر تصویر بندانگشتی این فضا.')
    projection = models.CharField(max_length=30, default='equirectangular', help_text='نوع تصویرسازی پانوراما؛ معمولاً تصویر کروی بازشده (Equirectangular).')
    width_px = models.PositiveIntegerField(default=0, help_text='عرض فایل پلان بر حسب پیکسل.')
    height_px = models.PositiveIntegerField(default=0, help_text='ارتفاع فایل پلان بر حسب پیکسل.')
    source_image_count = models.PositiveIntegerField(default=0, help_text='تعداد تصاویر اولیه\u200cای که برای ساخت پانوراما استفاده شده\u200cاند.')
    engine = models.CharField(max_length=80, blank=True, help_text='نام ابزار یا موتور پردازشی استفاده\u200cشده.')
    quality_report = models.JSONField(default=dict, blank=True, help_text='گزارش ارزیابی کیفیت خروجی پانوراما.')
    is_current = models.BooleanField(default=True, help_text='مشخص می\u200cکند این نسخه، نسخه فعال و جاری باشد یا خیر.')
    approved_at = models.DateTimeField(null=True, blank=True, help_text='زمان تأیید این نسخه برای انتشار.')

    class Meta:
        ordering = ['-version']
        constraints = [models.UniqueConstraint(fields=['scene', 'version'], name='uq_vt_panorama_version')]
        indexes = [models.Index(fields=['scene', 'is_current'], name='vt_pano_scene_current')]

class ScanProcessingResult(TimestampedModel):
    """نتیجه پردازش یک فایل اسکن، شامل فایل\u200cهای خروجی و شاخص\u200cهای فنی را ثبت می\u200cکند."""

    class State(models.TextChoices):
        QUEUED = 'queued'
        RUNNING = 'running'
        COMPLETED = 'completed'
        FAILED = 'failed'
        REVIEW = 'review'
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    asset = models.OneToOneField(ScanAsset, on_delete=models.CASCADE, related_name='processing_result', help_text='فایل اسکن ورودی که این نتیجه پردازش برای آن ساخته شده است.')
    state = models.CharField(max_length=20, choices=State.choices, default=State.QUEUED, help_text='وضعیت فعلی فایل یا عملیات.')
    engine = models.CharField(max_length=80, blank=True, help_text='نام ابزار یا موتور پردازشی استفاده\u200cشده.')
    normalized_key = models.CharField(max_length=700, blank=True, help_text='مسیر نسخه اصلاح\u200cشده و استانداردشده فایل پلان.')
    preview_key = models.CharField(max_length=700, blank=True, help_text='مسیر فایل پیش\u200cنمایش قابل مشاهده.')
    mesh_key = models.CharField(max_length=700, blank=True, help_text='مسیر فایل مش سه\u200cبعدی تولیدشده.')
    point_count = models.PositiveBigIntegerField(default=0, help_text='تعداد نقاط موجود در ابرنقاط پردازش\u200cشده.')
    bounds = models.JSONField(default=dict, blank=True, help_text='محدوده مکانی داده؛ شامل کمینه و بیشینه مختصات.')
    metrics = models.JSONField(default=dict, blank=True, help_text='شاخص\u200cهای فنی محاسبه\u200cشده در زمان پردازش.')
    error = models.TextField(blank=True, help_text='شرح خطایی که هنگام اجرای عملیات رخ داده است.')

class GeneratedModelAsset(TimestampedModel):
    """فایل\u200cهای مدل سه\u200cبعدی تولیدشده و نسخه\u200cهای مختلف آن\u200cها را نگهداری می\u200cکند."""

    class Format(models.TextChoices):
        GLB = 'glb'
        GLTF = 'gltf'
        OBJ = 'obj'
        PLY = 'ply'
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    tour = models.ForeignKey(Tour, on_delete=models.CASCADE, related_name='generated_models', help_text='توری که این اطلاعات به آن تعلق دارد.')
    version = models.PositiveIntegerField(default=1, help_text='شماره نسخه این فایل یا خروجی؛ با هر تولید جدید افزایش می\u200cیابد.')
    format = models.CharField(max_length=12, choices=Format.choices, default=Format.GLB, help_text='قالب فایل مدل خروجی؛ مانند GLB یا GLTF.')
    storage_key = models.CharField(max_length=700, help_text='مسیر فایل ذخیره\u200cشده در فضای فایل\u200cها.')
    preview_key = models.CharField(max_length=700, blank=True, help_text='مسیر فایل پیش\u200cنمایش قابل مشاهده.')
    source = models.CharField(max_length=32, default='manual_plan', help_text='روش یا منبعی که داده هندسی از آن تهیه شده است.')
    coordinate_system = models.CharField(max_length=40, default='building_local_meters', help_text='سیستم مختصاتی مورد استفاده برای ثبت هندسه؛ واحد استاندارد پروژه متر است.')
    metadata = models.JSONField(default=dict, blank=True, help_text='اطلاعات فنی تکمیلی که به فیلدهای ثابت نیاز ندارد.')
    is_current = models.BooleanField(default=True, help_text='مشخص می\u200cکند این نسخه، نسخه فعال و جاری باشد یا خیر.')

    class Meta:
        ordering = ['-version']
        constraints = [models.UniqueConstraint(fields=['tour', 'version', 'format'], name='uq_vt_model_asset_version')]

class RoomMeasurement(TimestampedModel):
    """اندازه\u200cهای محاسبه\u200cشده یا واردشده برای یک اتاق مانند عرض، ارتفاع و مساحت را ثبت می\u200cکند."""

    class Kind(models.TextChoices):
        WIDTH = 'width'
        DEPTH = 'depth'
        HEIGHT = 'height'
        AREA = 'area'
        PERIMETER = 'perimeter'
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text='شناسه یکتای این رکورد؛ به\u200cصورت خودکار ساخته می\u200cشود.')
    scene = models.ForeignKey(Scene, on_delete=models.CASCADE, related_name='measurements', help_text='فضایی که این تصویر یا داده به آن تعلق دارد.')
    kind = models.CharField(max_length=20, choices=Kind.choices, help_text='نوع نقطه یا بازشو؛ برای تعیین رفتار و ظاهر آن.')
    value = models.FloatField(help_text='مقدار اندازه\u200cگیری\u200cشده.')
    unit = models.CharField(max_length=12, default='m', help_text='واحد مقدار اندازه\u200cگیری\u200cشده؛ مانند متر یا مترمربع.')
    confidence = models.FloatField(null=True, blank=True, help_text='میزان اطمینان سامانه به صحت داده؛ عددی بین صفر و یک.')
    source = models.CharField(max_length=32, default='manual', help_text='روش یا منبعی که داده هندسی از آن تهیه شده است.')
    metadata = models.JSONField(default=dict, blank=True, help_text='اطلاعات فنی تکمیلی که به فیلدهای ثابت نیاز ندارد.')

    class Meta:
        indexes = [models.Index(fields=['scene', 'kind'], name='vt_measure_scene_kind')]
        constraints = [models.UniqueConstraint(fields=['scene', 'kind'], name='uq_vt_room_measurement_kind')]
