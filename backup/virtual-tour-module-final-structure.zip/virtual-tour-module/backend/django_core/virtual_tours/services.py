from django.db import transaction
from .models import Tour, Floor, Scene, BuildingGeometry, RoomGeometry

@transaction.atomic
def save_building_geometry(tour: Tour, payload: dict) -> BuildingGeometry:
    geometry, _ = BuildingGeometry.objects.select_for_update().get_or_create(tour=tour)
    geometry.coordinate_system = payload.get("coordinate_system", "building_local_meters")
    geometry.source = payload.get("source", "manual_plan")
    geometry.accuracy_m = payload.get("accuracy_m")
    geometry.user_reviewed = bool(payload.get("user_reviewed", False))
    if "geometry" in payload:
        geometry.geometry = payload["geometry"]
    geometry.save()
    return geometry

@transaction.atomic
def invalidate_current_models(tour: Tour, reason: str = "Building geometry changed") -> None:
    """با تغییر هندسه اصلی ساختمان، مدل‌های سه‌بعدی قبلی را از حالت جاری خارج می‌کند."""
    from .models import GeneratedModelAsset, BuildingGeometry
    GeneratedModelAsset.objects.filter(tour=tour, is_current=True).update(is_current=False)
    geometry, _ = BuildingGeometry.objects.get_or_create(tour=tour)
    geometry.save(update_fields=["updated_at"])

@transaction.atomic
def refresh_building_review_status(tour: Tour) -> BuildingGeometry:
    geometry, _ = BuildingGeometry.objects.select_for_update().get_or_create(tour=tour)
    active_scenes = list(Scene.objects.filter(tour=tour, active=True).values_list("id", flat=True))
    geometry.user_reviewed = bool(active_scenes) and all(
        RoomGeometry.objects.filter(scene_id=scene_id, is_reviewed=True).exists()
        for scene_id in active_scenes
    )
    geometry.save(update_fields=["user_reviewed", "updated_at"])
    return geometry
