"""آزمون قرارداد ساختار ماژول و توضیحات فارسی فیلدهای مدل."""
import ast
from pathlib import Path


ROOT = Path(__file__).resolve().parents[4]
BACKEND = ROOT / "backend"
MODEL_FILE = BACKEND / "django_core" / "virtual_tours" / "models.py"


def test_backend_contains_only_the_two_requested_module_roots():
    """در ریشه بک‌اند فقط دو مسیر ماژول Django و FastAPI وجود داشته باشد."""
    names = {path.name for path in BACKEND.iterdir()}
    assert names == {"django_core", "fastapi_core"}
    assert (BACKEND / "django_core" / "virtual_tours").is_dir()
    assert (BACKEND / "fastapi_core" / "virtual_tours").is_dir()


def test_every_django_model_field_has_persian_help_text():
    """برای تمام فیلدهای مدل، توضیح فارسی قابل نمایش در پنل مدیریت وجود داشته باشد."""
    tree = ast.parse(MODEL_FILE.read_text(encoding="utf-8"))
    checked = 0
    for model in (node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)):
        for statement in model.body:
            value = statement.value if isinstance(statement, (ast.Assign, ast.AnnAssign)) else None
            if not isinstance(value, ast.Call) or not isinstance(value.func, ast.Attribute):
                continue
            if not value.func.attr.endswith("Field"):
                continue
            help_text = next(
                (item.value.value for item in value.keywords
                 if item.arg == "help_text" and isinstance(item.value, ast.Constant)),
                None,
            )
            assert isinstance(help_text, str) and help_text.strip(), (
                f"فیلد {model.name} توضیح help_text ندارد."
            )
            assert any("\u0600" <= char <= "\u06ff" for char in help_text), (
                f"توضیح فیلد {model.name} فارسی نیست."
            )
            checked += 1
    assert checked >= 150
