"""آزمون‌های خودکار برای بخش storage ماژول تور مجازی."""
import pytest
from fastapi_core.virtual_tours.storage import LocalStorage

@pytest.mark.asyncio
async def test_local_storage_roundtrip(tmp_path, monkeypatch):
    from fastapi_core.virtual_tours.core import config
    monkeypatch.setattr(config.settings, "storage_root", str(tmp_path))
    storage = LocalStorage()
    key = await storage.save(b"virtual-tour", ".bin", "tours/test")
    assert await storage.read(key) == b"virtual-tour"
    await storage.delete(key)
    assert not storage.path(key).exists()


def test_local_storage_rejects_path_traversal(tmp_path, monkeypatch):
    from fastapi_core.virtual_tours.core import config
    monkeypatch.setattr(config.settings, "storage_root", str(tmp_path))
    storage = LocalStorage()
    with pytest.raises(ValueError):
        storage.path("../outside.txt")
