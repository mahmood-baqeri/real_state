"""آزمون‌های خودکار برای بخش glb export ماژول تور مجازی."""
import json
import struct

from fastapi_core.virtual_tours.processing.glb import build_dollhouse_glb, build_pointcloud_glb


def _json_chunk(glb: bytes):
    assert glb[:4] == b"glTF"
    version, total = struct.unpack("<II", glb[4:12])
    assert version == 2 and total == len(glb)
    length, kind = struct.unpack("<I4s", glb[12:20])
    assert kind == b"JSON"
    return json.loads(glb[20:20 + length])


def test_dollhouse_glb_has_rooms_and_mesh_primitives():
    glb, metadata = build_dollhouse_glb(
        [{"id": "floor-1", "elevation_m": 0}],
        [{"id": "room-1", "floor_id": "floor-1", "width_m": 4, "depth_m": 3,
          "height_m": 2.8, "origin_x_m": 0, "origin_z_m": 0}],
    )
    doc = _json_chunk(glb)
    assert len(doc["meshes"][0]["primitives"]) == 2
    assert metadata["room_count"] == 1
    assert metadata["triangle_count"] > 0


def test_dollhouse_glb_supports_wall_openings():
    glb, metadata = build_dollhouse_glb(
        [{"id": "f", "elevation_m": 0}],
        [{"id": "r", "floor_id": "f", "width_m": 4, "depth_m": 3, "height_m": 2.8}],
        [{"floor_id": "f", "room_id": "r", "start_x_m": -2, "start_z_m": 0,
          "end_x_m": 2, "end_z_m": 0, "height_m": 2.8, "thickness_m": .14,
          "openings": [{"offset_m": 1, "width_m": .9, "height_m": 2.1, "sill_height_m": 0}]}],
    )
    assert _json_chunk(glb)["asset"]["version"] == "2.0"
    assert metadata["wall_segment_count"] == 1


def test_pointcloud_glb_is_valid():
    glb, metadata = build_pointcloud_glb([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]])
    doc = _json_chunk(glb)
    assert doc["meshes"][0]["primitives"][0]["mode"] == 0
    assert metadata["point_count"] == 4
