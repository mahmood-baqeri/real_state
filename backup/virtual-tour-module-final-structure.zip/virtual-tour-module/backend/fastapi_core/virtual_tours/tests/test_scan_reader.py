"""آزمون‌های خودکار برای بخش scan reader ماژول تور مجازی."""
import pytest
from fastapi_core.virtual_tours.processing.scan import read_point_cloud


def test_xyz_reader():
    points = read_point_cloud("scan.xyz", b"0 0 0\n1 0 0\n0 1 0\n")
    assert points.shape == (3, 3)


def test_ascii_ply_reader():
    data = (b"ply\nformat ascii 1.0\nelement vertex 3\n"
            b"property float x\nproperty float y\nproperty float z\nend_header\n"
            b"0 0 0\n1 0 0\n0 1 0\n")
    assert read_point_cloud("scan.ply", data).shape == (3, 3)


def test_binary_ply_is_explicitly_rejected():
    data = b"ply\nformat binary_little_endian 1.0\nelement vertex 3\nend_header\n"
    with pytest.raises(ValueError, match="Only ASCII PLY"):
        read_point_cloud("scan.ply", data)


def test_ascii_pcd_reader():
    data = (b"VERSION .7\nFIELDS x y z\nSIZE 4 4 4\nTYPE F F F\nCOUNT 1 1 1\n"
            b"WIDTH 3\nHEIGHT 1\nPOINTS 3\nDATA ascii\n0 0 0\n1 0 0\n0 1 0\n")
    assert read_point_cloud("scan.pcd", data).shape == (3, 3)
