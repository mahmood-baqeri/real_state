"""آزمون‌های خودکار برای بخش image processing ماژول تور مجازی."""
from io import BytesIO
from PIL import Image
import pytest
from fastapi_core.virtual_tours.processing.image_io import normalize_image
from fastapi_core.virtual_tours.processing.quality import analyze_image


def make_image(fmt="JPEG", size=(1600, 1000), color=(120, 130, 140)):
    stream = BytesIO()
    Image.new("RGB", size, color).save(stream, format=fmt)
    return stream.getvalue()


def test_normalize_image_accepts_jpeg_and_removes_non_jpeg_container():
    data, meta = normalize_image(make_image("PNG"))
    assert meta["source_format"] == "PNG"
    assert meta["normalized_format"] == "JPEG"
    assert Image.open(BytesIO(data)).format == "JPEG"


def test_normalize_image_rejects_non_image_bytes():
    with pytest.raises(ValueError):
        normalize_image(b"not-an-image")


def test_normalize_image_rejects_unsupported_format():
    stream = BytesIO()
    Image.new("RGB", (100, 100)).save(stream, format="BMP")
    with pytest.raises(ValueError):
        normalize_image(stream.getvalue())


def test_analyze_image_returns_quality_fields():
    result = analyze_image(make_image())
    assert result["width"] == 1600
    assert result["height"] == 1000
    assert result["status"] in {"accepted", "warning", "reject"}
    assert "blur_score" in result and "warnings" in result


def test_normalize_image_enforces_pixel_limit():
    with pytest.raises(ValueError):
        normalize_image(make_image(size=(1200, 1000)), max_pixels=500_000)
