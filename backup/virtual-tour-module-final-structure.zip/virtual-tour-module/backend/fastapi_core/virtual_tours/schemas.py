"""ساختار داده و قوانین اعتبارسنجی ورودی و خروجی API."""
from uuid import UUID
import math
from typing import Literal
from pydantic import BaseModel, Field, field_validator, model_validator


class TourCreate(BaseModel):
    resource_type: str = Field(default="property", min_length=1, max_length=80)
    resource_id: str = Field(min_length=1, max_length=128)
    tenant_id: str | None = Field(default=None, max_length=128)
    title: str = Field(min_length=1, max_length=255)
    description: str = Field(default="", max_length=10000)

    @field_validator("resource_id", "title")
    @classmethod
    def strip_required(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("This field cannot be blank")
        return value


class TourUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=255)
    description: str | None = Field(default=None, max_length=10000)
    settings: dict | None = None


class FloorCreate(BaseModel):
    title: str = Field(min_length=1, max_length=150)
    order: int = Field(default=0, ge=0, le=1000)
    elevation_m: float = Field(default=0, ge=-100, le=1000)


class FloorUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=150)
    order: int | None = Field(default=None, ge=0, le=1000)
    elevation_m: float | None = Field(default=None, ge=-100, le=1000)


class SceneCreate(BaseModel):
    floor_id: UUID
    title: str = Field(min_length=1, max_length=150)
    room_type: str = Field(default="other", max_length=40)
    description: str = Field(default="", max_length=5000)
    order: int = Field(default=0, ge=0, le=10000)
    width_m: float | None = Field(default=None, gt=0, le=100)
    length_m: float | None = Field(default=None, gt=0, le=100)
    height_m: float = Field(default=2.8, ge=1.8, le=8)


class SceneUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=150)
    description: str | None = Field(default=None, max_length=5000)
    room_type: str | None = Field(default=None, max_length=40)
    order: int | None = Field(default=None, ge=0, le=10000)
    active: bool | None = None
    floor_x: float | None = Field(default=None, ge=0, le=100)
    floor_y: float | None = Field(default=None, ge=0, le=100)
    width_m: float | None = Field(default=None, gt=0, le=100)
    length_m: float | None = Field(default=None, gt=0, le=100)
    height_m: float | None = Field(default=None, ge=1.8, le=8)
    polygon: list[list[float]] | None = None

    @field_validator("polygon")
    @classmethod
    def validate_polygon(cls, value):
        if value is not None and (len(value) < 3 or len(value) > 500 or any(len(p) != 2 for p in value)):
            raise ValueError("Polygon must contain 3 to 500 [x,z] points")
        return value


class LinkCreate(BaseModel):
    source_scene_id: UUID
    target_scene_id: UUID
    yaw: float = Field(default=0, ge=0, le=360)
    pitch: float = Field(default=0, ge=-90, le=90)
    title: str = Field(default="رفتن به فضای بعدی", min_length=1, max_length=120)
    bidirectional: bool = False

    @model_validator(mode="after")
    def different_scenes(self):
        if self.source_scene_id == self.target_scene_id:
            raise ValueError("Source and target scenes must differ")
        return self


class HotspotCreate(BaseModel):
    kind: Literal["info", "navigation"] = "info"
    title: str = Field(min_length=1, max_length=150)
    body: str = Field(default="", max_length=5000)
    yaw: float = Field(default=0, ge=0, le=360)
    pitch: float = Field(default=0, ge=-90, le=90)
    target_scene_id: UUID | None = None

    @model_validator(mode="after")
    def navigation_requires_target(self):
        if self.kind == "navigation" and self.target_scene_id is None:
            raise ValueError("Navigation hotspot requires target_scene_id")
        return self


class DollhouseSavePayload(BaseModel):
    rooms: dict[str, dict] = Field(default_factory=dict)
    wall_height: float = Field(default=2.8, ge=1.8, le=8)
    wall_thickness: float = Field(default=0.14, ge=0.05, le=1)
    style: str = Field(default="warm-modern", max_length=60)

    @field_validator("rooms")
    @classmethod
    def validate_room_layouts(cls, rooms):
        if len(rooms) > 500:
            raise ValueError("A tour cannot contain more than 500 room layouts")
        for room_id, cfg in rooms.items():
            if not isinstance(cfg, dict):
                raise ValueError(f"Room layout {room_id} must be an object")
            for key, low, high, default in (("width", .2, 100, 4), ("depth", .2, 100, 4), ("height", 1.8, 8, 2.8), ("x", -10000, 10000, 0), ("z", -10000, 10000, 0), ("rotation", -360, 360, 0)):
                value = float(cfg.get(key, default))
                if not low <= value <= high:
                    raise ValueError(f"Room layout {room_id}: {key} is outside the allowed range")
        return rooms


class GeometrySourceUpdate(BaseModel):
    source: Literal["manual_plan", "panorama_estimated", "depth_scan", "lidar_depth", "depth_map", "point_cloud", "photogrammetry"]
    accuracy_m: float | None = Field(default=None, gt=0, le=10)
    user_reviewed: bool = False


class StartScenePayload(BaseModel):
    scene_id: UUID


class WallCreate(BaseModel):
    room_id: UUID | None = None
    order: int = Field(default=0, ge=0, le=10000)
    start_x_m: float = Field(ge=-10000, le=10000)
    start_z_m: float = Field(ge=-10000, le=10000)
    end_x_m: float = Field(ge=-10000, le=10000)
    end_z_m: float = Field(ge=-10000, le=10000)
    height_m: float = Field(default=2.8, ge=1.8, le=8)
    thickness_m: float = Field(default=0.14, ge=0.05, le=1)
    kind: Literal["interior", "exterior", "partition", "glass"] = "interior"
    material: str = Field(default="plaster", max_length=80)

    @model_validator(mode="after")
    def nonzero_length(self):
        if math.hypot(self.end_x_m-self.start_x_m,self.end_z_m-self.start_z_m)<0.1:
            raise ValueError("Wall length must be at least 0.1 meters")
        return self


class WallOpeningCreate(BaseModel):
    kind: Literal["door", "window", "arch", "passage"] = "door"
    offset_m: float = Field(default=0, ge=0, le=1000)
    width_m: float = Field(default=0.9, gt=0, le=20)
    height_m: float = Field(default=2.1, gt=0, le=8)
    sill_height_m: float = Field(default=0, ge=0, le=8)


class PlanCalibrationPayload(BaseModel):
    known_distance_m: float = Field(gt=0, le=1000)
    pixel_distance: float = Field(gt=0)
    origin_x_m: float = Field(default=0, ge=-10000, le=10000)
    origin_z_m: float = Field(default=0, ge=-10000, le=10000)
    rotation_deg: float = Field(default=0, ge=-360, le=360)


class RoomGeometryPayload(BaseModel):
    origin_x_m: float = Field(default=0, ge=-10000, le=10000)
    origin_z_m: float = Field(default=0, ge=-10000, le=10000)
    width_m: float = Field(default=4, ge=0.2, le=100)
    depth_m: float = Field(default=4, ge=0.2, le=100)
    height_m: float = Field(default=2.8, ge=1.8, le=8)
    rotation_deg: float = Field(default=0, ge=-360, le=360)
    polygon: list[list[float]] = Field(default_factory=list)
    source: Literal["manual_plan", "plan_trace", "depth_scan", "lidar_depth", "photogrammetry", "depth_map", "point_cloud", "panorama_estimated"] = "manual_plan"
    confidence: float | None = Field(default=None, ge=0, le=1)
    is_reviewed: bool = False
    review_notes: str = Field(default="", max_length=5000)

    @field_validator("polygon")
    @classmethod
    def valid_polygon(cls, value):
        if value and (len(value) < 3 or len(value) > 500 or any(len(p) != 2 for p in value)):
            raise ValueError("Polygon must contain 3 to 500 [x,z] points")
        if value:
            if any(not all(math.isfinite(float(v)) and abs(float(v)) <= 10000 for v in point) for point in value):
                raise ValueError("Polygon coordinates must be finite and within +/-10000 meters")
            area=abs(sum(value[i][0]*value[(i+1)%len(value)][1]-value[(i+1)%len(value)][0]*value[i][1] for i in range(len(value)))/2)
            if area < 0.01:
                raise ValueError("Polygon area is too small or degenerate")
        return value
