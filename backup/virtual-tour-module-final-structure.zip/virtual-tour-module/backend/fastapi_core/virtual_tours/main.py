"""مسیرهای API تور مجازی و نقطه ورود سرویس FastAPI."""
from contextlib import asynccontextmanager
from pathlib import Path
from uuid import UUID
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, RedirectResponse
from asgiref.sync import sync_to_async
from django.db import transaction
from django.db.models import Q
from fastapi_core.virtual_tours.django_runtime import *  # noqa: F401,F403 - initializes Django before model imports
from virtual_tours.models import Tour, Floor, Scene, CaptureSession, CaptureImage, SceneLink, Hotspot, ProcessingJob, ScanAsset, BuildingGeometry, FloorPlanAsset, RoomGeometry, WallSegment, WallOpening, CaptureGuideStep, PanoramaVersion, GeneratedModelAsset, RoomMeasurement, ScanProcessingResult, ModelBuildJob
from virtual_tours.services import save_building_geometry, invalidate_current_models, refresh_building_review_status
from fastapi_core.virtual_tours.core.config import settings
from fastapi_core.virtual_tours.schemas import TourCreate, TourUpdate, FloorCreate, FloorUpdate, SceneCreate, SceneUpdate, LinkCreate, HotspotCreate, DollhouseSavePayload, GeometrySourceUpdate, StartScenePayload, RoomGeometryPayload, PlanCalibrationPayload, WallCreate, WallOpeningCreate
from fastapi_core.virtual_tours.storage import storage
from fastapi_core.virtual_tours.processing.quality import analyze_image
from fastapi_core.virtual_tours.processing.image_io import normalize_image

@asynccontextmanager
async def lifespan(app):
    yield
app=FastAPI(title="Virtual Tour Processing API", version="2.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=[x.strip() for x in settings.cors_origins.split(',')], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def _tour_dict(t):
    return {"id":str(t.id),"title":t.title,"description":t.description,"status":t.status,"resource_type":t.resource_type,"resource_id":t.resource_id,"updated_at":t.updated_at.isoformat()}
def _scene_dict(s):
    return {"id":str(s.id),"floor_id":str(s.floor_id),"title":s.title,"room_type":s.room_type,"description":s.description,"order":s.order,"active":s.active,"start_scene":s.start_scene,"floor_x":s.floor_x,"floor_y":s.floor_y,"initial_yaw":s.initial_yaw,"initial_pitch":s.initial_pitch,"width_m":s.width_m,"length_m":s.length_m,"height_m":s.height_m,"panorama_url":f"{settings.public_base_url}/media/{s.panorama_key}" if s.panorama_key else None,"thumbnail_url":f"{settings.public_base_url}/media/{s.thumbnail_key}" if s.thumbnail_key else None}

@app.get('/health')
def health(): return {"status":"ok","service":"virtual-tour-processing-api","database_owner":"django"}
@app.get('/ready')
def readiness():
    from django.db import connection
    checks={"database":False,"redis":False}
    try:
        with connection.cursor() as c: c.execute('SELECT 1'); checks['database']=True
    except Exception: pass
    try:
        from redis import Redis
        r=Redis.from_url(settings.redis_url,socket_connect_timeout=2); checks['redis']=bool(r.ping()); r.close()
    except Exception: pass
    return {"status":"ready" if all(checks.values()) else "degraded","checks":checks}

@app.get('/api/v1/tours')
def list_tours(limit:int=50): return [_tour_dict(t) for t in Tour.objects.order_by('-updated_at')[:max(1,min(limit,100))]]
@app.post('/api/v1/tours',status_code=201)
def create_tour(payload:TourCreate):
    t=Tour.objects.create(**payload.model_dump()); return {"id":str(t.id),"title":t.title,"status":t.status}
@app.get('/api/v1/tours/{tour_id}')
def get_tour(tour_id:UUID):
    t=Tour.objects.filter(pk=tour_id).first()
    if not t: raise HTTPException(404,'Tour not found')
    floors=list(t.floors.all()); scenes=list(t.scenes.all()); links=list(SceneLink.objects.filter(tour=t).select_related('source_scene','target_scene'))
    latest={}
    for j in ProcessingJob.objects.filter(tour=t).order_by('-created_at'): latest.setdefault(j.scene_id,j)
    return {**_tour_dict(t),"floors":[{"id":str(f.id),"title":f.title,"order":f.order,"plan_key":f.plan_key,"plan_url":f"{settings.public_base_url}/media/{f.plan_key}" if f.plan_key else None,"elevation_m":f.elevation_m} for f in floors],"scenes":[{**_scene_dict(s),"panorama_review_required":bool(latest.get(s.id) and latest[s.id].state=='review'),"panorama_job_state":latest[s.id].state if latest.get(s.id) else None} for s in scenes],"links":[{"id":str(l.id),"source_scene_id":str(l.source_scene_id),"target_scene_id":str(l.target_scene_id),"yaw":l.yaw,"pitch":l.pitch,"title":l.title,"bidirectional":l.bidirectional} for l in links]}
@app.patch('/api/v1/tours/{tour_id}')
def update_tour(tour_id:UUID,payload:TourUpdate):
    t=Tour.objects.filter(pk=tour_id).first()
    if not t: raise HTTPException(404,'Tour not found')
    for k,v in payload.model_dump(exclude_unset=True,exclude_none=True).items(): setattr(t,k,v)
    t.save(); return _tour_dict(t)
@app.delete('/api/v1/tours/{tour_id}')
async def delete_tour(tour_id:UUID):
    t=await sync_to_async(Tour.objects.filter(pk=tour_id).first,thread_sensitive=True)()
    if not t: raise HTTPException(404,'Tour not found')
    def collect_and_delete():
        keys=[]
        keys.extend(CaptureImage.objects.filter(scene__tour=t).values_list('storage_key',flat=True))
        keys.extend(ScanAsset.objects.filter(tour=t).values_list('storage_key',flat=True))
        keys.extend(PanoramaVersion.objects.filter(scene__tour=t).values_list('storage_key',flat=True))
        for panorama_key,thumb_key in Scene.objects.filter(tour=t).values_list('panorama_key','thumbnail_key'):
            keys.extend([panorama_key,thumb_key])
        keys.extend(GeneratedModelAsset.objects.filter(tour=t).values_list('storage_key',flat=True))
        for model,field in [(PanoramaVersion,'thumbnail_key'),(GeneratedModelAsset,'preview_key')]:
            keys.extend(model.objects.filter(scene__tour=t).exclude(**{field:''}).values_list(field,flat=True) if model is PanoramaVersion else model.objects.filter(tour=t).exclude(**{field:''}).values_list(field,flat=True))
        for f in Floor.objects.filter(tour=t):
            if f.plan_key: keys.append(f.plan_key)
        for p in FloorPlanAsset.objects.filter(floor__tour=t): keys.extend([p.original_key,p.normalized_key])
        for r in ScanProcessingResult.objects.filter(asset__tour=t): keys.extend([r.normalized_key,r.preview_key,r.mesh_key])
        t.delete()
        return list({k for k in keys if k})
    keys=await sync_to_async(collect_and_delete,thread_sensitive=True)()
    for key in keys:
        try: await storage.delete(key)
        except (ValueError,OSError): pass
    return {"status":"deleted","assets_removed":len(keys)}

@app.post('/api/v1/tours/{tour_id}/floors',status_code=201)
def create_floor(tour_id:UUID,payload:FloorCreate):
    t=Tour.objects.filter(pk=tour_id).first()
    if not t: raise HTTPException(404,'Tour not found')
    f=Floor.objects.create(tour=t,**payload.model_dump()); return {"id":str(f.id),"title":f.title}
@app.patch('/api/v1/floors/{floor_id}')
def update_floor(floor_id:UUID,payload:FloorUpdate):
    f=Floor.objects.filter(pk=floor_id).first()
    if not f: raise HTTPException(404,'Floor not found')
    changed=payload.model_dump(exclude_unset=True,exclude_none=True)
    for k,v in changed.items(): setattr(f,k,v)
    f.save()
    if 'elevation_m' in changed: invalidate_current_models(f.tour, 'Floor elevation changed')
    return {"id":str(f.id),"title":f.title}
@app.delete('/api/v1/floors/{floor_id}')
async def delete_floor(floor_id:UUID):
    f=await sync_to_async(Floor.objects.filter(pk=floor_id).select_related('tour').first,thread_sensitive=True)()
    if not f: raise HTTPException(404,'Floor not found')
    if await sync_to_async(f.scenes.exists,thread_sensitive=True)(): raise HTTPException(409,'ابتدا فضاهای این طبقه را حذف یا به طبقه دیگری منتقل کنید.')
    keys=await sync_to_async(lambda:list(FloorPlanAsset.objects.filter(floor=f).values_list('original_key','normalized_key')),thread_sensitive=True)()
    if f.plan_key: keys.append((f.plan_key,None))
    await sync_to_async(lambda:(invalidate_current_models(f.tour, 'Floor deleted'),f.delete()),thread_sensitive=True)()
    for pair in keys:
        for key in pair:
            if key:
                try: await storage.delete(key)
                except (ValueError,OSError): pass
    return {"status":"deleted"}
@app.post('/api/v1/tours/{tour_id}/scenes',status_code=201)
@transaction.atomic
def create_scene(tour_id:UUID,payload:SceneCreate):
    t=Tour.objects.filter(pk=tour_id).first(); f=Floor.objects.filter(pk=payload.floor_id,tour_id=tour_id).first()
    if not t or not f: raise HTTPException(400,'Floor does not belong to this tour')
    s=Scene.objects.create(tour=t,**payload.model_dump()); invalidate_current_models(t, 'Room added'); return {"id":str(s.id),"title":s.title}
@app.get('/api/v1/scenes/{scene_id}')
def get_scene(scene_id:UUID):
    s=Scene.objects.filter(pk=scene_id).first()
    if not s: raise HTTPException(404,'Scene not found')
    return _scene_dict(s)
@app.patch('/api/v1/scenes/{scene_id}')
@transaction.atomic
def update_scene(scene_id:UUID,payload:SceneUpdate):
    s=Scene.objects.filter(pk=scene_id).first()
    if not s: raise HTTPException(404,'Scene not found')
    for k,v in payload.model_dump(exclude_unset=True,exclude_none=True).items(): setattr(s,k,v)
    s.save(); invalidate_current_models(s.tour, 'Room geometry or metadata changed'); return _scene_dict(s)
@app.delete('/api/v1/scenes/{scene_id}')
async def delete_scene(scene_id:UUID):
    s=await sync_to_async(Scene.objects.filter(pk=scene_id).first,thread_sensitive=True)()
    if not s: raise HTTPException(404,'Scene not found')
    @transaction.atomic
    def remove_db():
        keys=list(CaptureImage.objects.filter(scene=s).values_list('storage_key',flat=True))
        keys+=list(PanoramaVersion.objects.filter(scene=s).values_list('storage_key',flat=True))
        keys+=list(PanoramaVersion.objects.filter(scene=s).values_list('thumbnail_key',flat=True))
        keys += [k for k in [s.panorama_key,s.thumbnail_key] if k]
        tour=s.tour; s.delete(); invalidate_current_models(tour, 'Room deleted'); return list({k for k in keys if k})
    keys=await sync_to_async(remove_db,thread_sensitive=True)()
    for key in keys:
        try: await storage.delete(key)
        except (ValueError,OSError): pass
    return {"status":"deleted","assets_removed":len(keys)}
@app.post('/api/v1/tours/{tour_id}/start-scene')
def set_start_scene(tour_id:UUID,payload:StartScenePayload):
    s=Scene.objects.filter(pk=payload.scene_id,tour_id=tour_id).first()
    if not s: raise HTTPException(404,'Scene not found')
    with transaction.atomic():
        Scene.objects.filter(tour_id=tour_id).update(start_scene=False); s.start_scene=True; s.save(update_fields=['start_scene','updated_at'])
    return {"status":"saved","scene_id":str(s.id)}

CAPTURE_PLAN={"minimum_images":8,"recommended_images":12,"overlap_percent":35,"steps":[{"yaw":i*30,"pitch":0,"label":f"عکس افقی {i+1}"} for i in range(12)]+[{"yaw":0,"pitch":55,"label":"سقف"},{"yaw":0,"pitch":-55,"label":"کف"}]}
@app.post('/api/v1/scenes/{scene_id}/capture-sessions',status_code=201)
@transaction.atomic
def create_capture(scene_id:UUID):
    s=Scene.objects.filter(pk=scene_id).first()
    if not s: raise HTTPException(404,'Scene not found')
    s.tour.status='capturing'; s.tour.save(update_fields=['status','updated_at'])
    cs=CaptureSession.objects.create(tour=s.tour,scene=s,status='capturing',plan=CAPTURE_PLAN,device={"capture_mode":"guided_mobile","coordinate_reference":"session_relative_yaw"})
    CaptureGuideStep.objects.bulk_create([CaptureGuideStep(session=cs,sequence=i,yaw=step["yaw"],pitch=step["pitch"],label=step["label"],required=(i<12),expected_overlap_percent=CAPTURE_PLAN["overlap_percent"],guidance={"keep_position_fixed":True,"recommended_camera_height_m":1.5}) for i,step in enumerate(CAPTURE_PLAN["steps"])])
    return {"id":str(cs.id),"plan":cs.plan,"guide_steps":[{"sequence":x.sequence,"yaw":x.yaw,"pitch":x.pitch,"label":x.label,"required":x.required,"state":x.state} for x in cs.guide_steps.all()]}
@app.post('/api/v1/scenes/{scene_id}/retake',status_code=201)
def retake_scene(scene_id:UUID): return create_capture(scene_id)
@app.post('/api/v1/capture-sessions/{session_id}/images',status_code=201)
async def upload_capture(session_id:UUID,sequence:int=Form(...),yaw:float|None=Form(None),pitch:float|None=Form(None),file:UploadFile=File(...)):
    cs=await sync_to_async(CaptureSession.objects.select_related('tour','scene').filter(pk=session_id).first,thread_sensitive=True)()
    if not cs: raise HTTPException(404,'Capture session not found')
    if sequence<0: raise HTTPException(400,'Sequence must be zero or greater')
    data=await file.read(settings.max_upload_bytes+1)
    if len(data)>settings.max_upload_bytes: raise HTTPException(413,'File is too large')
    try:
        normalized,meta=normalize_image(data); quality=analyze_image(normalized); quality['source_format']=meta['source_format']
    except ValueError as e: raise HTTPException(400,str(e))
    phash=quality.get('perceptual_hash')
    if phash:
        previous=await sync_to_async(lambda:list(CaptureImage.objects.filter(session=cs).exclude(sequence=sequence).values_list('id','analysis')),thread_sensitive=True)()
        for previous_id,analysis in previous:
            old_hash=(analysis or {}).get('perceptual_hash')
            if old_hash and len(old_hash)==len(phash) and (int(old_hash,16)^int(phash,16)).bit_count()<=4:
                quality['status']='warning'; quality['duplicate_candidate']=str(previous_id); quality.setdefault('warnings',[]).append('این تصویر از نظر بصری بسیار شبیه یکی از تصاویر قبلی است؛ در صورت امکان زاویه را تغییر دهید و دوباره ثبت کنید.')
                break
    key=await storage.save(normalized,'.jpg',f'tours/{cs.tour_id}/captures/{cs.id}')
    name=Path(file.filename or 'capture').name[:255] or 'capture'
    @transaction.atomic
    def persist():
        im=CaptureImage.objects.filter(session=cs,sequence=sequence).first(); old_key=None
        if im:
            old_key=im.storage_key; im.storage_key=key; im.filename=name; im.size=len(normalized); im.width=quality['width']; im.height=quality['height']; im.status=quality['status']; im.analysis=quality; im.yaw=yaw; im.pitch=pitch; im.save()
        else:
            im=CaptureImage.objects.create(session=cs,scene=cs.scene,storage_key=key,filename=name,sequence=sequence,size=len(normalized),width=quality['width'],height=quality['height'],status=quality['status'],analysis=quality,yaw=yaw,pitch=pitch)
        step=CaptureGuideStep.objects.filter(session=cs,sequence=sequence).first()
        if step:
            step.state='retake' if quality['status']=='reject' else 'captured'; step.image=im; step.save(update_fields=['state','image','updated_at'])
        return {"id":str(im.id),"status":im.status,"quality":quality,"storage_key":key,"replaced_storage_key":old_key}
    result=await sync_to_async(persist,thread_sensitive=True)()
    if result.get('replaced_storage_key'):
        try: await storage.delete(result['replaced_storage_key'])
        except (ValueError,OSError): pass
    return result
@app.get('/api/v1/capture-sessions/{session_id}/guide')
def get_capture_guide(session_id:UUID):
    session=CaptureSession.objects.filter(pk=session_id).first()
    if not session: raise HTTPException(404,'Capture session not found')
    return {"session_id":str(session.id),"status":session.status,"plan":session.plan,"steps":[{"sequence":x.sequence,"yaw":x.yaw,"pitch":x.pitch,"label":x.label,"required":x.required,"state":x.state,"image_id":str(x.image_id) if x.image_id else None} for x in session.guide_steps.all()]}

@app.post('/api/v1/capture-sessions/{session_id}/complete')
def complete_capture_session(session_id:UUID):
    session=CaptureSession.objects.filter(pk=session_id).first()
    if not session: raise HTTPException(404,'Capture session not found')
    usable=session.images.filter(status__in=['accepted','warning']).count()
    required=session.guide_steps.filter(required=True).count()
    captured=session.guide_steps.filter(required=True,state='captured').count()
    if usable<8: raise HTTPException(409,'حداقل ۸ تصویر قابل‌استفاده برای پایان عکاسی لازم است.')
    session.status='ready' if captured>=required else 'needs_retake'; session.save(update_fields=['status','updated_at'])
    return {"session_id":str(session.id),"status":session.status,"usable_images":usable,"required_steps":required,"captured_required_steps":captured}

@app.get('/api/v1/scenes/{scene_id}/images')
def list_scene_images(scene_id:UUID): return [{"id":str(x.id),"filename":x.filename,"sequence":x.sequence,"status":x.status,"analysis":x.analysis} for x in CaptureImage.objects.filter(scene_id=scene_id).order_by('sequence')]
@app.get('/api/v1/capture-sessions/{session_id}/images')
def list_capture_images(session_id:UUID): return [{"id":str(x.id),"filename":x.filename,"sequence":x.sequence,"status":x.status,"analysis":x.analysis} for x in CaptureImage.objects.filter(session_id=session_id).order_by('sequence')]
@app.delete('/api/v1/images/{image_id}')
async def delete_image(image_id:UUID):
    im=await sync_to_async(CaptureImage.objects.filter(pk=image_id).first,thread_sensitive=True)()
    if not im: raise HTTPException(404,'Image not found')
    key=im.storage_key
    await sync_to_async(lambda:CaptureGuideStep.objects.filter(image=im).update(state='pending',image=None),thread_sensitive=True)()
    await sync_to_async(im.delete,thread_sensitive=True)()
    try: await storage.delete(key)
    except (ValueError,OSError): pass
    return {"status":"deleted"}

@app.post('/api/v1/scenes/{scene_id}/process',status_code=202)
def process_scene_api(scene_id:UUID):
    s=Scene.objects.filter(pk=scene_id).select_related('tour').first()
    if not s: raise HTTPException(404,'Scene not found')
    active=ProcessingJob.objects.filter(scene=s,state__in=['queued','running']).order_by('-created_at').first()
    if active: return {"job_id":str(active.id),"status":active.state,"progress":active.progress,"status_url":f"/api/v1/jobs/{active.id}"}
    cs=CaptureSession.objects.filter(scene=s).order_by('-created_at').first()
    if not cs: raise HTTPException(400,'No capture session found')
    imgs=CaptureImage.objects.filter(session=cs,status__in=['accepted','warning'])
    if imgs.count()<2: raise HTTPException(400,'در آخرین نوبت عکاسی حداقل دو تصویر قابل استفاده لازم است')
    job=ProcessingJob.objects.create(tour=s.tour,scene=s,result={"capture_session_id":str(cs.id)})
    s.tour.status='processing'; s.tour.save(update_fields=['status','updated_at'])
    try:
        from fastapi_core.virtual_tours.worker import process_scene
        process_scene.delay(str(job.id))
    except Exception as e:
        job.state='failed'; job.step='queue_failed'; job.error=str(e); job.save(); raise HTTPException(503,'Processing queue is unavailable')
    return {"job_id":str(job.id),"status":job.state,"progress":0,"status_url":f"/api/v1/jobs/{job.id}"}
@app.get('/api/v1/jobs/{job_id}')
def get_job(job_id:UUID):
    j=ProcessingJob.objects.filter(pk=job_id).first()
    if not j: raise HTTPException(404,'Job not found')
    return {"id":str(j.id),"state":j.state,"status":j.state,"progress":j.progress,"step":j.step,"error":j.error,"result":j.result}
@app.get('/api/v1/scenes/{scene_id}/jobs')
def list_scene_jobs(scene_id:UUID): return [{"id":str(j.id),"state":j.state,"progress":j.progress,"step":j.step,"error":j.error} for j in ProcessingJob.objects.filter(scene_id=scene_id).order_by('-created_at')]

@app.post('/api/v1/tours/{tour_id}/links',status_code=201)
def create_link(tour_id:UUID,payload:LinkCreate):
    a=Scene.objects.filter(pk=payload.source_scene_id,tour_id=tour_id).first(); b=Scene.objects.filter(pk=payload.target_scene_id,tour_id=tour_id).first()
    if not a or not b: raise HTTPException(400,'Both scenes must belong to this tour')
    l=SceneLink.objects.create(tour=a.tour,source_scene=a,target_scene=b,**payload.model_dump(exclude={'source_scene_id','target_scene_id'})); return {"id":str(l.id)}
@app.delete('/api/v1/links/{link_id}')
def delete_link(link_id:UUID):
    n,_=SceneLink.objects.filter(pk=link_id).delete()
    if not n: raise HTTPException(404,'Link not found')
    return {"status":"deleted"}
@app.post('/api/v1/scenes/{scene_id}/hotspots',status_code=201)
def create_hotspot(scene_id:UUID,payload:HotspotCreate):
    s=Scene.objects.filter(pk=scene_id).first()
    if not s: raise HTTPException(404,'Scene not found')
    data=payload.model_dump()
    target_id=data.get('target_scene_id')
    if target_id and not Scene.objects.filter(pk=target_id,tour_id=s.tour_id).exists(): raise HTTPException(422,'Target scene must belong to the same tour')
    h=Hotspot.objects.create(scene=s,**data); return {"id":str(h.id)}
@app.get('/api/v1/scenes/{scene_id}/hotspots')
def list_scene_hotspots(scene_id:UUID): return [{"id":str(h.id),"kind":h.kind,"title":h.title,"body":h.body,"yaw":h.yaw,"pitch":h.pitch,"target_scene_id":str(h.target_scene_id) if h.target_scene_id else None} for h in Hotspot.objects.filter(scene_id=scene_id)]
@app.get('/api/v1/tours/{tour_id}/hotspots')
def list_tour_hotspots(tour_id:UUID): return [{"id":str(h.id),"scene_id":str(h.scene_id),"kind":h.kind,"title":h.title,"body":h.body,"yaw":h.yaw,"pitch":h.pitch,"target_scene_id":str(h.target_scene_id) if h.target_scene_id else None} for h in Hotspot.objects.filter(scene__tour_id=tour_id)]
@app.patch('/api/v1/hotspots/{hotspot_id}')
def update_hotspot(hotspot_id:UUID,payload:dict):
    h=Hotspot.objects.filter(pk=hotspot_id).first()
    if not h: raise HTTPException(404,'Hotspot not found')
    for k in ('kind','title','body','yaw','pitch','target_scene_id'):
        if k in payload: setattr(h,k,payload[k])
    if h.kind not in {'info','navigation'}: raise HTTPException(422,'Invalid hotspot kind')
    if not h.title.strip(): raise HTTPException(422,'Hotspot title cannot be blank')
    if not (0<=h.yaw<=360 and -90<=h.pitch<=90): raise HTTPException(422,'Invalid hotspot yaw/pitch')
    if h.target_scene_id and not Scene.objects.filter(pk=h.target_scene_id,tour_id=h.scene.tour_id).exists(): raise HTTPException(422,'Target scene must belong to the same tour')
    if h.kind=='navigation' and not h.target_scene_id: raise HTTPException(422,'Navigation hotspot requires a target scene')
    h.save(); return {"id":str(h.id)}
@app.delete('/api/v1/hotspots/{hotspot_id}')
def delete_hotspot(hotspot_id:UUID):
    n,_=Hotspot.objects.filter(pk=hotspot_id).delete()
    if not n: raise HTTPException(404,'Hotspot not found')
    return {"status":"deleted"}
@app.post('/api/v1/tours/{tour_id}/publish')
def publish(tour_id:UUID):
    t=Tour.objects.filter(pk=tour_id).first()
    if not t: raise HTTPException(404,'Tour not found')
    active=list(t.scenes.filter(active=True))
    if not active: raise HTTPException(400,'At least one active room is required')
    missing=[s.title for s in active if not s.panorama_key]
    if missing: raise HTTPException(409,'اتاق‌های فاقد پانوراما: '+', '.join(missing))
    pending=[s.title for s in active if not PanoramaVersion.objects.filter(scene=s,is_current=True,state='approved').exists()]
    if pending: raise HTTPException(409,'پانورامای این اتاق‌ها هنوز تأیید نشده است: '+', '.join(pending))
    t.status='published'; t.save(update_fields=['status','updated_at']); return {"status":"published","room_count":len(active)}

@app.get('/api/v1/tours/{tour_id}/dollhouse')
def get_dollhouse(tour_id:UUID):
    t=Tour.objects.filter(pk=tour_id).first()
    if not t: raise HTTPException(404,'Tour not found')
    floors=list(t.floors.all()); scenes=list(t.scenes.filter(active=True)); geom=BuildingGeometry.objects.filter(tour=t).first(); saved=(geom.geometry if geom else {})
    room_configs=saved.get('rooms',{}) if isinstance(saved,dict) else {}
    rooms=[]
    for i,s in enumerate(scenes):
        cfg=room_configs.get(str(s.id),{})
        room_geom=RoomGeometry.objects.filter(scene=s).first()
        width=float(room_geom.width_m if room_geom else cfg.get('width',s.width_m or 4.2)); depth=float(room_geom.depth_m if room_geom else cfg.get('depth',s.length_m or 3.6)); height=float(room_geom.height_m if room_geom else cfg.get('height',s.height_m or 2.8))
        x=float(room_geom.origin_x_m if room_geom else cfg.get('x', ((s.floor_x-50)*0.18 if s.floor_x is not None else (i%3)*5.0))); z=float(room_geom.origin_z_m if room_geom else cfg.get('z', ((s.floor_y-50)*0.18 if s.floor_y is not None else (i//3)*4.5)))
        rotation=float(room_geom.rotation_deg if room_geom else cfg.get('rotation',0)); polygon=room_geom.polygon if room_geom else s.polygon
        rooms.append({"id":str(s.id),"floor_id":str(s.floor_id),"floor_title":s.floor.title,"title":s.title,"room_type":s.room_type,"description":s.description,"x":x,"z":z,"width":width,"depth":depth,"height":height,"rotation":rotation,"polygon":polygon,"geometry_reviewed":bool(room_geom and room_geom.is_reviewed),"panorama_url":f"{settings.public_base_url}/media/{s.panorama_key}" if s.panorama_key else None,"thumbnail_url":f"{settings.public_base_url}/media/{s.thumbnail_key}" if s.thumbnail_key else None})
    return {"tour_id":str(t.id),"title":t.title,"style":saved.get('style','warm-modern'),"wall_height":float(saved.get('wall_height',2.8)),"wall_thickness":float(saved.get('wall_thickness',0.14)),"floors":[{"id":str(f.id),"title":f.title,"elevation":f.elevation_m,"plan_url":f"{settings.public_base_url}/media/{f.plan_key}" if f.plan_key else None} for f in floors],"rooms":rooms,"links":[{"source_scene_id":str(l.source_scene_id),"target_scene_id":str(l.target_scene_id),"title":l.title} for l in SceneLink.objects.filter(tour=t)],"geometry_source":geom.source if geom else 'manual_plan','needs_dimensions_review':not bool(geom and geom.user_reviewed),'geometry':{"source":geom.source,"accuracy_m":geom.accuracy_m,"reviewed":geom.user_reviewed} if geom else {"source":"manual_plan","accuracy_m":None,"reviewed":False},"scan_assets":[{"id":str(a.id),"filename":a.original_filename,"source":a.source,"coordinate_unit":a.coordinate_unit,"notes":a.notes,"status":a.status,"size":(a.metadata or {}).get('size',0),"processing_state":(a.processing_result.state if hasattr(a,'processing_result') else None),"point_count":(a.processing_result.point_count if hasattr(a,'processing_result') else 0),"preview_url":(f"{settings.public_base_url}/media/{a.processing_result.preview_key}" if hasattr(a,'processing_result') and a.processing_result.preview_key else None),"processing_error":(a.processing_result.error if hasattr(a,'processing_result') else '')} for a in t.scan_assets.all()],"walls":[{"id":str(w.id),"floor_id":str(w.floor_id),"room_id":str(w.room_id) if w.room_id else None,"start_x_m":w.start_x_m,"start_z_m":w.start_z_m,"end_x_m":w.end_x_m,"end_z_m":w.end_z_m,"height_m":w.height_m,"thickness_m":w.thickness_m,"kind":w.kind,"material":w.material,"openings":[{"id":str(o.id),"kind":o.kind,"offset_m":o.offset_m,"width_m":o.width_m,"height_m":o.height_m,"sill_height_m":o.sill_height_m} for o in w.openings.all()]} for w in WallSegment.objects.filter(floor__tour=t).filter(Q(room__active=True)|Q(room__isnull=True)).prefetch_related('openings')],"model_asset":({"id":str(GeneratedModelAsset.objects.filter(tour=t,format='glb',is_current=True).first().id),"url":f"{settings.public_base_url}/media/{GeneratedModelAsset.objects.filter(tour=t,format='glb',is_current=True).first().storage_key}"} if GeneratedModelAsset.objects.filter(tour=t,format='glb',is_current=True).exists() else None)}
@app.put('/api/v1/tours/{tour_id}/dollhouse')
@transaction.atomic
def save_dollhouse(tour_id:UUID,payload:DollhouseSavePayload):
    t=Tour.objects.filter(pk=tour_id).first()
    if not t: raise HTTPException(404,'Tour not found')
    known={str(x) for x in t.scenes.values_list('id',flat=True)}; unknown=set(payload.rooms.keys())-known
    if unknown: raise HTTPException(400,'Unknown room IDs: '+', '.join(sorted(unknown)))
    g=save_building_geometry(t,{"source":"manual_plan","user_reviewed":True,"geometry":{"rooms":payload.rooms,"wall_height":payload.wall_height,"wall_thickness":payload.wall_thickness,"style":payload.style}})
    for scene_id,cfg in payload.rooms.items():
        scene=Scene.objects.get(pk=scene_id,tour=t)
        RoomGeometry.objects.update_or_create(scene=scene,defaults={"origin_x_m":float(cfg.get('x',0)),"origin_z_m":float(cfg.get('z',0)),"width_m":float(cfg.get('width',scene.width_m or 4)),"depth_m":float(cfg.get('depth',scene.length_m or 4)),"height_m":float(cfg.get('height',scene.height_m or 2.8)),"rotation_deg":float(cfg.get('rotation',0)),"source":"manual_plan","is_reviewed":True})
    refresh_building_review_status(t)
    invalidate_current_models(t, 'Dollhouse layout changed')
    return {"status":"saved","rooms_saved":len(payload.rooms),"geometry_id":str(g.id)}
@app.put('/api/v1/tours/{tour_id}/geometry-source')
def update_geometry_source(tour_id:UUID,payload:GeometrySourceUpdate):
    t=Tour.objects.filter(pk=tour_id).first()
    if not t: raise HTTPException(404,'Tour not found')
    payload=payload.model_dump()
    source=payload.get('source','manual_plan')
    g=save_building_geometry(t,{"source":source,"accuracy_m":payload.get('accuracy_m'),"user_reviewed":payload.get('user_reviewed',False)})
    invalidate_current_models(t, 'Building geometry source changed')
    return {"status":"saved","geometry":{"source":g.source,"accuracy_m":g.accuracy_m,"reviewed":g.user_reviewed}}
ALLOWED_SCAN_SUFFIXES={'.ply','.pcd','.xyz','.pts','.las','.laz','.bin','.npy','.npz','.json','.zip','.png','.tif','.tiff'}
@app.post('/api/v1/tours/{tour_id}/scan-assets',status_code=201)
async def upload_scan_asset(tour_id:UUID,source:str=Form(...),coordinate_unit:str=Form('meter'),notes:str=Form(''),file:UploadFile=File(...)):
    t=await sync_to_async(Tour.objects.filter(pk=tour_id).first,thread_sensitive=True)()
    if not t: raise HTTPException(404,'Tour not found')
    suffix=Path(file.filename or '').suffix.lower()
    if suffix not in ALLOWED_SCAN_SUFFIXES: raise HTTPException(415,'Unsupported scan format')
    if source not in {'manual_plan','panorama_estimated','depth_scan','lidar_depth','depth_map','point_cloud','photogrammetry'}: raise HTTPException(422,'Invalid geometry source')
    if coordinate_unit not in {'meter','centimeter','millimeter'}: raise HTTPException(422,'Invalid coordinate unit')
    content=await file.read(500*1024*1024+1)
    if not content or len(content)>500*1024*1024: raise HTTPException(413,'Empty or oversized scan file')
    key=await storage.save(content,suffix,f'tours/{tour_id}/scans')
    def persist_scan():
        asset=ScanAsset.objects.create(tour=t,source=source,storage_key=key,original_filename=Path(file.filename or 'scan').name[:255],coordinate_unit=coordinate_unit,notes=notes,metadata={"size":len(content),"format":suffix.lstrip('.')})
        ScanProcessingResult.objects.create(asset=asset,state='queued',engine='format_inspection')
        save_building_geometry(t,{"source":source,"user_reviewed":False})
        return asset
    asset=await sync_to_async(persist_scan,thread_sensitive=True)()
    try:
        from fastapi_core.virtual_tours.worker import inspect_scan_asset
        task=inspect_scan_asset.delay(str(asset.id))
        return {"id":str(asset.id),"filename":asset.original_filename,"source":asset.source,"size":len(content),"status":"uploaded","processing_status":"queued","task_id":task.id,"processing_note":"فایل در صف بررسی قرار گرفت. برای XYZ/PTS/ASCII PLY/NPY/NPZ پیش‌نمایش ابرنقاط تولید می‌شود؛ این پیش‌نمایش مش معماری دقیق نیست."}
    except Exception as exc:
        await sync_to_async(ScanProcessingResult.objects.filter(asset=asset).update,thread_sensitive=True)(state='failed',error=f'Unable to enqueue scan inspection: {exc}')
        raise HTTPException(503,'صف پردازش اسکن در دسترس نیست؛ Redis و Celery Worker را بررسی کنید.')
@app.get('/api/v1/tours/{tour_id}/quality-report')
def tour_quality_report(tour_id:UUID):
    t=Tour.objects.filter(pk=tour_id).first()
    if not t: raise HTTPException(404,'Tour not found')
    report=[]
    for s in t.scenes.filter(active=True):
        images=list(s.capture_images.all()); analyses=[i.analysis or {} for i in images]; bad=[a for a in analyses if a.get('status')=='reject']; warnings=sorted({w for a in analyses for w in a.get('warnings',[])})
        yaws=sorted(float(i.yaw)%360 for i in images if i.yaw is not None); max_gap=None
        if len(yaws)>1:
            gaps=[yaws[i+1]-yaws[i] for i in range(len(yaws)-1)]+[yaws[0]+360-yaws[-1]]; max_gap=round(max(gaps),1)
            if max_gap>90: warnings.append(f'شکاف زاویه‌ای زیاد در پوشش عکس‌ها: {max_gap} درجه')
        if not s.panorama_key: warnings.append('پانورامای نهایی هنوز ساخته یا تأیید نشده است')
        required_missing=[]
        for session in s.capture_sessions.order_by('-created_at')[:1]:
            required_missing=[step.label for step in session.guide_steps.filter(required=True).exclude(state='captured')]
        if required_missing: warnings.append(f"مراحل عکاسی ناقص: {len(required_missing)} مرحله")
        blur_values=[float(a.get('blur_score')) for a in analyses if a.get('blur_score') is not None]
        brightness_values=[float(a.get('brightness')) for a in analyses if a.get('brightness') is not None]
        report.append({"scene_id":str(s.id),"scene_title":s.title,"status":"needs_attention" if bad or warnings else ('pending' if not images else 'passed'),"image_count":len(images),"rejected_images":len(bad),"warnings":warnings,"max_yaw_gap_degrees":max_gap,"average_blur_score":round(sum(blur_values)/len(blur_values),2) if blur_values else None,"average_brightness":round(sum(brightness_values)/len(brightness_values),2) if brightness_values else None,"missing_guide_steps":required_missing,"panorama_ready":bool(s.panorama_key)})
    overall="pending" if not report or any(x['status']=='pending' for x in report) else ("needs_attention" if any(x['status']=='needs_attention' for x in report) else "passed")
    return {"tour_id":str(tour_id),"overall":overall,"scenes":report,"limitations":["تشخیص قطعی ghosting و seams در این گزارش انجام نمی‌شود.","صحت هندسه و اندازه‌ها باید توسط اپراتور بازبینی شود."]}

@app.post('/api/v1/floors/{floor_id}/plan',status_code=201)
async def upload_floor_plan(floor_id:UUID,file:UploadFile=File(...)):
    f=await sync_to_async(Floor.objects.filter(pk=floor_id).first,thread_sensitive=True)()
    if not f: raise HTTPException(404,'Floor not found')
    original_data=await file.read(settings.max_upload_bytes+1)
    if len(original_data)>settings.max_upload_bytes: raise HTTPException(413,'File too large')
    try:
        from PIL import Image
        from io import BytesIO
        with Image.open(BytesIO(original_data)) as image:
            image.verify()
        with Image.open(BytesIO(original_data)) as image:
            width,height=image.size; image_format=(image.format or '').upper(); mime=Image.MIME.get(image_format,"application/octet-stream")
            original_suffix={"JPEG":".jpg","PNG":".png","WEBP":".webp"}.get(image_format)
            if not original_suffix: raise ValueError('Only JPEG, PNG and WebP floor plans are supported')
            normalized=image.convert("RGB"); out=BytesIO(); normalized.save(out,format="JPEG",quality=92,optimize=True)
            normalized_data=out.getvalue()
    except Exception as exc:
        raise HTTPException(400,f"Invalid floor plan image: {exc}")
    original_key=await storage.save(original_data,original_suffix,f'tours/{f.tour_id}/plans/originals')
    normalized_key=await storage.save(normalized_data,'.jpg',f'tours/{f.tour_id}/plans/normalized')
    def save_plan():
        version=(FloorPlanAsset.objects.filter(floor=f).order_by('-version').values_list('version',flat=True).first() or 0)+1
        FloorPlanAsset.objects.filter(floor=f,is_current=True).update(is_current=False,state='superseded')
        asset=FloorPlanAsset.objects.create(floor=f,version=version,original_key=original_key,normalized_key=normalized_key,original_filename=Path(file.filename or 'plan').name[:255],mime_type=mime,width_px=width,height_px=height,is_current=True,metadata={"normalized_format":"jpeg","original_format":image_format.lower()})
        f.plan_key=normalized_key; f.save(update_fields=['plan_key','updated_at'])
        return asset
    asset=await sync_to_async(save_plan,thread_sensitive=True)()
    return {"id":str(asset.id),"version":asset.version,"plan_url":f"{settings.public_base_url}/media/{normalized_key}","width_px":width,"height_px":height,"calibrated":False,"message":"برای تبدیل مختصات پیکسلی به متر، پلان را با یک طول واقعی کالیبره کنید."}
@app.get('/api/v1/tours/{tour_id}/capture-summary')
def capture_summary(tour_id:UUID):
    if not Tour.objects.filter(pk=tour_id).exists(): raise HTTPException(404,'Tour not found')
    return [{"scene_id":str(s.id),"title":s.title,"image_count":s.capture_images.count(),"usable_count":s.capture_images.filter(status__in=['accepted','warning']).count(),"rejected_count":s.capture_images.exclude(status__in=['accepted','warning']).count(),"has_panorama":bool(s.panorama_key)} for s in Scene.objects.filter(tour_id=tour_id)]
@app.post('/api/v1/scenes/{scene_id}/approve-panorama')
@transaction.atomic
def approve_panorama(scene_id:UUID):
    j=ProcessingJob.objects.filter(scene_id=scene_id,state='review').order_by('-created_at').first()
    if not j: raise HTTPException(404,'Review job not found')
    j.state='completed'; j.error=''; j.step='approved'; j.save()
    version=PanoramaVersion.objects.filter(scene_id=scene_id,is_current=True).order_by('-version').first()
    if version:
        from django.utils import timezone
        version.state='approved'; version.approved_at=timezone.now(); version.save(update_fields=['state','approved_at','updated_at'])
    scene=Scene.objects.filter(pk=scene_id).select_related('tour').first()
    if scene:
        active_scenes=list(scene.tour.scenes.filter(active=True))
        if active_scenes and all(PanoramaVersion.objects.filter(scene=item,is_current=True,state='approved').exists() for item in active_scenes):
            scene.tour.status='ready'; scene.tour.save(update_fields=['status','updated_at'])
    return {"status":"approved","panorama_version":version.version if version else None}
@app.post('/api/v1/scenes/{scene_id}/reject-panorama')
@transaction.atomic
def reject_panorama(scene_id:UUID,payload:dict|None=None):
    scene=Scene.objects.select_related('tour').filter(pk=scene_id).first()
    if not scene: raise HTTPException(404,'Scene not found')
    current=PanoramaVersion.objects.filter(scene=scene,is_current=True,state='review').first()
    if not current: raise HTTPException(404,'Panorama awaiting review not found')
    reason=str((payload or {}).get('reason','Rejected during visual review'))[:2000]
    current.state='rejected'; current.is_current=False; current.quality_report={**(current.quality_report or {}),'review_decision':'rejected','review_reason':reason}; current.save(update_fields=['state','is_current','quality_report','updated_at'])
    previous=PanoramaVersion.objects.filter(scene=scene,is_current=False,state='superseded',approved_at__isnull=False).order_by('-version').first()
    if previous:
        previous.state='approved'; previous.is_current=True; previous.save(update_fields=['state','is_current','updated_at'])
        scene.panorama_key=previous.storage_key; scene.thumbnail_key=previous.thumbnail_key or None
    else:
        scene.panorama_key=None; scene.thumbnail_key=None
    scene.save(update_fields=['panorama_key','thumbnail_key','updated_at'])
    ProcessingJob.objects.filter(scene=scene,state='review').update(state='failed',step='rejected',error=reason)
    active_scenes=list(scene.tour.scenes.filter(active=True))
    scene.tour.status='ready' if active_scenes and all(PanoramaVersion.objects.filter(scene=item,is_current=True,state='approved').exists() for item in active_scenes) else 'review'
    scene.tour.save(update_fields=['status','updated_at'])
    return {"status":"rejected","restored_version":previous.version if previous else None,"reason":reason}

@app.get('/media/{key:path}')
async def media(key:str):
    if settings.storage_backend.lower()=='s3':
        if not hasattr(storage,'presigned_url'): raise HTTPException(404,'Media not found')
        return RedirectResponse(await storage.presigned_url(key))
    try: path=storage.path(key)
    except ValueError: raise HTTPException(404,'Media not found')
    if not path.is_file(): raise HTTPException(404,'Media not found')
    return FileResponse(path)

# ---------------------------------------------------------------------------
# Calibrated floor plans and canonical room geometry (meters, X/Z floor plane).
# ---------------------------------------------------------------------------
@app.get('/api/v1/tours/{tour_id}/geometry')
def get_tour_geometry(tour_id: UUID):
    t=Tour.objects.filter(pk=tour_id).first()
    if not t: raise HTTPException(404,'Tour not found')
    floors=[]
    for floor in t.floors.all():
        plan=FloorPlanAsset.objects.filter(floor=floor,is_current=True).first()
        rooms=[]
        for scene in floor.scenes.filter(active=True):
            geom=RoomGeometry.objects.filter(scene=scene).first()
            rooms.append({"id":str(scene.id),"title":scene.title,"room_type":scene.room_type,"geometry":({"origin_x_m":geom.origin_x_m,"origin_z_m":geom.origin_z_m,"width_m":geom.width_m,"depth_m":geom.depth_m,"height_m":geom.height_m,"rotation_deg":geom.rotation_deg,"polygon":geom.polygon,"source":geom.source,"confidence":geom.confidence,"is_reviewed":geom.is_reviewed} if geom else {"origin_x_m":((scene.floor_x-50)*0.18 if scene.floor_x is not None else (scene.order%3)*5.0),"origin_z_m":((scene.floor_y-50)*0.18 if scene.floor_y is not None else (scene.order//3)*4.5),"width_m":scene.width_m or 4,"depth_m":scene.length_m or 4,"height_m":scene.height_m or 2.8,"rotation_deg":0,"polygon":scene.polygon or [],"source":"legacy_unreviewed","confidence":None,"is_reviewed":False}),"panorama_url":f"{settings.public_base_url}/media/{scene.panorama_key}" if scene.panorama_key else None})
        walls=[{"id":str(w.id),"room_id":str(w.room_id) if w.room_id else None,"start_x_m":w.start_x_m,"start_z_m":w.start_z_m,"end_x_m":w.end_x_m,"end_z_m":w.end_z_m,"height_m":w.height_m,"thickness_m":w.thickness_m,"kind":w.kind,"material":w.material,"openings":[{"id":str(o.id),"kind":o.kind,"offset_m":o.offset_m,"width_m":o.width_m,"height_m":o.height_m,"sill_height_m":o.sill_height_m} for o in w.openings.all()]} for w in floor.walls.all()]
        floors.append({"id":str(floor.id),"title":floor.title,"order":floor.order,"elevation_m":floor.elevation_m,"plan":{"id":str(plan.id),"version":plan.version,"url":f"{settings.public_base_url}/media/{plan.normalized_key or plan.original_key}","width_px":plan.width_px,"height_px":plan.height_px,"scale_m_per_px":plan.scale_m_per_px,"origin_x_m":plan.origin_x_m,"origin_z_m":plan.origin_z_m,"rotation_deg":plan.rotation_deg,"calibrated":bool(plan.scale_m_per_px)} if plan else None,"rooms":rooms,"walls":walls})
    return {"tour_id":str(t.id),"coordinate_system":"building_local_meters","axis_convention":{"x":"east/right","y":"up/elevation","z":"south/down-plan"},"floors":floors}

@app.put('/api/v1/scenes/{scene_id}/geometry')
@transaction.atomic
def save_room_geometry(scene_id: UUID, payload: RoomGeometryPayload):
    scene=Scene.objects.select_related('floor','tour').filter(pk=scene_id).first()
    if not scene: raise HTTPException(404,'Scene not found')
    payload=payload.model_dump()
    def number(key,default):
        try: value=float(payload.get(key,default))
        except (TypeError,ValueError): raise HTTPException(422,f'{key} must be numeric')
        if not __import__('math').isfinite(value): raise HTTPException(422,f'{key} must be finite')
        return value
    width=number('width_m',scene.width_m or 4); depth=number('depth_m',scene.length_m or 4); height=number('height_m',scene.height_m or 2.8)
    if not (0.2<=width<=100 and 0.2<=depth<=100 and 1.8<=height<=8): raise HTTPException(422,'Room dimensions are outside supported ranges')
    polygon=payload.get('polygon',[])
    if polygon:
        if not isinstance(polygon,list) or len(polygon)<3 or len(polygon)>500: raise HTTPException(422,'Polygon must contain between 3 and 500 vertices')
        try:
            polygon=[[float(p[0]),float(p[1])] for p in polygon]
            if any(not all(__import__('math').isfinite(v) for v in p) for p in polygon): raise ValueError()
        except Exception: raise HTTPException(422,'Polygon vertices must be numeric [x,z] pairs')
    geom,created=RoomGeometry.objects.get_or_create(scene=scene,defaults={})
    geom.origin_x_m=number('origin_x_m',geom.origin_x_m); geom.origin_z_m=number('origin_z_m',geom.origin_z_m)
    geom.width_m=width; geom.depth_m=depth; geom.height_m=height; geom.rotation_deg=number('rotation_deg',geom.rotation_deg)
    geom.polygon=polygon; geom.source=payload.get('source',geom.source); geom.confidence=payload.get('confidence',geom.confidence)
    geom.is_reviewed=bool(payload.get('is_reviewed',False)); geom.review_notes=str(payload.get('review_notes',''))[:5000]; geom.save()
    scene.width_m=width; scene.length_m=depth; scene.height_m=height; scene.polygon=polygon; scene.geometry_source=geom.source; scene.save(update_fields=['width_m','length_m','height_m','polygon','geometry_source','updated_at'])
    if polygon:
        area=abs(sum(polygon[i][0]*polygon[(i+1)%len(polygon)][1]-polygon[(i+1)%len(polygon)][0]*polygon[i][1] for i in range(len(polygon)))/2)
        perimeter=sum(((polygon[(i+1)%len(polygon)][0]-polygon[i][0])**2+(polygon[(i+1)%len(polygon)][1]-polygon[i][1])**2)**0.5 for i in range(len(polygon)))
    else:
        area=width*depth; perimeter=2*(width+depth)
    for kind,value,unit in [('width',width,'m'),('depth',depth,'m'),('height',height,'m'),('area',area,'m2'),('perimeter',perimeter,'m')]:
        RoomMeasurement.objects.update_or_create(scene=scene,kind=kind,defaults={'value':value,'unit':unit,'confidence':geom.confidence,'source':geom.source})
    refresh_building_review_status(scene.tour)
    invalidate_current_models(scene.tour, 'Room geometry changed')
    return {"id":str(geom.id),"scene_id":str(scene.id),"width_m":width,"depth_m":depth,"height_m":height,"area_m2":round(area,3),"perimeter_m":round(perimeter,3),"origin_x_m":geom.origin_x_m,"origin_z_m":geom.origin_z_m,"rotation_deg":geom.rotation_deg,"polygon":geom.polygon,"source":geom.source,"is_reviewed":geom.is_reviewed}

@app.get('/api/v1/scenes/{scene_id}/measurements')
def get_room_measurements(scene_id: UUID):
    if not Scene.objects.filter(pk=scene_id).exists(): raise HTTPException(404,'Scene not found')
    return [{"id":str(m.id),"kind":m.kind,"value":m.value,"unit":m.unit,"confidence":m.confidence,"source":m.source,"updated_at":m.updated_at.isoformat()} for m in RoomMeasurement.objects.filter(scene_id=scene_id).order_by('kind')]

@app.put('/api/v1/floor-plans/{plan_id}/calibration')
def calibrate_floor_plan(plan_id: UUID, payload: PlanCalibrationPayload):
    plan=FloorPlanAsset.objects.filter(pk=plan_id,is_current=True).first()
    if not plan: raise HTTPException(404,'Floor plan not found')
    payload=payload.model_dump()
    try: known=float(payload.get('known_distance_m')); pixels=float(payload.get('pixel_distance'))
    except (TypeError,ValueError): raise HTTPException(422,'known_distance_m and pixel_distance are required')
    if known<=0 or pixels<=0 or known>1000: raise HTTPException(422,'Calibration distances must be positive and within range')
    scale=known/pixels
    if not (0.0001<=scale<=1): raise HTTPException(422,'Calculated scale is implausible; check the selected pixel and real-world distances')
    plan.scale_m_per_px=scale; plan.origin_x_m=float(payload.get('origin_x_m',0)); plan.origin_z_m=float(payload.get('origin_z_m',0)); plan.rotation_deg=float(payload.get('rotation_deg',0)); plan.state='calibrated'; plan.save()
    return {"id":str(plan.id),"scale_m_per_px":scale,"state":plan.state,"message":"پلان کالیبره شد؛ مختصات اتاق‌ها از این پس باید بر حسب متر و در دستگاه مختصات ساختمان ذخیره شوند."}

@app.get('/api/v1/floors/{floor_id}/walls')
def list_walls(floor_id: UUID):
    floor=Floor.objects.filter(pk=floor_id).first()
    if not floor: raise HTTPException(404,'Floor not found')
    return [{"id":str(w.id),"room_id":str(w.room_id) if w.room_id else None,"start_x_m":w.start_x_m,"start_z_m":w.start_z_m,"end_x_m":w.end_x_m,"end_z_m":w.end_z_m,"height_m":w.height_m,"thickness_m":w.thickness_m,"kind":w.kind,"material":w.material} for w in floor.walls.all()]

@app.post('/api/v1/floors/{floor_id}/walls',status_code=201)
@transaction.atomic
def create_wall(floor_id: UUID, payload: WallCreate):
    floor=Floor.objects.select_related('tour').filter(pk=floor_id).first()
    if not floor: raise HTTPException(404,'Floor not found')
    data=payload.model_dump()
    room=None
    if data.get('room_id'):
        room=Scene.objects.filter(pk=data['room_id'],floor=floor).first()
        if not room: raise HTTPException(422,'Room must belong to this floor')
    wall=WallSegment.objects.create(floor=floor,room=room,order=data['order'],start_x_m=data['start_x_m'],start_z_m=data['start_z_m'],end_x_m=data['end_x_m'],end_z_m=data['end_z_m'],height_m=data['height_m'],thickness_m=data['thickness_m'],kind=data['kind'],material=data['material'])
    invalidate_current_models(floor.tour, 'Wall segment added')
    return {"id":str(wall.id),"floor_id":str(floor.id)}

@app.delete('/api/v1/walls/{wall_id}')
@transaction.atomic
def delete_wall(wall_id: UUID):
    wall=WallSegment.objects.select_related('floor__tour').filter(pk=wall_id).first()
    if not wall: raise HTTPException(404,'Wall not found')
    tour=wall.floor.tour; wall.delete(); invalidate_current_models(tour, 'Wall segment deleted')
    return {"status":"deleted"}

@app.post('/api/v1/walls/{wall_id}/openings',status_code=201)
@transaction.atomic
def create_wall_opening(wall_id: UUID, payload: WallOpeningCreate):
    wall=WallSegment.objects.select_related('floor__tour').filter(pk=wall_id).first()
    if not wall: raise HTTPException(404,'Wall not found')
    data=payload.model_dump()
    length=((wall.end_x_m-wall.start_x_m)**2+(wall.end_z_m-wall.start_z_m)**2)**0.5
    if data['offset_m']+data['width_m']>length or data['sill_height_m']+data['height_m']>wall.height_m:
        raise HTTPException(422,'Opening must fit completely inside its wall')
    opening=WallOpening.objects.create(wall=wall,**data)
    invalidate_current_models(wall.floor.tour, 'Wall opening added')
    return {"id":str(opening.id),"wall_id":str(wall.id)}

@app.delete('/api/v1/wall-openings/{opening_id}')
@transaction.atomic
def delete_wall_opening(opening_id: UUID):
    opening=WallOpening.objects.select_related('wall__floor__tour').filter(pk=opening_id).first()
    if not opening: raise HTTPException(404,'Wall opening not found')
    tour=opening.wall.floor.tour; opening.delete(); invalidate_current_models(tour, 'Wall opening deleted')
    return {"status":"deleted"}

@app.get('/api/v1/tours/{tour_id}/panorama-versions')
def list_panorama_versions(tour_id: UUID):
    if not Tour.objects.filter(pk=tour_id).exists(): raise HTTPException(404,'Tour not found')
    return [{"id":str(p.id),"scene_id":str(p.scene_id),"version":p.version,"state":p.state,"url":f"{settings.public_base_url}/media/{p.storage_key}","thumbnail_url":f"{settings.public_base_url}/media/{p.thumbnail_key}" if p.thumbnail_key else None,"width_px":p.width_px,"height_px":p.height_px,"source_image_count":p.source_image_count,"engine":p.engine,"is_current":p.is_current,"quality_report":p.quality_report} for p in PanoramaVersion.objects.filter(scene__tour_id=tour_id).order_by('scene_id','-version')]

@app.post('/api/v1/tours/{tour_id}/model-builds',status_code=202)
def enqueue_model_build(tour_id: UUID, payload: dict|None=None):
    tour=Tour.objects.filter(pk=tour_id).first()
    if not tour: raise HTTPException(404,'Tour not found')
    if not tour.scenes.filter(active=True).exists(): raise HTTPException(422,'At least one active room is required')
    geometry,_=BuildingGeometry.objects.get_or_create(tour=tour)
    job=ModelBuildJob.objects.create(tour=tour,state='queued',progress=0,step='queued',source=(payload or {}).get('source','manual_plan'),metadata={"requested_format":"glb","coordinate_system":"building_local_meters","source_geometry_updated_at":geometry.updated_at.isoformat()})
    try:
        from fastapi_core.virtual_tours.worker import build_dollhouse
        task=build_dollhouse.delay(str(job.id))
        job.metadata={**job.metadata,"celery_task_id":task.id}; job.save(update_fields=['metadata','updated_at'])
    except Exception as exc:
        job.state='failed'; job.error=f'Unable to enqueue model build: {exc}'; job.step='enqueue_failed'; job.save()
        raise HTTPException(503,'پردازشگر پس‌زمینه در دسترس نیست؛ وضعیت Redis و Celery Worker را بررسی کنید.')
    return {"job_id":str(job.id),"state":job.state,"message":"درخواست ساخت مدل سه‌بعدی ثبت شد."}

@app.get('/api/v1/model-builds/{job_id}')
def get_model_build(job_id: UUID):
    job=ModelBuildJob.objects.filter(pk=job_id).first()
    if not job: raise HTTPException(404,'Model build job not found')
    return {"id":str(job.id),"state":job.state,"progress":job.progress,"step":job.step,"error":job.error,"metadata":job.metadata,"model_url":f"{settings.public_base_url}/media/{job.output_key}" if job.output_key else None}

@app.get('/api/v1/tours/{tour_id}/model-assets')
def list_model_assets(tour_id: UUID):
    if not Tour.objects.filter(pk=tour_id).exists(): raise HTTPException(404,'Tour not found')
    return [{"id":str(a.id),"version":a.version,"format":a.format,"url":f"{settings.public_base_url}/media/{a.storage_key}","source":a.source,"coordinate_system":a.coordinate_system,"metadata":a.metadata,"is_current":a.is_current} for a in GeneratedModelAsset.objects.filter(tour_id=tour_id).order_by('-version')]

@app.post('/api/v1/model-builds/{job_id}/approve')
def approve_model_build(job_id: UUID):
    job=ModelBuildJob.objects.filter(pk=job_id,state='review').first()
    if not job: raise HTTPException(404,'Model build requiring review not found')
    job.state='completed'; job.step='approved'; job.error=''; job.save(update_fields=['state','step','error','updated_at'])
    if all(PanoramaVersion.objects.filter(scene=scene,is_current=True,state='approved').exists() for scene in job.tour.scenes.filter(active=True)):
        job.tour.status='ready'; job.tour.save(update_fields=['status','updated_at'])
    return {"status":"approved","job_id":str(job.id)}

@app.get('/api/v1/tours/{tour_id}/scan-assets')
def list_scan_assets(tour_id: UUID):
    if not Tour.objects.filter(pk=tour_id).exists(): raise HTTPException(404,'Tour not found')
    return [{"id":str(a.id),"filename":a.original_filename,"source":a.source,"coordinate_unit":a.coordinate_unit,"status":a.status,"size":(a.metadata or {}).get('size',0),"processing":({"state":a.processing_result.state,"engine":a.processing_result.engine,"point_count":a.processing_result.point_count,"bounds":a.processing_result.bounds,"error":a.processing_result.error,"preview_url":f"{settings.public_base_url}/media/{a.processing_result.preview_key}" if a.processing_result.preview_key else None} if hasattr(a,'processing_result') else None)} for a in ScanAsset.objects.filter(tour_id=tour_id).order_by('-created_at')]
