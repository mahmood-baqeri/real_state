# ماژول FastAPI تور مجازی املاک

این پوشه سرویس API و پردازش تور مجازی است. این بخش مالک مدل یا دیتابیس نیست و برای خواندن و نوشتن داده‌ها از مدل‌های اپ `virtual_tours` در Django استفاده می‌کند.

## ساختار

- `main.py`: مسیرهای API و دریافت درخواست‌ها
- `schemas.py`: اعتبارسنجی ورودی و خروجی API
- `worker.py`: وظایف پس‌زمینه Celery
- `processing/`: پردازش تصویر، کنترل کیفیت، اسکن و ساخت GLB
- `storage.py`: ذخیره فایل در فضای محلی یا S3
- `django_runtime.py`: راه‌اندازی اتصال به تنظیمات Django پروژه میزبان

## اتصال به پروژه میزبان

پروژه اصلی باید `DJANGO_SETTINGS_MODULE` را تنظیم کرده باشد، اپ `virtual_tours` را در `INSTALLED_APPS` ثبت کرده باشد و مسیر `backend/django_core` در `PYTHONPATH` باشد. این ماژول عمداً هیچ فایل تنظیمات یا پروژه مستقل Django ندارد.

## نصب وابستگی‌ها و اجرا

`pip install -r requirements.txt`

`uvicorn fastapi_core.virtual_tours.main:app --app-dir backend --host 0.0.0.0 --port 8000`

برای اجرای Worker نیز از مسیر ریشه‌ای استفاده کنید: `celery -A fastapi_core.virtual_tours.worker.celery worker --loglevel=info`

## آزمون‌ها

آزمون‌های مستقل پردازش: `pytest backend/fastapi_core/virtual_tours/tests -q`

آزمون مدل‌های Django باید با تنظیمات تست پروژه اصلی اجرا شود: `python manage.py test virtual_tours`
