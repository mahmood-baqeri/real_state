"""ذخیره و بازیابی فایل‌ها از فضای محلی یا فضای سازگار با S3."""
from __future__ import annotations
import asyncio
from pathlib import Path
from uuid import uuid4
import aiofiles
from fastapi_core.virtual_tours.core.config import settings

class LocalStorage:
    def __init__(self):
        self.root = Path(settings.storage_root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    async def save(self, data: bytes, suffix: str, folder: str) -> str:
        key = f"{folder.strip('/')}/{uuid4().hex}{suffix.lower()}"
        path = self.path(key)
        path.parent.mkdir(parents=True, exist_ok=True)
        async with aiofiles.open(path, "wb") as file:
            await file.write(data)
        return key

    def path(self, key: str) -> Path:
        path = (self.root / key).resolve()
        if self.root not in path.parents:
            raise ValueError("Invalid storage key")
        return path

    async def read(self, key: str) -> bytes:
        async with aiofiles.open(self.path(key), "rb") as file:
            return await file.read()

    async def delete(self, key: str) -> None:
        path = self.path(key)
        if path.exists():
            path.unlink()

class S3Storage:
    def __init__(self):
        import boto3
        self.client = boto3.client(
            "s3",
            endpoint_url=settings.s3_endpoint_url or None,
            aws_access_key_id=settings.s3_access_key or None,
            aws_secret_access_key=settings.s3_secret_key or None,
            region_name=settings.s3_region or None,
        )
        self.bucket = settings.s3_bucket

    async def save(self, data: bytes, suffix: str, folder: str) -> str:
        key = f"{folder.strip('/')}/{uuid4().hex}{suffix.lower()}"
        content_type = "image/jpeg" if suffix.lower() in {".jpg", ".jpeg"} else "application/octet-stream"
        await asyncio.to_thread(self.client.put_object, Bucket=self.bucket, Key=key, Body=data, ContentType=content_type)
        return key

    async def read(self, key: str) -> bytes:
        response = await asyncio.to_thread(self.client.get_object, Bucket=self.bucket, Key=key)
        body = response["Body"]
        try:
            return await asyncio.to_thread(body.read)
        finally:
            await asyncio.to_thread(body.close)

    async def delete(self, key: str) -> None:
        await asyncio.to_thread(self.client.delete_object, Bucket=self.bucket, Key=key)

    def path(self, key: str):
        raise ValueError("S3 assets are delivered through presigned URLs")

    async def presigned_url(self, key: str) -> str:
        return await asyncio.to_thread(
            self.client.generate_presigned_url,
            "get_object",
            Params={"Bucket": self.bucket, "Key": key},
            ExpiresIn=settings.s3_presign_ttl,
        )

if settings.storage_backend.lower() == "s3":
    if not settings.s3_bucket:
        raise RuntimeError("S3_BUCKET is required when STORAGE_BACKEND=s3")
    storage = S3Storage()
elif settings.storage_backend.lower() == "local":
    storage = LocalStorage()
else:
    raise RuntimeError("STORAGE_BACKEND must be either 'local' or 's3'")
