"""اتصال سرویس FastAPI به تنظیمات و مدل‌های پروژه اصلی Django."""
# -*- coding: utf-8 -*-
"""اتصال FastAPI و Worker به مدل‌های Django پروژه میزبان.

پروژه میزبان باید متغیر DJANGO_SETTINGS_MODULE را تنظیم کرده باشد و برنامه
virtual_tours را در INSTALLED_APPS ثبت کرده باشد. این ماژول تنظیمات مستقل نمی‌سازد.
"""
import os
import sys
from pathlib import Path

# مسیر پوشه‌ای را به مسیر جست‌وجوی پایتون اضافه می‌کنیم تا اپ Django پیدا شود.
MODULE_ROOT = Path(__file__).resolve().parents[2]
DJANGO_APPS_ROOT = MODULE_ROOT / "django_core"
if str(DJANGO_APPS_ROOT) not in sys.path:
    sys.path.insert(0, str(DJANGO_APPS_ROOT))

# تنظیمات باید از پروژه اصلی بیاید؛ ماژول نباید پروژه Django جداگانه بسازد.
if not os.environ.get("DJANGO_SETTINGS_MODULE"):
    raise RuntimeError(
        "متغیر DJANGO_SETTINGS_MODULE را به مسیر تنظیمات پروژه اصلی Django تنظیم کنید."
    )

import django  # noqa: E402
django.setup()
