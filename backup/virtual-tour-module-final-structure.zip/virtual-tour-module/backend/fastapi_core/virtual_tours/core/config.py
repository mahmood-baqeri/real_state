"""خواندن تنظیمات اجرایی سرویس FastAPI از متغیرهای محیطی."""
from pydantic_settings import BaseSettings, SettingsConfigDict
class Settings(BaseSettings):
    redis_url: str = "redis://localhost:6379/0"
    storage_backend: str = "local"
    storage_root: str = "./data"
    s3_endpoint_url: str = ""
    s3_bucket: str = ""
    s3_access_key: str = ""
    s3_secret_key: str = ""
    s3_region: str = "us-east-1"
    s3_presign_ttl: int = 3600
    panorama_fov: float = 75.0
    max_upload_bytes: int = 100 * 1024 * 1024
    cors_origins: str = "http://localhost:3000"
    public_base_url: str = "http://localhost:8000"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
settings = Settings()
