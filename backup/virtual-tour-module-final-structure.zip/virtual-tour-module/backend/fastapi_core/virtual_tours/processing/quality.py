"""بررسی کیفیت تصاویر ورودی و محاسبه شاخص‌های لازم برای عکاسی بهتر."""
import cv2
import numpy as np
from fastapi_core.virtual_tours.processing.image_io import normalize_image

def analyze_image(data: bytes) -> dict:
    normalized, meta = normalize_image(data)
    arr = np.frombuffer(normalized, dtype=np.uint8)
    image = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError("تصویر قابل خواندن نیست")
    h, w = image.shape[:2]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blur = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    brightness = float(np.mean(gray))
    contrast = float(np.std(gray))
    # نسبت نقاط بسیار روشن یا بسیار تیره، سوختگی نور و از بین رفتن جزئیات سایه را مشخص می‌کند.
    dark_clip = float(np.mean(gray <= 5) * 100)
    bright_clip = float(np.mean(gray >= 250) * 100)
    warnings = []
    if blur < 45: warnings.append("احتمال تاری یا لرزش تصویر")
    if brightness < 55 or dark_clip > 8: warnings.append("نور تصویر کم یا سایه‌ها بسته‌اند")
    if brightness > 210 or bright_clip > 8: warnings.append("نور تصویر زیاد یا بخش‌هایی سوخته‌اند")
    if contrast < 22: warnings.append("کنتراست تصویر پایین است")
    if min(w, h) < 900: warnings.append("رزولوشن تصویر برای پانورامای باکیفیت پایین است")
    # هش ادراکی ۶۴ بیتی برای شناسایی عکس‌های تکراری ناخواسته در یک جلسه عکاسی استفاده می‌شود.
    small=cv2.resize(gray,(32,32),interpolation=cv2.INTER_AREA).astype(np.float32)
    dct=cv2.dct(small)[:8,:8].flatten()[1:]
    median=float(np.median(dct))
    phash=''.join(f'{sum((1<<i) for i,v in enumerate(dct[j:j+4]) if v>median):x}' for j in range(0,64,4))
    status = "reject" if blur < 12 or min(w, h) < 500 else ("warning" if warnings else "accepted")
    return {**meta, "width": w, "height": h, "blur_score": round(blur, 2),
            "brightness": round(brightness, 2), "contrast": round(contrast, 2),
            "dark_clip_percent": round(dark_clip, 2), "bright_clip_percent": round(bright_clip, 2),
            "perceptual_hash": phash, "status": status, "warnings": warnings}
