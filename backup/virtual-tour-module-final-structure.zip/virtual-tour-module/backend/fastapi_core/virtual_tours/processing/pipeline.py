"""فرایند ساخت پانوراما؛ ابتدا از Hugin و در صورت نیاز از OpenCV استفاده می‌کند."""
from __future__ import annotations
import asyncio
from io import BytesIO
from pathlib import Path
import glob
import shutil
import subprocess
import tempfile

import cv2
import numpy as np
from PIL import Image
from fastapi_core.virtual_tours.storage import storage
from fastapi_core.virtual_tours.processing.quality import analyze_image
from fastapi_core.virtual_tours.core.config import settings

HUGIN_TOOLS = ("pto_gen", "cpfind", "cpclean", "autooptimiser", "pano_modify", "nona", "enblend")

def _hugin_available() -> bool:
    return all(shutil.which(tool) for tool in HUGIN_TOOLS)

def _run(command: list[str], timeout: int = 900) -> None:
    result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip()[-2500:]
        raise RuntimeError(f"Hugin command failed ({Path(command[0]).name}): {detail}")

def _hugin_stitch(raw_images: list[bytes], hfov: float) -> bytes:
    with tempfile.TemporaryDirectory(prefix="vt-hugin-") as temp:
        root = Path(temp)
        files = []
        for index, raw in enumerate(raw_images):
            path = root / f"capture-{index:03d}.jpg"
            path.write_bytes(raw)
            files.append(str(path))
        pto = str(root / "project.pto")
        clean = str(root / "clean.pto")
        optimized = str(root / "optimized.pto")
        spherical = str(root / "spherical.pto")
        _run(["pto_gen", f"--fov={hfov}", "-o", pto, *files])
        _run(["cpfind", "--multirow", "-o", pto, pto], timeout=1200)
        _run(["cpclean", "-o", clean, pto])
        _run(["autooptimiser", "-a", "-l", "-s", "-o", optimized, clean], timeout=1200)
        # عدد ۲ به معنی تصویر کروی بازشده است؛ اندازه خروجی برای پوشش کامل ۳۶۰ درجه تنظیم می‌شود.
        _run(["pano_modify", "--projection=2", "--fov=360,180", "--canvas=AUTO", "--crop=AUTO", "-o", spherical, optimized])
        prefix = str(root / "render-")
        _run(["nona", "-m", "TIFF_m", "-o", prefix, spherical], timeout=1200)
        rendered = sorted(glob.glob(str(root / "render-*.tif")))
        if not rendered:
            raise RuntimeError("Hugin produced no rendered image layers")
        output = str(root / "panorama.tif")
        enblend = shutil.which("enblend")
        if enblend:
            _run([enblend, "-o", output, *rendered], timeout=1200)
            selected = output
        else:
            # اگر لایه نخست Nona معتبر نباشد، خطا می‌دهیم تا فایل خراب به‌عنوان خروجی پذیرفته نشود.
            selected = rendered[0]
        with Image.open(selected) as image:
            image = image.convert("RGB")
            buffer = BytesIO()
            image.save(buffer, format="JPEG", quality=92, optimize=True, progressive=True)
            return buffer.getvalue()

async def build_panorama(keys: list[str], output_key_hint: str, on_progress=None) -> dict:
    if len(keys) < 2:
        raise ValueError("برای ساخت پانوراما حداقل دو تصویر لازم است")
    raw_images: list[bytes] = []
    cv_images = []
    for key in keys:
        raw = await storage.read(key)
        analysis = analyze_image(raw)
        if analysis["status"] == "reject":
            continue
        raw_images.append(raw)
        arr = np.frombuffer(raw, np.uint8)
        image = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        if image is not None:
            cv_images.append(image)
    if len(raw_images) < 2 or len(cv_images) < 2:
        raise ValueError("تعداد تصاویر قابل استفاده برای اتصال کافی نیست")
    if on_progress:
        await on_progress(25, "validating_captures")

    panorama_bytes: bytes
    engine: str
    projection: str
    if _hugin_available():
        if on_progress:
            await on_progress(35, "hugin_feature_matching")
        try:
            panorama_bytes = await asyncio.to_thread(_hugin_stitch, raw_images, settings.panorama_fov)
            engine, projection = "hugin", "equirectangular"
        except Exception as hugin_error:
            # در محیط‌های محدود از روش جایگزین استفاده می‌کنیم و این موضوع را در نتیجه اعلام می‌کنیم.
            if on_progress:
                await on_progress(45, "opencv_fallback")
            panorama_bytes, engine, projection = await _opencv_stitch(cv_images), "opencv", "spherical_partial_candidate"
            fallback_reason = str(hugin_error)[:1200]
    else:
        panorama_bytes, engine, projection = await _opencv_stitch(cv_images), "opencv", "spherical_partial_candidate"
        fallback_reason = "Hugin tools are not installed; OpenCV fallback was used."

    if on_progress:
        await on_progress(88, "writing_panorama")
    with Image.open(BytesIO(panorama_bytes)) as panorama:
        panorama = panorama.convert("RGB")
        width, height = panorama.size
        if width < 1024 or height < 512:
            raise RuntimeError("ابعاد پانورامای خروجی برای نمایش باکیفیت کافی نیست")
        buffer = BytesIO()
        panorama.save(buffer, format="JPEG", quality=91, optimize=True, progressive=True)
        panorama_bytes = buffer.getvalue()
        preview = panorama.copy()
        preview.thumbnail((1200, 600), Image.Resampling.LANCZOS)
        thumb_buffer = BytesIO()
        preview.save(thumb_buffer, format="JPEG", quality=82, optimize=True)
    key = await storage.save(panorama_bytes, ".jpg", f"{output_key_hint}/panoramas")
    thumbnail_key = await storage.save(thumb_buffer.getvalue(), ".jpg", f"{output_key_hint}/thumbnails")
    if on_progress:
        await on_progress(96, "finalizing_assets")
    result = {
        "storage_key": key,
        "thumbnail_key": thumbnail_key,
        "width": width,
        "height": height,
        "aspect_ratio": round(width / max(height, 1), 4),
        "input_count": len(cv_images),
        "engine": engine,
        "projection": projection,
        # حتی پس از موفقیت پردازش Hugin باید کیفیت بصری بررسی شود؛ موفقیت فنی به‌تنهایی کافی نیست.
        # زیرا ممکن است بخشی از فضا ثبت نشده باشد یا در محل اتصال تصاویر خطا دیده شود.
        "requires_visual_review": True,
        "review_reason": "پوشش کامل، درزها، اعوجاج و صحت اتصال باید در پیش‌نمایش بررسی شود.",
    }
    if engine == "opencv":
        result["fallback_note"] = fallback_reason
    return result

async def _opencv_stitch(images: list[np.ndarray]) -> bytes:
    def stitch():
        stitcher = cv2.Stitcher_create(cv2.Stitcher_PANORAMA)
        status, pano = stitcher.stitch(images)
        if status != cv2.Stitcher_OK or pano is None:
            raise RuntimeError(f"اتصال تصاویر ناموفق بود (OpenCV status={status}). هم‌پوشانی بیشتر، نوردهی ثابت و چرخش از نقطه ثابت را رعایت کنید.")
        pano = cv2.fastNlMeansDenoisingColored(pano, None, 3, 3, 7, 21)
        lab = cv2.cvtColor(pano, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        l = cv2.createCLAHE(clipLimit=1.5, tileGridSize=(8, 8)).apply(l)
        pano = cv2.cvtColor(cv2.merge((l, a, b)), cv2.COLOR_LAB2BGR)
        ok, encoded = cv2.imencode(".jpg", pano, [cv2.IMWRITE_JPEG_QUALITY, 91])
        if not ok:
            raise RuntimeError("ساخت فایل پانوراما ناموفق بود")
        return encoded.tobytes()
    return await asyncio.to_thread(stitch)
