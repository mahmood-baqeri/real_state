"""ساخت فایل GLB سبک و قابل ویرایش از هندسه‌ای که بر اساس پلان تعریف شده است.

The exported model is architectural massing (floors and walls), not a photogrammetric
reconstruction. Coordinates are meters, X/Z are the floor plane and Y is up.
"""
from __future__ import annotations
import json, math, struct
from typing import Iterable


def _rotate(x: float, z: float, degrees: float) -> tuple[float, float]:
    a = math.radians(degrees); c, s = math.cos(a), math.sin(a)
    return x*c - z*s, x*s + z*c


def build_dollhouse_glb(floors: list[dict], rooms: list[dict], walls: list[dict] | None = None) -> tuple[bytes, dict]:
    positions: list[float] = []
    indices: list[int] = []
    primitive_ranges: list[dict] = []
    material_ids: list[int] = []
    min_bounds = [float("inf")] * 3; max_bounds = [float("-inf")] * 3

    def add_vertex(p):
        idx = len(positions)//3; positions.extend([float(p[0]), float(p[1]), float(p[2])])
        for k in range(3): min_bounds[k] = min(min_bounds[k], p[k]); max_bounds[k] = max(max_bounds[k], p[k])
        return idx

    def add_quad(a, b, c, d, material=0):
        start = len(indices); ia, ib, ic, id_ = map(add_vertex, (a,b,c,d))
        indices.extend([ia,ib,ic, ia,ic,id_]); primitive_ranges.append({"start":start,"count":6,"material":material})

    def add_wall(wall, elevation=0.0):
        x1,z1=float(wall["start_x_m"]),float(wall["start_z_m"]); x2,z2=float(wall["end_x_m"]),float(wall["end_z_m"])
        dx,dz=x2-x1,z2-z1; length=math.hypot(dx,dz)
        if length<0.05: return
        ux,uz=dx/length,dz/length; nx,nz=-uz,ux
        height=max(1.8,min(8.0,float(wall.get("height_m",2.8)))); thickness=max(0.05,float(wall.get("thickness_m",0.14)))/2
        def point(t,y,side=0): return (x1+ux*t+nx*thickness*side,elevation+y,z1+uz*t+nz*thickness*side)
        openings=sorted(wall.get("openings",[]),key=lambda o:float(o.get("offset_m",0)))
        cursor=0.0
        for opening in openings:
            start=max(cursor,float(opening.get("offset_m",0))); end=min(length,start+float(opening.get("width_m",0.9)))
            sill=max(0.0,float(opening.get("sill_height_m",0))); top=min(height,sill+float(opening.get("height_m",2.1)))
            if start>cursor: add_quad(point(cursor,0,-1),point(start,0,-1),point(start,height,-1),point(cursor,height,-1),0)
            if sill>0 and end>start: add_quad(point(start,0,-1),point(end,0,-1),point(end,sill,-1),point(start,sill,-1),0)
            if top<height and end>start: add_quad(point(start,top,-1),point(end,top,-1),point(end,height,-1),point(start,height,-1),0)
            cursor=max(cursor,end)
        if cursor<length: add_quad(point(cursor,0,-1),point(length,0,-1),point(length,height,-1),point(cursor,height,-1),0)
        # سطح پشت دیوار هم ساخته می‌شود تا دیوار از هر دو سمت در نمایشگر دیده شود.
        # دیوارها به شکل پوسته سبک ساخته می‌شوند و حجم توپر کامل ایجاد نمی‌کنند.
        if not openings: add_quad(point(0,0,1),point(length,0,1),point(length,height,1),point(0,height,1),0)

    floor_map = {str(f["id"]): float(f.get("elevation_m", 0)) for f in floors}
    walls = walls or []
    walls_by_room={}
    for wall in walls:
        if wall.get("room_id"): walls_by_room.setdefault(str(wall["room_id"]),[]).append(wall)
    for room in rooms:
        width = max(0.2, float(room.get("width_m") or 4.0)); depth = max(0.2, float(room.get("depth_m") or 4.0))
        height = max(1.8, min(6.0, float(room.get("height_m") or 2.8)))
        ox, oz = float(room.get("origin_x_m", 0)), float(room.get("origin_z_m", 0))
        rotation = float(room.get("rotation_deg", 0)); elevation = floor_map.get(str(room.get("floor_id")), 0.0)
        polygon = room.get("polygon") or [[-width/2,-depth/2],[width/2,-depth/2],[width/2,depth/2],[-width/2,depth/2]]
        if len(polygon) < 3: continue
        pts=[]
        for point in polygon:
            px,pz = float(point[0]),float(point[1]); rx,rz = _rotate(px,pz,rotation); pts.append((ox+rx,oz+rz))
        # سطح کف به چند مثلث تقسیم می‌شود؛ این روش برای چندضلعی ساده و بدون حفره مناسب است.
        base = [add_vertex((x,elevation,z)) for x,z in pts]
        for i in range(1,len(base)-1):
            start=len(indices); indices.extend([base[0],base[i+1],base[i]]); primitive_ranges.append({"start":start,"count":3,"material":1})
        # اگر دیوارها جداگانه تعریف شده باشند از همان‌ها استفاده می‌کنیم؛ در غیر این صورت از مرز اتاق دیوار می‌سازیم.
        explicit=walls_by_room.get(str(room.get("id")),[])
        if len(explicit) < len(pts):
            for i,(x1,z1) in enumerate(pts):
                x2,z2=pts[(i+1)%len(pts)]
                add_quad((x1,elevation,z1),(x2,elevation,z2),(x2,elevation+height,z2),(x1,elevation+height,z1),0)
        for wall in explicit: add_wall(wall,elevation)
        # لبه باریک زیر کف کمک می‌کند مرز کف اتاق در مدل بهتر دیده شود.
        for i,(x1,z1) in enumerate(pts):
            x2,z2=pts[(i+1)%len(pts)]
            add_quad((x1,elevation,z1),(x1,elevation-0.08,z1),(x2,elevation-0.08,z2),(x2,elevation,z2),1)

    for wall in walls:
        if not wall.get("room_id"):
            elevation=floor_map.get(str(wall.get("floor_id")),0.0); add_wall(wall,elevation)
    if not positions or not indices:
        raise ValueError("No valid room geometry is available to build the Dollhouse model")
    # داده موقعیت رأس‌ها و شماره رأس‌ها با هم‌ترازی چهار‌بایتی در فایل قرار می‌گیرند.
    pos_bytes = struct.pack("<" + "f"*len(positions), *positions)
    while len(pos_bytes) % 4: pos_bytes += b"\x00"
    index_offset = len(pos_bytes)
    index_bytes = struct.pack("<" + "I"*len(indices), *indices)
    binary = pos_bytes + index_bytes
    primitives=[]
    for material in (0,1):
        selected=[r for r in primitive_ranges if r["material"]==material]
        if not selected: continue
        # برای هر جنس، بخش جداگانه‌ای از شماره رأس‌ها ساخته می‌شود تا نمایش مواد درست باشد.
        # این کار مثلث‌های مربوط به هر جنس را در یک بخش مستقل جمع می‌کند.
        compact=[]
        for r in selected: compact.extend(indices[r["start"]:r["start"]+r["count"]])
        raw=struct.pack("<"+"I"*len(compact),*compact)
        offset=len(binary); binary += raw
        while len(binary)%4: binary += b"\x00"
        view_index=2+len(primitives)
        primitives.append({"attributes":{"POSITION":0},"indices":view_index,"material":material,"mode":4,"_offset":offset,"_length":len(raw),"_count":len(compact)})
    views=[{"buffer":0,"byteOffset":0,"byteLength":len(pos_bytes),"target":34962},{"buffer":0,"byteOffset":index_offset,"byteLength":len(index_bytes),"target":34963}]
    accessors=[{"bufferView":0,"componentType":5126,"count":len(positions)//3,"type":"VEC3","min":min_bounds,"max":max_bounds},{"bufferView":1,"componentType":5125,"count":len(indices),"type":"SCALAR"}]
    for p in primitives:
        views.append({"buffer":0,"byteOffset":p.pop("_offset"),"byteLength":p.pop("_length"),"target":34963})
        accessors.append({"bufferView":len(views)-1,"componentType":5125,"count":p.pop("_count"),"type":"SCALAR"})
    gltf={"asset":{"version":"2.0","generator":"Virtual Tour Studio"},"scene":0,"scenes":[{"nodes":[0]}],"nodes":[{"name":"Dollhouse Building","mesh":0}],"meshes":[{"name":"Plan-derived Dollhouse","primitives":primitives}],"materials":[{"name":"Interior walls","doubleSided":True,"pbrMetallicRoughness":{"baseColorFactor":[0.91,0.89,0.84,1],"roughnessFactor":0.92}},{"name":"Floor slabs","doubleSided":True,"pbrMetallicRoughness":{"baseColorFactor":[0.68,0.58,0.43,1],"roughnessFactor":0.88}}],"buffers":[{"byteLength":len(binary)}],"bufferViews":views,"accessors":accessors}
    json_bytes=json.dumps(gltf,separators=(",",":"),ensure_ascii=False).encode("utf-8")
    while len(json_bytes)%4: json_bytes += b" "
    while len(binary)%4: binary += b"\x00"
    total=12+8+len(json_bytes)+8+len(binary)
    glb=struct.pack("<4sII",b"glTF",2,total)+struct.pack("<I4s",len(json_bytes),b"JSON")+json_bytes+struct.pack("<I4s",len(binary),b"BIN\x00")+binary
    meta={"format":"glb","coordinate_system":"building_local_meters","vertex_count":len(positions)//3,"triangle_count":len(indices)//3,"room_count":len(rooms),"wall_segment_count":len(walls),"bounds":{"min":min_bounds,"max":max_bounds},"geometry_source":"manual_plan_or_reviewed_room_geometry","limitations":["Plan-derived architectural massing; wall openings are represented as planar cut-outs, not full wall reveals or joinery.","For metric accuracy, room dimensions and scan alignment must be reviewed by the operator."]}
    return glb,meta


def build_pointcloud_glb(points):
    """نقاط نمونه‌برداری‌شده اسکن را برای بررسی در قالب نقاط فایل glTF ذخیره می‌کند."""
    import numpy as np
    arr=np.asarray(points,dtype=np.float32)
    if arr.ndim!=2 or arr.shape[1]<3 or len(arr)<3: raise ValueError('Point cloud must contain at least three XYZ points')
    arr=arr[:,:3]
    arr=arr[np.isfinite(arr).all(axis=1)]
    if len(arr)<3: raise ValueError('Point cloud contains too few finite points')
    # حجم پیش‌نمایش محدود می‌شود تا مرورگر سبک بماند و پراکندگی نقاط حفظ شود.
    if len(arr)>250000:
        step=max(1,len(arr)//250000); arr=arr[::step][:250000]
    raw=arr.astype('<f4',copy=False).tobytes()
    mn=arr.min(axis=0).astype(float).tolist(); mx=arr.max(axis=0).astype(float).tolist()
    gltf={"asset":{"version":"2.0","generator":"Virtual Tour Studio scan preview"},"scene":0,"scenes":[{"nodes":[0]}],"nodes":[{"mesh":0}],"meshes":[{"primitives":[{"attributes":{"POSITION":0},"mode":0,"material":0}]}],"materials":[{"name":"Scan points","doubleSided":True,"pbrMetallicRoughness":{"baseColorFactor":[0.12,0.45,0.8,1],"roughnessFactor":1}}],"buffers":[{"byteLength":len(raw)}],"bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":len(raw),"target":34962}],"accessors":[{"bufferView":0,"componentType":5126,"count":len(arr),"type":"VEC3","min":mn,"max":mx}]}
    jb=json.dumps(gltf,separators=(',',':')).encode()
    while len(jb)%4: jb+=b' '
    while len(raw)%4: raw+=b'\x00'
    total=12+8+len(jb)+8+len(raw)
    glb=struct.pack('<4sII',b'glTF',2,total)+struct.pack('<I4s',len(jb),b'JSON')+jb+struct.pack('<I4s',len(raw),b'BIN\x00')+raw
    return glb,{"point_count":int(len(arr)),"bounds":{"min":mn,"max":mx},"format":"glb-point-cloud-preview","note":"Point cloud preview only; this is not a watertight architectural mesh."}
