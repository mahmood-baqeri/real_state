"""خواندن و آماده‌سازی فایل‌های اسکن عمقی و ابرنقاط."""
from __future__ import annotations
from pathlib import Path
from io import BytesIO
import numpy as np


def read_point_cloud(filename: str, data: bytes):
    suffix=Path(filename).suffix.lower()
    if suffix in {'.xyz','.pts'}:
        rows=[]
        for line in data.decode('utf-8-sig',errors='ignore').splitlines():
            line=line.strip()
            if not line or line.startswith('#'): continue
            parts=line.replace(',',' ').split()
            try: vals=[float(v) for v in parts[:3]]
            except ValueError: continue
            if len(vals)==3: rows.append(vals)
        arr=np.asarray(rows,dtype=np.float32)
    elif suffix=='.pcd':
        stream=BytesIO(data); fields=[]; data_mode=None
        while True:
            line=stream.readline()
            if not line: raise ValueError('Incomplete PCD header')
            text=line.decode('ascii','ignore').strip()
            if text.startswith('FIELDS '): fields=text.split()[1:]
            elif text.startswith('DATA '): data_mode=text.split()[1].lower(); break
        if data_mode!='ascii': raise ValueError('Only ASCII PCD is supported by the built-in preview reader; convert binary PCD to XYZ or use a point-cloud adapter')
        try: ix,iy,iz=[fields.index(axis) for axis in ('x','y','z')]
        except ValueError: raise ValueError('PCD fields must include x, y and z')
        rows=[]
        for line in stream.read().decode('ascii','ignore').splitlines():
            values=line.split()
            try: rows.append([float(values[ix]),float(values[iy]),float(values[iz])])
            except (ValueError,IndexError): continue
        arr=np.asarray(rows,dtype=np.float32)
    elif suffix in {'.las','.laz'}:
        try:
            import laspy
            cloud=laspy.read(BytesIO(data)); arr=np.column_stack((cloud.x,cloud.y,cloud.z)).astype(np.float32)
        except ImportError: raise ValueError('LAS/LAZ reader is optional; install laspy[lazrs] to process this scan format')
        except Exception as exc: raise ValueError(f'Unable to read LAS/LAZ point cloud: {exc}')
    elif suffix=='.ply':
        stream=BytesIO(data); first=stream.readline().strip()
        if first!=b'ply': raise ValueError('Invalid PLY header')
        fmt=None; count=None; props=[]
        while True:
            line=stream.readline()
            if not line: raise ValueError('Incomplete PLY header')
            text=line.decode('ascii','ignore').strip()
            if text.startswith('format '): fmt=text.split()[1]
            elif text.startswith('element vertex '): count=int(text.split()[-1])
            elif text.startswith('property ') and count is not None: props.append(text.split()[-1])
            elif text=='end_header': break
        if fmt!='ascii': raise ValueError('Only ASCII PLY is supported by the built-in preview reader; convert binary PLY to XYZ or install a compatible point-cloud adapter')
        if not count or count<3: raise ValueError('PLY contains too few vertices')
        try: ix,iy,iz=[props.index(axis) for axis in ('x','y','z')]
        except ValueError: raise ValueError('PLY vertex properties must include x, y and z')
        rows=[]
        for _ in range(count):
            line=stream.readline()
            if not line: break
            values=line.split()
            try: rows.append([float(values[ix]),float(values[iy]),float(values[iz])])
            except (ValueError,IndexError): continue
        arr=np.asarray(rows,dtype=np.float32)
    elif suffix in {'.npy','.npz'}:
        loaded=np.load(BytesIO(data),allow_pickle=False)
        if suffix=='.npz':
            key='points' if 'points' in loaded.files else loaded.files[0]
            arr=np.asarray(loaded[key],dtype=np.float32)
        else: arr=np.asarray(loaded,dtype=np.float32)
    else:
        raise ValueError(f'Built-in preview reader does not support {suffix or "this file type"}; use XYZ, PTS, ASCII PLY, NPY or NPZ')
    if arr.ndim!=2 or arr.shape[1]<3: raise ValueError('Point cloud array must have shape N×3 or wider')
    arr=arr[:,:3]; arr=arr[np.isfinite(arr).all(axis=1)]
    if len(arr)<3: raise ValueError('Point cloud must contain at least three finite XYZ points')
    if len(arr)>2_000_000: raise ValueError('Point cloud exceeds the built-in inspection limit of 2,000,000 points')
    return arr
