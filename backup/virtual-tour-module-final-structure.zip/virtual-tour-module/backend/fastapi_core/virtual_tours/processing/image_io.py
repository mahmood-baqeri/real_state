"""خواندن امن تصویر و یکسان‌سازی اندازه و قالب آن برای مسیرهای بارگذاری."""
from __future__ import annotations
from io import BytesIO
import warnings
from PIL import Image, ImageOps, UnidentifiedImageError

ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}
MAX_PIXELS = 60_000_000

def normalize_image(data: bytes, *, max_pixels: int = MAX_PIXELS) -> tuple[bytes, dict]:
    if not data:
        raise ValueError("فایل تصویر خالی است")
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            source = Image.open(BytesIO(data))
            fmt = (source.format or "").upper()
            if fmt not in ALLOWED_FORMATS:
                raise ValueError("فرمت واقعی تصویر باید JPEG، PNG یا WebP باشد")
            source.verify()
        with Image.open(BytesIO(data)) as image:
            image = ImageOps.exif_transpose(image)
            width, height = image.size
            if width < 320 or height < 240:
                raise ValueError("ابعاد تصویر بسیار کوچک است")
            if width * height > max_pixels:
                raise ValueError("ابعاد تصویر بیش از حد مجاز است")
            image = image.convert("RGB")
            output = BytesIO()
            image.save(output, format="JPEG", quality=94, optimize=True, progressive=True, subsampling=0)
            return output.getvalue(), {"width": width, "height": height, "source_format": fmt, "normalized_format": "JPEG"}
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError, Image.DecompressionBombWarning) as exc:
        raise ValueError("فایل تصویر معتبر نیست یا قابل پردازش نیست") from exc
