"""وظایف پس‌زمینه؛ API و Worker هر دو فقط از ORM جنگو برای داده‌ها استفاده می‌کنند."""
import asyncio
from celery import Celery
from asgiref.sync import sync_to_async
from django.db import close_old_connections
from django.db.models import Q
from fastapi_core.virtual_tours.django_runtime import *  # noqa
from virtual_tours.models import ProcessingJob, Scene, CaptureImage, PanoramaVersion, CaptureSession, ModelBuildJob, Tour, Floor, RoomGeometry, GeneratedModelAsset, ScanAsset, ScanProcessingResult, WallSegment, BuildingGeometry
from fastapi_core.virtual_tours.core.config import settings
from fastapi_core.virtual_tours.processing.pipeline import build_panorama
from fastapi_core.virtual_tours.processing.glb import build_dollhouse_glb, build_pointcloud_glb
from fastapi_core.virtual_tours.processing.scan import read_point_cloud
from fastapi_core.virtual_tours.storage import storage

celery=Celery('virtual_tour',broker=settings.redis_url,backend=settings.redis_url)
celery.conf.update(task_serializer='json',result_serializer='json',accept_content=['json'],task_track_started=True,worker_prefetch_multiplier=1,task_acks_late=True,task_reject_on_worker_lost=True,broker_connection_retry_on_startup=True,task_soft_time_limit=1800,task_time_limit=1860)

@celery.task(bind=True,name='virtual_tour.process_scene',acks_late=True)
def process_scene(self,job_id:str):
    close_old_connections()
    job=ProcessingJob.objects.filter(pk=job_id).first()
    if not job: return {'job_id':job_id,'state':'missing'}
    scene=Scene.objects.filter(pk=job.scene_id).first()
    if not scene:
        job.state='failed'; job.step='failed'; job.error='Scene no longer exists'; job.save(); return {'job_id':job_id,'state':'failed'}
    session_id=(job.result or {}).get('capture_session_id')
    images=CaptureImage.objects.filter(scene=scene,status__in=['accepted','warning'])
    if session_id: images=images.filter(session_id=session_id)
    images=list(images.order_by('sequence'))
    if len(images)<2:
        job.state='failed'; job.step='failed'; job.error='At least two usable photos are required'; job.save(); return {'job_id':job_id,'state':'failed'}
    job.state='running'; job.progress=10; job.step='loading_images'; job.save()
    async def run():
        async def report(progress,step):
            await sync_to_async(ProcessingJob.objects.filter(pk=job_id).update,thread_sensitive=True)(progress=progress,step=step)
        return await build_panorama([x.storage_key for x in images],f'tours/{scene.tour_id}/scenes/{scene.id}',on_progress=report)
    try:
        result=asyncio.run(run())
        # همه نسخه‌های پانوراما نگهداری می‌شوند و نسخه قبلی منتشرشده حذف نمی‌شود.
        next_version=(PanoramaVersion.objects.filter(scene=scene).order_by('-version').values_list('version',flat=True).first() or 0)+1
        PanoramaVersion.objects.filter(scene=scene,is_current=True).update(is_current=False,state='superseded')
        PanoramaVersion.objects.create(scene=scene,capture_session_id=session_id if session_id else None,version=next_version,
            state='review' if result.get('requires_visual_review') else 'approved',storage_key=result['storage_key'],
            thumbnail_key=result.get('thumbnail_key',''),projection=result.get('projection','equirectangular'),
            width_px=result.get('width',0),height_px=result.get('height',0),source_image_count=result.get('input_count',0),
            engine=result.get('engine',''),quality_report=result,is_current=True)
        scene.panorama_key=result['storage_key']; scene.thumbnail_key=result.get('thumbnail_key'); scene.save(update_fields=['panorama_key','thumbnail_key','updated_at'])
        job.state='review' if result.get('requires_visual_review') else 'completed'; job.progress=100; job.step='review_required' if result.get('requires_visual_review') else 'completed'; job.result={**(job.result or {}),**result,'panorama_version':next_version}; job.error='خروجی ساخته شد و باید پیش از انتشار بازبینی شود.' if result.get('requires_visual_review') else ''; job.save()
        scene.tour.status='review' if result.get('requires_visual_review') else 'ready'; scene.tour.save(update_fields=['status','updated_at'])
        if session_id: CaptureSession.objects.filter(pk=session_id).update(status='completed')
        return {'job_id':job_id,'state':job.state,'result':result}
    except Exception as exc:
        job.state='failed'; job.progress=0; job.step='failed'; job.error=str(exc); job.save()
        if session_id: CaptureSession.objects.filter(pk=session_id).update(status='needs_retake')
        scene.tour.status='capturing'; scene.tour.save(update_fields=['status','updated_at'])
        raise
    finally: close_old_connections()


@celery.task(bind=True,name='virtual_tour.build_dollhouse',acks_late=True)
def build_dollhouse(self,job_id:str):
    close_old_connections()
    job=ModelBuildJob.objects.filter(pk=job_id).first()
    if not job: return {'job_id':job_id,'state':'missing'}
    try:
        job.state='running'; job.progress=10; job.step='loading_geometry'; job.error=''; job.save()
        tour=Tour.objects.get(pk=job.tour_id)
        floors=list(Floor.objects.filter(tour=tour).values('id','elevation_m'))
        rooms=[]; unreviewed_room_count=0
        for scene in Scene.objects.filter(tour=tour,active=True).select_related('floor'):
            geom=RoomGeometry.objects.filter(scene=scene).first()
            if geom:
                if not geom.is_reviewed: unreviewed_room_count+=1
                rooms.append({'id':str(scene.id),'floor_id':str(scene.floor_id),'width_m':geom.width_m,'depth_m':geom.depth_m,'height_m':geom.height_m,'origin_x_m':geom.origin_x_m,'origin_z_m':geom.origin_z_m,'rotation_deg':geom.rotation_deg,'polygon':geom.polygon})
            else:
                # اگر هندسه جدید وجود نداشت از ابعاد قدیمی فضا استفاده می‌کنیم؛ این داده نیازمند بازبینی است.
                unreviewed_room_count+=1
                rooms.append({'id':str(scene.id),'floor_id':str(scene.floor_id),'width_m':scene.width_m or 4.0,'depth_m':scene.length_m or 4.0,'height_m':scene.height_m or 2.8,'origin_x_m':((scene.floor_x-50)*0.18 if scene.floor_x is not None else (scene.order%3)*5.0),'origin_z_m':((scene.floor_y-50)*0.18 if scene.floor_y is not None else (scene.order//3)*4.5),'rotation_deg':0,'polygon':scene.polygon or []})
        if not rooms: raise ValueError('At least one active room with geometry is required')
        walls=[]
        for wall in WallSegment.objects.filter(floor__tour=tour).filter(Q(room__active=True)|Q(room__isnull=True)).prefetch_related('openings'):
            walls.append({'id':str(wall.id),'floor_id':str(wall.floor_id),'room_id':str(wall.room_id) if wall.room_id else None,'start_x_m':wall.start_x_m,'start_z_m':wall.start_z_m,'end_x_m':wall.end_x_m,'end_z_m':wall.end_z_m,'height_m':wall.height_m,'thickness_m':wall.thickness_m,'openings':[{'kind':o.kind,'offset_m':o.offset_m,'width_m':o.width_m,'height_m':o.height_m,'sill_height_m':o.sill_height_m} for o in wall.openings.all()]})
        job.progress=35; job.step='building_glb'; job.save()
        glb,meta=build_dollhouse_glb(floors,rooms,walls)
        geometry_revision=BuildingGeometry.objects.get(tour=tour).updated_at.isoformat()
        expected_revision=(job.metadata or {}).get('source_geometry_updated_at')
        if expected_revision and geometry_revision!=expected_revision:
            raise RuntimeError('Building geometry changed while the model was being generated; start a new build from the latest geometry.')
        meta['unreviewed_room_count']=unreviewed_room_count
        meta['operator_review_required']=True
        key=asyncio.run(storage.save(glb,'.glb',f'tours/{tour.id}/models'))
        version=(GeneratedModelAsset.objects.filter(tour=tour,format='glb').order_by('-version').values_list('version',flat=True).first() or 0)+1
        GeneratedModelAsset.objects.filter(tour=tour,format='glb',is_current=True).update(is_current=False)
        asset=GeneratedModelAsset.objects.create(tour=tour,version=version,format='glb',storage_key=key,source=job.source,metadata=meta,is_current=True)
        job.state='review'; job.progress=100; job.step='review_required'; job.output_key=key; job.metadata={**(job.metadata or {}),**meta,'asset_id':str(asset.id)}; job.error='مدل تولید شد؛ ابعاد، اتصال طبقات و صحت هندسه را در نمای سه‌بعدی بازبینی کنید.'; job.save()
        tour.status='review'; tour.save(update_fields=['status','updated_at'])
        return {'job_id':job_id,'state':job.state,'asset_id':str(asset.id),'storage_key':key,'metadata':meta}
    except Exception as exc:
        job.state='failed'; job.progress=0; job.step='failed'; job.error=str(exc); job.save(); raise
    finally:
        close_old_connections()


@celery.task(bind=True,name='virtual_tour.inspect_scan_asset',acks_late=True)
def inspect_scan_asset(self,asset_id:str):
    close_old_connections()
    asset=ScanAsset.objects.filter(pk=asset_id).first()
    if not asset: return {'asset_id':asset_id,'state':'missing'}
    result,_=ScanProcessingResult.objects.get_or_create(asset=asset)
    try:
        result.state='running'; result.engine='builtin_xyz_ply_numpy_reader'; result.error=''; result.save()
        raw=asyncio.run(storage.read(asset.storage_key))
        points=read_point_cloud(asset.original_filename,raw)
        # پیش از محاسبه محدوده، واحد فایل ورودی به متر تبدیل می‌شود.
        factor={'meter':1.0,'centimeter':0.01,'millimeter':0.001}.get(asset.coordinate_unit,1.0)
        points=points*factor
        glb,meta=build_pointcloud_glb(points)
        preview_key=asyncio.run(storage.save(glb,'.glb',f'tours/{asset.tour_id}/scans/previews'))
        result.state='review'; result.preview_key=preview_key; result.point_count=meta['point_count']; result.bounds=meta['bounds']; result.metrics={**meta,'source_unit':asset.coordinate_unit,'canonical_unit':'meter','sampled_for_preview':meta['point_count']<len(points)}; result.save()
        asset.status='preview_ready'; asset.metadata={**(asset.metadata or {}),'point_count':len(points),'preview_note':meta['note']}; asset.save(update_fields=['status','metadata','updated_at'])
        return {'asset_id':asset_id,'state':result.state,'point_count':result.point_count,'preview_key':preview_key}
    except Exception as exc:
        result.state='failed'; result.error=str(exc); result.save(); asset.status='failed'; asset.metadata={**(asset.metadata or {}),'processing_error':str(exc)}; asset.save(update_fields=['status','metadata','updated_at']); raise
    finally: close_old_connections()
