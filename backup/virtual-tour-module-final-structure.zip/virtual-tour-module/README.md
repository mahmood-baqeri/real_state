# Virtual Tour Studio — مستقل برای املاک

ماژول مستقل ساخت، مدیریت و انتشار تور مجازی ملک با عکاسی هدایت‌شده موبایل، پانورامای ۳۶۰ درجه، پلان دوبعدی، Dollhouse سه‌بعدی، اسکن عمقی و کنترل کیفیت.

## معماری قطعی

- **Django Core** تنها مالک مدل‌های ORM، دیتابیس، Migration و قواعد داده است.
- **FastAPI** سرویس HTTP و پردازش است و همان کلاس‌های مدل Django را مستقیماً مصرف می‌کند؛ مدل ORM موازی ندارد.
- **Celery + Redis** پردازش‌های طولانی پانوراما، بررسی ابرنقاط و تولید GLB را اجرا می‌کنند.
- **PostgreSQL** تنها دیتابیس ماژول است.
- **Next.js + React + TypeScript** پنل مدیریت، عکاسی موبایل، ویرایش پلان و نمایش تور را ارائه می‌کند.
- **Three.js** نمایش Dollhouse و تعامل با اتاق‌ها را انجام می‌دهد.
- ذخیره‌سازی محلی یا S3-compatible قابل انتخاب است.

## ساختار سورس

```text
virtual-tour-module/
├── backend/
│   ├── django_core/
│   │   ├── config/                  # Django settings
│   │   ├── apps/virtual_tours/
│   │   │   ├── models.py            # تنها منبع مدل‌های ORM
│   │   │   └── migrations/          # تنها منبع تغییر Schema
│   │   └── manage.py
│   ├── fastapi_service/
│   │   ├── main.py                  # FastAPI routes
│   │   ├── django_runtime.py        # django.setup() و اتصال به Django ORM
│   │   ├── schemas.py               # Pydantic HTTP schemas، نه ORM
│   │   ├── worker.py                # Celery tasks + همان Django ORM
│   │   ├── storage.py
│   │   ├── core/                    # تنظیمات سرویس FastAPI
│   │   └── processing/              # پانوراما، کیفیت، اسکن و GLB
│   ├── tests/
│   └── requirements.txt
├── frontend/
│   └── src/app/
│       ├── page.tsx                 # داشبورد
│       ├── tours/[id]/              # مدیریت تور، طبقات، اتاق‌ها، لینک‌ها و Hotspot
│       ├── capture/[sceneId]/       # راهنمای عکاسی موبایل
│       ├── geometry/[tourId]/       # کالیبراسیون پلان و هندسه ساختمان
│       ├── dollhouse/[tourId]/      # نمای سه‌بعدی، اسکن و خروجی GLB
│       └── viewer/[tourId]/         # بازدیدکننده تور ۳۶۰
├── docker-compose.yml
├── ARCHITECTURE.md
├── MODELS.md
├── WORKFLOWS.md
└── API.md
```

## اجرای توسعه با Docker Compose

1. فایل `backend/.env.example` را به `backend/.env` کپی کنید.
2. مقادیر اتصال دیتابیس، Redis، کلید Django، CORS و ذخیره‌سازی را تنظیم کنید.
3. اجرا:

```bash
docker compose up --build
```

سرویس Migration قبل از FastAPI و Worker اجرا می‌شود. آدرس‌های پیش‌فرض توسعه:

- Frontend: `http://localhost:3000`
- FastAPI: `http://localhost:8000`
- Swagger: `http://localhost:8000/docs`
- Readiness: `http://localhost:8000/ready`

## اجرای دستی Backend

در محیطی که PostgreSQL و Redis آماده‌اند:

```bash
cd backend
cp .env.example .env
pip install -r requirements.txt
python django_core/manage.py migrate
uvicorn fastapi_service.main:app --host 0.0.0.0 --port 8000 --reload
```

در ترمینال جداگانه:

```bash
cd backend
celery -A fastapi_service.worker.celery worker --loglevel=info --concurrency=1
```

## اجرای دستی Frontend

```bash
cd frontend
cp .env.example .env.local
npm install
npm run dev
```

متغیرهای Frontend:

```env
NEXT_PUBLIC_API_URL=http://localhost:8000/api/v1
NEXT_PUBLIC_MEDIA_URL=http://localhost:8000/media
```

## تغییر مدل و Migration

مدل‌ها فقط در این مسیر تعریف می‌شوند:

`backend/django_core/apps/virtual_tours/models.py`

ساخت و اجرای Migration فقط با Django:

```bash
cd backend
python django_core/manage.py makemigrations virtual_tours
python django_core/manage.py migrate
```

در FastAPI فقط Pydantic Schema و endpoint تعریف می‌شود. در این پروژه SQLAlchemy، Alembic یا مدل دیتابیس مستقل FastAPI وجود ندارد.

## جریان اصلی استفاده

1. ایجاد تور با شناسه مرجع ملک از سامانه میزبان.
2. تعریف طبقات و اتاق‌ها.
3. بارگذاری پلان هر طبقه و کالیبره‌کردن آن با دو نقطه و یک فاصله واقعی.
4. تعریف هندسه اتاق‌ها بر حسب متر؛ تعیین ابعاد، محل، چرخش و در صورت نیاز چندضلعی.
5. عکاسی هدایت‌شده برای هر اتاق؛ ثبت تصاویر، وضعیت حسگر و کیفیت اولیه.
6. پردازش پانوراما در Celery؛ ثبت نسخه و انتقال به بازبینی انسانی.
7. اتصال اتاق‌ها با لینک‌های ناوبری و افزودن Hotspot اطلاعاتی.
8. ساخت و بازبینی Dollhouse؛ در صورت وجود، افزودن دیوارها و بازشوها.
9. بارگذاری اسکن عمقی/ابرنقاط و مشاهده پیش‌نمایش فرمت‌های پشتیبانی‌شده.
10. اجرای گزارش کنترل کیفیت و انتشار فقط پس از تأیید پانوراماهای اتاق‌های فعال.

## قابلیت‌های پیاده‌سازی‌شده

- مدیریت تور، طبقه، اتاق، وضعیت و شناسه مرجع خارجی
- ثبت جلسه عکاسی و گام‌های هدایت‌شده (۱۲ زاویه افقی + سقف و کف)
- بارگذاری تصویر، نرمال‌سازی، بررسی رزولوشن، تاری، نور، کنتراست و تصویر تکراری
- ثبت Yaw/Pitch و بررسی شکاف پوشش زاویه‌ای
- اتصال پانوراما با Hugin و مسیر جایگزین OpenCV
- نسخه‌بندی پانوراما و تأیید/رد انسانی
- مدیریت لینک‌های بین اتاق‌ها و Hotspotها
- بارگذاری نسخه‌دار پلان طبقه و کالیبراسیون متر بر پیکسل
- هندسه اتاق با مختصات مشترک `building_local_meters`
- ثبت دیوارها و بازشوهای در/پنجره/قوس
- تولید خروجی GLB پارامتریک از کف و دیوارهای اتاق و بازشوهای ثبت‌شده
- ورودی اسکن و تولید پیش‌نمایش ابرنقاط GLB برای فرمت‌های خوانده‌شده توسط پردازشگر داخلی
- گزارش کیفیت و وضعیت آماده‌سازی هر اتاق
- مدیریت فایل‌ها و حذف دارایی‌های مرتبط هنگام حذف تور/اتاق/طبقه

## محدودیت‌های فنی مهم

این نسخه یک محصول قابل اجرا برای ساخت تور ۳۶۰ و Dollhouse پارامتریک است؛ نباید آن را موتور بازسازی فوتورئالیستی Matterport دانست.

- پانورامای تک‌نقطه‌ای عمق و ابعاد واقعی دیوارها را تعیین نمی‌کند.
- خروجی GLB معماری از پلان و اندازه‌های واردشده ساخته می‌شود؛ هندسه و اندازه‌ها باید بازبینی شوند.
- بازشوها در خروجی GLB به شکل بریدگی سطحی نمایش داده می‌شوند؛ چهارچوب و جزئیات اجرایی در و پنجره ساخته نمی‌شوند.
- پیش‌نمایش ابرنقاط برای XYZ، PTS، ASCII PLY، ASCII PCD، NPY و NPZ فعال است. LAS/LAZ به نصب `laspy[lazrs]` نیاز دارد.
- Depth Map، تصاویر خام، بسته Photogrammetry و فرمت‌های باینری PLY/PCD دریافت و ذخیره می‌شوند، اما موتور داخلی فعلی آن‌ها را به مش معماری تبدیل نمی‌کند.
- تشخیص تاری، نور، کنتراست، رزولوشن، تصویر تکراری و شکاف زاویه‌ای خودکار است؛ تشخیص قطعی Ghosting و Seam و تأیید نهایی همچنان نیازمند بازبینی بصری است.
- با fallback OpenCV ممکن است پانوراما کامل ۳۶۰ درجه تولید نشود؛ خروجی با وضعیت Review علامت می‌خورد و نباید بدون بررسی منتشر شود.

## احراز هویت و اتصال به سامانه میزبان

عمداً پیاده‌سازی نشده‌اند. `resource_type`, `resource_id`, `tenant_id` برای اتصال به ملک/آژانس در سامانه میزبان در نظر گرفته شده‌اند. پیش از دسترسی عمومی باید احراز هویت، مجوزهای سطح آژانس/ملک، محدودیت دسترسی به فایل‌ها و کنترل tenant در مرز سامانه میزبان اعمال شوند.

## تست‌های قابل اجرا

```bash
cd backend
PYTHONPATH=. pytest -q
```

تست‌های فعلی شامل پردازش تصویر، ذخیره‌سازی، تولید GLB و خواندن ابرنقاط هستند. تست Migration و اتصال واقعی PostgreSQL باید در محیطی که Django و PostgreSQL در دسترس است اجرا شود.
