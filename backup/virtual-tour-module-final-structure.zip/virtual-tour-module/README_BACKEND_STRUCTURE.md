# راهنمای ساختار بک‌اند ماژول تور مجازی

ساختار بک‌اند فقط شامل دو مسیر ماژول است:

```text
backend/
├── django_core/
│   └── virtual_tours/
└── fastapi_core/
    └── virtual_tours/
```

- `django_core/virtual_tours`: اپلیکیشن قابل نصب در پروژه اصلی Django؛ شامل مدل‌ها، Migrationها، سرویس‌های دامنه و آزمون مدل‌ها.
- `fastapi_core/virtual_tours`: API، اعتبارسنجی درخواست‌ها، پردازش تصویر و اسکن، تولید GLB، ذخیره‌سازی و Workerها.

این بسته عمداً فاقد `settings.py`، `manage.py`، تنظیمات اتصال دیتابیس و فایل‌های پروژه مستقل Django است. پروژه میزبان مالک تنظیمات و اتصال دیتابیس باقی می‌ماند.

## راه‌اندازی در پروژه میزبان

1. مسیر `backend/django_core` را به `PYTHONPATH` اضافه کنید.
2. `virtual_tours.apps.VirtualToursConfig` را به `INSTALLED_APPS` اضافه کنید.
3. Migrationهای `virtual_tours` را با تنظیمات پروژه اصلی اجرا کنید.
4. هنگام اجرای FastAPI و Celery، متغیر `DJANGO_SETTINGS_MODULE` را روی تنظیمات پروژه میزبان قرار دهید.
5. مسیر `backend` را نیز در `PYTHONPATH` قرار دهید تا بسته `fastapi_core.virtual_tours` قابل import باشد.

## اجرای آزمون‌ها

آزمون‌های قابل اجرای مستقل این ماژول:

```bash
PYTHONPATH=backend pytest -q backend/fastapi_core/virtual_tours/tests
```

آزمون مدل‌های Django باید با تنظیمات تست پروژه میزبان اجرا شود:

```bash
python manage.py test virtual_tours
```

تمام فیلدهای مدل دارای `help_text` فارسی هستند. توضیح ماژول‌ها، مدل‌ها و آزمون‌ها نیز فارسی نوشته شده است.
