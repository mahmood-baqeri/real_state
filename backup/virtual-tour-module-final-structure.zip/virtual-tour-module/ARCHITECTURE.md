# Architecture & boundaries

## Ownership

`django_core/apps/virtual_tours/models.py` is the only persistent ORM model source. Django migrations are the only schema authority. FastAPI imports these classes after `django.setup()`; Celery tasks do the same. Pydantic schemas are transport contracts only and must never be used as a second database model layer.

## Runtime

- Django: schema, ORM, data integrity and core state.
- FastAPI: HTTP API, request validation, uploads and orchestration.
- Celery/Redis: panorama stitching, scan inspection and GLB builds.
- PostgreSQL: canonical relational data.
- Storage adapter: local filesystem or S3-compatible object storage.
- Next.js: capture and management UX.

## Coordinate convention

All building geometry is stored in meters in `building_local_meters`:

- X: horizontal axis on the floor plan.
- Y: vertical elevation.
- Z: depth axis on the floor plan.
- Floor elevation is a Y offset.
- Room polygons are local X/Z vertices; room origin and rotation place them in building coordinates.
- Camera yaw/pitch are panorama-local spherical angles, not building coordinates.

Never mix the legacy normalized `Scene.floor_x/floor_y` percentages with metric coordinates. They are retained only for backward compatibility and initial layout suggestions.

## Processing lifecycle

Capture: `created -> capturing -> validating -> ready/needs_retake -> completed`.

Panorama: `queued -> running -> review -> approved` or `failed`. A new panorama creates a new `PanoramaVersion`; old versions are preserved and marked superseded.

Dollhouse build: `queued -> running -> review -> completed` or `failed`. The build creates a versioned `GeneratedModelAsset` in GLB format.

Scan inspection: `queued -> running -> review` or `failed`. The built-in reader produces a point-cloud preview, not an architectural mesh.

## Deletion and storage

Deleting a tour, scene or empty floor collects related storage keys and removes corresponding records before best-effort object deletion. For production, object-store lifecycle policies and asynchronous deletion/retry queues are recommended for very large tours.

## Host integration

Authentication is deliberately external. The host should pass verified tenant/property context at the API boundary and enforce per-tour authorization before calling management endpoints. Never trust `tenant_id` or `resource_id` from an untrusted browser as authorization.
