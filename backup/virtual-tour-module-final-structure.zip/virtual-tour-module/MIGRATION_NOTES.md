# Upgrade notes

## From the previous Django-core/FastAPI package

The previous package already used Django for the initial relational schema. Keep the existing database and run the new Django migration:

```bash
cd backend
python django_core/manage.py migrate
```

Migration `0002_geometry_capture_and_asset_versions` adds the versioned floor-plan, room-geometry, wall/opening, capture-guide, panorama-version, scan-processing, generated-model and measurement tables. It does not drop the original Tour/Floor/Scene/CaptureSession/CaptureImage/SceneLink/Hotspot/ProcessingJob/ScanAsset/BuildingGeometry/ModelBuildJob tables.

Back up PostgreSQL before deploying. Existing scene dimensions and legacy normalized floor positions are retained as fallbacks. New metric `RoomGeometry` rows can be created/verified through the Geometry Editor. Old panorama keys remain available; only new processing runs create `PanoramaVersion` history records.

## From a database created by the older SQLAlchemy-only prototype

There is no automatic data migration from arbitrary SQLAlchemy table layouts in this archive. Export and map those records into the Django models before switching traffic. Do not point this version at an unverified legacy schema and run migrations without a backup.

## Deployment order

1. Back up database and media storage.
2. Deploy backend code and dependencies.
3. Run Django migrations once.
4. Start Redis, API and Celery worker.
5. Deploy frontend.
6. Verify tour reads, uploads, Celery processing, media access and tenant authorization in the host application.

## Backend package layout update (2026-11-21)

The former `backend/app/` package is now `backend/fastapi_service/` to make the service boundary explicit. Update runtime commands to `uvicorn fastapi_service.main:app` and `celery -A fastapi_service.worker.celery`. Django remains the only persistence/model owner under `backend/django_core/`; no duplicate ORM layer was introduced. Docker copy paths and the root/backend READMEs were updated accordingly.
