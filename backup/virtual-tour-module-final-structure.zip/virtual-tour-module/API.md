# FastAPI endpoints

Base prefix: `/api/v1`. Interactive OpenAPI documentation is available at `/docs` when the API is running.

## Tours and building structure

- `GET /tours` — list tours
- `POST /tours` — create a tour
- `GET /tours/{tour_id}` — tour detail with floors, scenes and links
- `PATCH /tours/{tour_id}` — update tour metadata
- `DELETE /tours/{tour_id}` — delete tour and related stored assets
- `POST /tours/{tour_id}/floors` — add floor
- `PATCH /floors/{floor_id}` — update floor
- `DELETE /floors/{floor_id}` — delete an empty floor
- `POST /tours/{tour_id}/scenes` — add room/scene
- `GET/PATCH/DELETE /scenes/{scene_id}` — room operations
- `POST /tours/{tour_id}/start-scene` — choose initial room

## Guided capture and panorama

- `POST /scenes/{scene_id}/capture-sessions` — create guided capture session and guide steps
- `GET /capture-sessions/{session_id}/guide` — read guide progress
- `POST /capture-sessions/{session_id}/images` — upload/replace a frame (`file`, `sequence`, optional `yaw`, `pitch` form fields)
- `GET /capture-sessions/{session_id}/images` — list frames
- `POST /capture-sessions/{session_id}/complete` — validate capture session
- `POST /scenes/{scene_id}/process` — enqueue panorama processing
- `GET /jobs/{job_id}` — processing state
- `GET /scenes/{scene_id}/jobs` — processing history
- `GET /tours/{tour_id}/panorama-versions` — panorama revision history
- `POST /scenes/{scene_id}/approve-panorama` — approve latest review-required panorama
- `POST /scenes/{scene_id}/reject-panorama` — reject a panorama and restore the last approved revision when available
- `GET /tours/{tour_id}/quality-report` — quality summary
- `GET /tours/{tour_id}/capture-summary` — per-room capture summary

## Navigation and hotspots

- `POST /tours/{tour_id}/links` — create room-to-room link
- `DELETE /links/{link_id}` — remove link
- `POST /scenes/{scene_id}/hotspots` — create information/navigation hotspot
- `GET /scenes/{scene_id}/hotspots` — list room hotspots
- `GET /tours/{tour_id}/hotspots` — list tour hotspots
- `PATCH/DELETE /hotspots/{hotspot_id}` — update/remove hotspot

## Plans and geometry

- `POST /floors/{floor_id}/plan` — upload normalized, versioned floor plan
- `GET /tours/{tour_id}/geometry` — floors, plan metadata, rooms and walls
- `PUT /floor-plans/{plan_id}/calibration` — calibrate meter-per-pixel scale
- `PUT /scenes/{scene_id}/geometry` — save metric room geometry and calculate measurements
- `GET /scenes/{scene_id}/measurements` — read width/depth/height/area/perimeter
- `GET /floors/{floor_id}/walls` — list explicit wall segments
- `POST /floors/{floor_id}/walls` — create wall segment
- `POST /walls/{wall_id}/openings` — create door/window/arch opening
- `DELETE /walls/{wall_id}` — delete wall and its openings
- `DELETE /wall-openings/{opening_id}` — delete an opening
- `GET/PUT /tours/{tour_id}/dollhouse` — read/save Dollhouse layout
- `PUT /tours/{tour_id}/geometry-source` — set building geometry source/review state

## Scan and model generation

- `POST /tours/{tour_id}/scan-assets` — upload scan/depth/point-cloud source
- `GET /tours/{tour_id}/scan-assets` — scan assets and inspection results
- `POST /tours/{tour_id}/model-builds` — enqueue GLB build
- `GET /model-builds/{job_id}` — build progress and model URL
- `POST /model-builds/{job_id}/approve` — approve generated model after review
- `GET /tours/{tour_id}/model-assets` — model revision history
- `GET /media/{key}` — retrieve local media or redirect to S3 presigned URL

## Operational

- `GET /health` — liveness
- `GET /ready` — PostgreSQL and Redis readiness

All management routes are intentionally unauthenticated inside this standalone module. The host application must enforce authorization before exposing them publicly.
