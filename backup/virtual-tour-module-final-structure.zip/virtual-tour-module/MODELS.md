# Django data model catalogue

All models below are defined only in `backend/django_core/apps/virtual_tours/models.py` and migrated only by Django.

| Model | Responsibility | Important relations/data |
|---|---|---|
| `Tour` | Aggregate root for a property tour | External `resource_type/resource_id`, `tenant_id`, status, title, settings |
| `Floor` | Building storey | Tour FK, order, elevation in meters, legacy plan key |
| `Scene` | A room/space represented by a 360 panorama | Tour + Floor FKs, room type, capture state, start scene, panorama/thumbnail keys, legacy dimensions/position |
| `CaptureSession` | One guided capture attempt for a room | Tour + Scene FKs, guide plan, device metadata, lifecycle status |
| `CaptureImage` | Uploaded frame | Session + Scene FKs, sequence, dimensions, quality JSON, yaw/pitch, storage key |
| `CaptureGuideStep` | Persistent capture instruction | Session FK, expected yaw/pitch, overlap, required flag, capture state, optional image FK |
| `SceneLink` | Navigable transition between rooms | Tour, source Scene, target Scene, spherical yaw/pitch, directionality |
| `Hotspot` | Informational or navigational marker | Scene, optional target Scene, yaw/pitch, title/body |
| `ProcessingJob` | Panorama processing state | Tour + Scene, progress, step, error, result metadata |
| `PanoramaVersion` | Immutable panorama revision | Scene, optional CaptureSession, source count, projection, dimensions, QA report, approval/current state |
| `FloorPlanAsset` | Versioned floor-plan image | Floor, pixel dimensions, meter-per-pixel calibration, origin and rotation, current version |
| `RoomGeometry` | Canonical editable room geometry | OneToOne Scene, metric origin/dimensions/rotation/polygon, source/confidence/review status |
| `WallSegment` | Explicit wall geometry | Floor, optional Room, start/end X/Z, height/thickness, material and type |
| `WallOpening` | Door/window/arch opening in a wall | Wall FK, offset, width, height, sill height |
| `ScanAsset` | Original LiDAR/depth/point-cloud/photogrammetry input | Tour FK, source, unit, file key, metadata |
| `ScanProcessingResult` | Scan inspection output | OneToOne ScanAsset, point count, bounds, preview/mesh keys, engine and errors |
| `BuildingGeometry` | Building-level geometry metadata | OneToOne Tour, coordinate system, source, accuracy, review state and JSON snapshot |
| `ModelBuildJob` | Dollhouse build lifecycle | Tour FK, progress, source, output key, metadata and error |
| `GeneratedModelAsset` | Versioned generated model | Tour FK, GLB/GLTF/OBJ/PLY format, storage key, source, coordinate system and metadata |
| `RoomMeasurement` | Explicit room measurements | Scene FK, width/depth/height/area/perimeter, unit, confidence and source |

## Important invariants

- `Scene.floor` and `Scene.tour` must refer to the same tour; API validates this on creation.
- `SceneLink` source and target must belong to the same tour.
- Navigation hotspots must target a scene in the same tour.
- A `FloorPlanAsset` version is unique within its floor.
- A `PanoramaVersion` version is unique within its scene.
- A `GeneratedModelAsset` version is unique per tour and format.
- A capture step sequence is unique within its capture session.
- A room measurement kind is unique per room; geometry updates upsert width/depth/height/area/perimeter.
- A capture image sequence is unique within its capture session; re-uploading a sequence replaces that frame.
- Room geometry uses meters and `building_local_meters`; legacy normalized scene coordinates are not the canonical coordinate system.
