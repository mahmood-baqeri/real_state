# Product workflows

## 1. Tour setup

Create a `Tour` using the host property's external identifier. Create floors in storey order and rooms (`Scene`) for each floor. Each room is the unit of capture and the destination of a 360 navigation link.

## 2. Floor plan calibration and room geometry

Upload a plan image to a floor. The server normalizes it and stores a versioned `FloorPlanAsset`. Select two points whose real-world distance is known; the scale is `known_distance_m / pixel_distance`. The plan origin is the world coordinate of its top-left pixel. Place room origins using this scale, then edit width, depth, height, rotation and optional polygon. Mark geometry reviewed only after checking actual measurements.

## 3. Guided mobile capture

A capture session persists 14 guide steps: 12 horizontal headings at 30-degree intervals, plus ceiling and floor. The first 12 steps are required; top and bottom are supplementary. Keep the camera at one physical location and rotate around its optical center. The target overlap is 35%. The browser camera flow uses the rear camera and device orientation when available; manual angle guidance remains the fallback.

Each upload is normalized to JPEG, analyzed for resolution, blur, exposure, contrast and perceptual duplicates, then stored with yaw/pitch. Re-uploading a sequence replaces the previous frame. At least 8 usable images are required to complete a session; all 12 horizontal guide steps are recommended for full coverage.

## 4. Panorama processing and approval

The Celery worker prefers Hugin (`pto_gen`, `cpfind`, `cpclean`, `autooptimiser`, `pano_modify`, `nona`, `enblend`). OpenCV is the fallback. Output is versioned and flagged for visual review because successful feature matching does not prove complete spherical coverage or artifact-free seams. Approval changes the current panorama version to `approved`.

## 5. Navigation and hotspots

Create directed or bidirectional `SceneLink` records between rooms. Yaw/pitch place the navigation target in the source panorama. `Hotspot` supports information and navigation. Cross-tour navigation targets are rejected.

## 6. Dollhouse and plan editing

Edit room geometry in the canonical metric coordinate system. Define explicit wall segments and door/window/arch openings when the room outline alone is insufficient. The GLB worker creates a roofless architectural shell from room polygons/rectangles and explicit walls. It preserves floor elevations and exports a versioned GLB asset. Review the dimensions and wall placement before treating the model as accurate.

## 7. LiDAR and depth input

The original scan is stored with source and coordinate unit. The built-in scan reader creates a GLB point-cloud preview for XYZ, PTS, ASCII PLY, ASCII PCD, NPY and NPZ. LAS/LAZ require `laspy[lazrs]`. This preview helps inspect spatial coverage and bounds; it does not reconstruct walls or a watertight mesh. Depth maps and photogrammetry image bundles are stored for a future specialized reconstruction adapter.

## 8. Quality and publication

The quality report aggregates per-frame blur/exposure/resolution/duplicate indicators, rejected images, yaw gaps, missing guide steps and panorama readiness. Ghosting, stitching seams, room completeness and geometry accuracy still require human review. Publishing is blocked until every active room has an approved current panorama version.
