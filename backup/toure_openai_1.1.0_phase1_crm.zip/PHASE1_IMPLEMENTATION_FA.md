# بنیان ملک — Phase 1: CRM & Customer Activity Core

## وضعیت بسته
Phase 1 روی نسخه 1.0.4 Phase 0 worktree پیاده شده است. این بسته شامل تغییرات کد و migration جدید است؛ آزمون عملی Django/DB در محیط فاقد Django و DB اجرا نشده، بنابراین تحویل به معنی تأیید runtime نیست.

## قابلیت‌های پیاده‌سازی‌شده
- Timeline یکپارچه با تعامل‌ها، وظایف، بازدید، مذاکره، قرارداد، اسناد، انتقال مسئول و فعالیت‌های سرنخ مرتبط.
- تشخیص مشتری تکراری در همان آژانس: تطبیق شماره تلفن/ایمیل با نرمال‌سازی ارقام فارسی/عربی و امتیاز شباهت نام (آستانه 0.88).
- ادغام دو پرونده درون یک آژانس، بازتخصیص FKها، نگه‌داشتن فیلدهای canonical، آرشیو پرونده duplicate و Audit event. تعارض Pipeline canonical حفظ می‌شود؛ اشتراک‌های هم‌عضو deduplicate می‌شوند.
- انتقال مسئول مشتری با کنترل عضو فعال/آژانس/شعبه، علت الزامی، تاریخچه `CustomerTransfer` و audit.
- API برای Timeline، duplicate lookup، merge، transfer، ایجاد task و تغییر وضعیت task.
- Timeline به صفحه جزئیات مشتری افزوده شده است.
- Permissionهای `customer.transfer` و `customer.merge` ثبت و به roleهای مدیریتی مربوط تخصیص یافته‌اند.

## API جدید
- `GET /api/v1/customers/{customer_id}/timeline?limit=100`
- `GET /api/v1/customers/{customer_id}/duplicates`
- `POST /api/v1/customers/merge` — body: `primary_customer_id`, `duplicate_customer_id`
- `POST /api/v1/customers/{customer_id}/transfer` — body: `target_membership_id`, `reason`
- `POST /api/v1/customers/{customer_id}/tasks` — body: `assigned_membership_id`, `title`, `due_at`
- `PATCH /api/v1/customer-tasks/{task_id}/status` — body: `status` (`OPEN`, `COMPLETED`, `CANCELLED`)

## Migration
`apps/customers/migrations/0003_customertransfer.py`


## تست/اعتبارسنجی انجام‌شده
- Python compileall برای فایل‌های تغییرکرده: موفق.
- TypeScript/TSX syntax parse صفحه مشتری: بدون diagnostic نحوی.
- Django migrations، service tests، API tests، PostgreSQL integration، tenant/security scenarios و Next production build اجرا نشده‌اند.

## محدودیت و موارد قابل توجه
- Duplicate detection، heuristic است؛ merge فقط با اقدام صریح API انجام می‌شود.
- Merge رابطه‌ها به صورت تراکنشی انجام می‌شود و تعارض DB باعث rollback می‌شود. در مدل‌هایی که uniqueness business-specific دارند، پیش از rollout باید داده staging و migration behavior بررسی شود.
- Timeline به scopeهای موجود در `get_customer_detail` متکی است. در صورت اضافه شدن نوع رابطه جدید، باید timeline آن هم به این stream اضافه شود.
- برای API merge/transfer باید مجوزها در seed اعمال شده و در دیتابیس موجود role permissionها به‌روز شوند (seed runner).
- UI برای duplicate review/merge و transfer هنوز workflow wizard ندارد؛ API و backend structure فراهم شده است.
- CustomerShare API نمایش فقط shareهای معتبر و دارای expiry؛ endpoint لغو اشتراک نیز اضافه شد: `DELETE /api/v1/customers/{customer_id}/share/{membership_id}`.
- صفحه جزئیات مشتری اکنون بخش Timeline یکپارچه، بررسی موارد تکراری با گزینه ادغام تأییدشده و فرم انتقال مسئول همراه علت را دارد.
