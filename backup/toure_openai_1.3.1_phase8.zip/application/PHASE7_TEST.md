# Phase 7 — Deal Financial Summary (v1.3.0)

## UI test
1. Start backend and frontend; sign in and select an agency.
2. Open Dashboard → معاملات (`/dashboard/deals`).
3. Confirm the new **خلاصه مالی معاملات** panel loads above the deals table.
4. Compare each currency bucket with the ledger records for the deals visible to your account. Values must remain grouped by currency (no cross-currency total).
5. Confirm the displayed values: total deal amount, received, receivable (never negative), paid, net profit, and settlement counts (settled / partial / open).
6. Switch to an account with access to only its own deals and verify summary totals are limited to those visible deals.
7. If no ledger exists for visible deals, the panel should show the empty-state message rather than an error.

## API test
- GET `/api/v1/deals/financial-summary` with a valid agency token and agency header.
- Verify response includes `deal_count` and `currencies[]`.
- Each currency bucket includes `deal_amount`, `received`, `paid`, `receivable`, `net_profit`, `ledger_count`, and settlement counts.
- Verify amounts are strings and each currency is a separate bucket.
- Verify `receivable` equals sum of max(0, deal_amount - total_received) per ledger.

## Checks performed for this package
- Python syntax compile for the changed API module.
- ZIP integrity check.
- Frontend production build/typecheck was not run in this environment (node_modules not installed).
