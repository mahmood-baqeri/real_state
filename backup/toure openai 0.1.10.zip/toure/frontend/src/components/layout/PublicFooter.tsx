"use client";

import React from "react";
import Link from "next/link";
import { Building2 } from "lucide-react";
import { usePublicConfig } from "@/lib/public-config-context";
import { useTheme } from "@/lib/theme-context";

export function PublicFooter() {
  const { getSetting, getBrandAsset, legalDocuments } = usePublicConfig();
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === "dark";

  const platformName = getSetting<string>("general.platform_name_fa", "بنیان ملک");
  const tagline = getSetting<string>(
    "general.footer_tagline",
    "پلتفرم سازمانی چندآژانسی مدیریت املاک، پایپ‌لاین فروش CRM، محاسبه دقیق کمیسیون و حسابداری دوطرفه برای شبکه حرفه‌ای مشاوران املاک."
  );
  const copyrightText = getSetting<string>(
    "general.copyright_text",
    "© ۱۴۰۵ پلتفرم سازمانی بنیان ملک — تمامی حقوق محفوظ است."
  );
  const logoUrl = getBrandAsset(isDark ? "site_logo_dark" : "site_logo_light", isDark, "");

  return (
    <footer className="border-t border-slate-200 bg-white text-slate-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-2 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between">
          <span className="font-semibold text-slate-700 dark:text-slate-300">{platformName}</span>
        </div>

        <div className="mt-3 flex flex-col items-center justify-between gap-3 border-t border-slate-200 pt-6 text-[11px] dark:border-slate-800 sm:flex-row">
          <span>{copyrightText}</span>
          <div className="flex flex-wrap items-center gap-4">
            {legalDocuments.length > 0 ? (
              legalDocuments.slice(0, 2).map((doc) => (
                <Link
                  key={doc.slug}
                  href={`/legal/${doc.slug}`}
                  className="hover:text-teal-700 dark:hover:text-teal-400"
                >
                  {doc.title_fa}
                </Link>
              ))
            ) : (
              <>
                <Link href="/privacy" className="hover:text-teal-700 dark:hover:text-teal-400">
                  حریم خصوصی
                </Link>
                <Link href="/terms-of-use" className="hover:text-teal-700 dark:hover:text-teal-400">
                  شرایط استفاده
                </Link>
              </>
            )}
            <Link href="/careers" className="hover:text-teal-700 dark:hover:text-teal-400">
              فرصت‌های شغلی
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
