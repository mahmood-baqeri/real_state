"use client";

import React, { useMemo, useState } from "react";
import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import {
  GitCompareArrows,
  LayoutGrid,
  Map as MapIcon,
  MapPin,
  RotateCcw,
  Search,
  SlidersHorizontal,
  X,
} from "lucide-react";
import { apiFetch } from "@/lib/api-client";
import type { PublicSearchProperty } from "@/lib/types";
import { PublicHeader } from "@/components/layout/PublicHeader";
import { PublicFooter } from "@/components/layout/PublicFooter";
import { PropertyCard } from "@/components/properties/PropertyCard";
import {
  InteractiveMap,
  buildPropertyPriceLabel,
  type MapMarkerItem,
} from "@/components/ui/InteractiveMap";
import { ErrorState, LoadingState } from "@/components/ui/StateNotice";
import { formatNumberFa } from "@/lib/formatters";

interface GeoBounds {
  min_lat: number;
  max_lat: number;
  min_lng: number;
  max_lng: number;
}

export default function AdvancedSearchPage() {
  const [viewMode, setViewMode] = useState<"list" | "split">("split");
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [pendingBounds, setPendingBounds] = useState<GeoBounds | null>(null);
  const [appliedBounds, setAppliedBounds] = useState<GeoBounds | null>(null);

  const [filters, setFilters] = useState({
    q: "",
    city: "تهران",
    district: "",
    deal_type: "",
    property_type: "",
    min_price: "",
    max_price: "",
    min_area: "",
    min_bedrooms: "",
  });
  const [applied, setApplied] = useState(filters);

  const searchQ = useQuery({
    queryKey: ["advanced-public-search", applied, appliedBounds],
    queryFn: async () => {
      const p = new URLSearchParams();
      Object.entries(applied).forEach(([k, v]) => {
        if (v) p.set(k, v);
      });
      if (appliedBounds) {
        p.set("min_lat", String(appliedBounds.min_lat));
        p.set("max_lat", String(appliedBounds.max_lat));
        p.set("min_lng", String(appliedBounds.min_lng));
        p.set("max_lng", String(appliedBounds.max_lng));
      }
      return (await apiFetch<PublicSearchProperty[]>(`/api/v1/search/properties?${p.toString()}`)).data;
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setApplied(filters);
  };

  const toggleCompare = (id: string) => {
    setCompareIds((prev) => {
      if (prev.includes(id)) return prev.filter((item) => item !== id);
      if (prev.length >= 4) return prev;
      return [...prev, id];
    });
  };

  const items = useMemo(() => searchQ.data || [], [searchQ.data]);

  const mapMarkers: MapMarkerItem[] = useMemo(() => {
    return items
      .filter((p) => p.latitude && p.longitude)
      .map((p) => ({
        id: p.id,
        title: p.title,
        subtitle: `${p.city}${p.district ? `، ${p.district}` : ""}`,
        lat: Number(p.latitude),
        lng: Number(p.longitude),
        priceText: buildPropertyPriceLabel(
          p.total_price,
          p.deposit_amount,
          p.rent_amount,
          p.deal_type_id,
          p.currency_id
        ),
        hideExactAddress: true,
        href: `/properties/${p.id}`,
      }));
  }, [items]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950">
      <PublicHeader />
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-8 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">
              جستجوی پیشرفته و نقشه املاک
            </h1>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-400">
              فیلتر بر اساس محله، بودجه، متراژ و محدوده جغرافیایی همراه با مقایسه هم‌زمان تا ۴ ملک
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <Link
              href="/explore/tehran/zafaranieh"
              className="inline-flex items-center gap-1 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-1.5 font-medium text-slate-700 dark:text-slate-300 hover:border-teal-600"
            >
              <MapPin className="h-3.5 w-3.5 text-teal-700 dark:text-teal-400" />
              زعفرانیه تهران
            </Link>
            <Link
              href="/explore/tehran/fereshteh"
              className="inline-flex items-center gap-1 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-1.5 font-medium text-slate-700 dark:text-slate-300 hover:border-teal-600"
            >
              <MapPin className="h-3.5 w-3.5 text-teal-700 dark:text-teal-400" />
              فرشته تهران
            </Link>

            <div className="inline-flex items-center rounded-lg border border-slate-200 bg-white p-0.5 dark:border-slate-800 dark:bg-slate-900">
              <button
                type="button"
                onClick={() => setViewMode("split")}
                className={`inline-flex h-8 items-center gap-1.5 rounded-md px-3 font-semibold transition-colors ${
                  viewMode === "split"
                    ? "bg-teal-700 text-white"
                    : "text-slate-600 dark:text-slate-300"
                }`}
              >
                <MapIcon className="h-3.5 w-3.5" />
                نقشه + فهرست
              </button>
              <button
                type="button"
                onClick={() => setViewMode("list")}
                className={`inline-flex h-8 items-center gap-1.5 rounded-md px-3 font-semibold transition-colors ${
                  viewMode === "list"
                    ? "bg-teal-700 text-white"
                    : "text-slate-600 dark:text-slate-300"
                }`}
              >
                <LayoutGrid className="h-3.5 w-3.5" />
                شبکه‌ای
              </button>
            </div>
          </div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4"
        >
          <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
            <SlidersHorizontal className="h-4 w-4 text-teal-700 dark:text-teal-400" />
            فیلترهای تخصصی جستجو
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <input
              placeholder="کلیدواژه یا کد ملک..."
              value={filters.q}
              onChange={(e) => setFilters({ ...filters, q: e.target.value })}
              className="h-10 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 text-sm text-slate-900 dark:text-slate-100"
            />
            <input
              placeholder="شهر (تهران)"
              value={filters.city}
              onChange={(e) => setFilters({ ...filters, city: e.target.value })}
              className="h-10 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 text-sm text-slate-900 dark:text-slate-100"
            />
            <input
              placeholder="منطقه یا محله (مثلاً زعفرانیه)"
              value={filters.district}
              onChange={(e) => setFilters({ ...filters, district: e.target.value })}
              className="h-10 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 text-sm text-slate-900 dark:text-slate-100"
            />
            <select
              value={filters.deal_type}
              onChange={(e) => setFilters({ ...filters, deal_type: e.target.value })}
              className="h-10 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 text-sm text-slate-900 dark:text-slate-100"
            >
              <option value="">همه انواع معامله</option>
              <option value="SALE">فروش</option>
              <option value="MORTGAGE_RENT">رهن و اجاره</option>
            </select>
            <select
              value={filters.property_type}
              onChange={(e) => setFilters({ ...filters, property_type: e.target.value })}
              className="h-10 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 text-sm text-slate-900 dark:text-slate-100"
            >
              <option value="">همه کاربری‌ها</option>
              <option value="APARTMENT">آپارتمان</option>
              <option value="VILLA">ویلا</option>
              <option value="OFFICE">اداری</option>
              <option value="LAND">زمین</option>
            </select>
            <input
              type="number"
              placeholder="حداقل متراژ (مترمربع)"
              value={filters.min_area}
              onChange={(e) => setFilters({ ...filters, min_area: e.target.value })}
              className="h-10 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 font-mono text-sm text-slate-900 dark:text-slate-100"
            />
            <input
              type="number"
              placeholder="حداقل تعداد خواب"
              value={filters.min_bedrooms}
              onChange={(e) => setFilters({ ...filters, min_bedrooms: e.target.value })}
              className="h-10 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 font-mono text-sm text-slate-900 dark:text-slate-100"
            />
            <button
              type="submit"
              className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-teal-700 px-4 text-sm font-semibold text-white hover:bg-teal-800"
            >
              <Search className="h-4 w-4" />
              اعمال فیلتر و جستجو
            </button>
          </div>
        </form>

        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 dark:text-slate-400">
          <span>
            نتایج مطابق با فیلترهای شما (برای مقایسه، دکمه «مقایسه» روی ۲ تا ۴ کارت را انتخاب کنید)
          </span>
          <div className="flex items-center gap-3">
            {appliedBounds && (
              <button
                type="button"
                onClick={() => setAppliedBounds(null)}
                className="inline-flex items-center gap-1 font-semibold text-amber-700 hover:underline dark:text-amber-400"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                حذف محدوده جغرافیایی نقشه
              </button>
            )}
            <span className="font-mono font-bold">{formatNumberFa(items.length)} ملک</span>
          </div>
        </div>

        {searchQ.isLoading ? (
          <LoadingState message="در حال جستجوی پیشرفته..." />
        ) : searchQ.error ? (
          <ErrorState
            message={searchQ.error instanceof Error ? searchQ.error.message : "خطا در جستجو"}
            onRetry={() => searchQ.refetch()}
          />
        ) : viewMode === "split" ? (
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
            <div className="lg:col-span-5 lg:sticky lg:top-20 lg:self-start space-y-3">
              <InteractiveMap
                markers={mapMarkers}
                heightClass="h-[460px]"
                onBoundsChange={(b) => setPendingBounds(b)}
              />
              {pendingBounds && (
                <button
                  type="button"
                  onClick={() => setAppliedBounds(pendingBounds)}
                  className="inline-flex h-9 w-full items-center justify-center gap-1.5 rounded-lg border border-teal-700 bg-teal-50 text-xs font-semibold text-teal-800 hover:bg-teal-100 dark:border-teal-500 dark:bg-teal-950/60 dark:text-teal-300"
                >
                  <MapPin className="h-3.5 w-3.5" />
                  جستجو در این محدوده نقشه
                </button>
              )}
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                دایره‌های سبز روی نقشه محدوده تقریبی ملک را با حفظ حریم خصوصی پلاک مالک نمایش
                می‌دهند.
              </p>
            </div>

            <div className="lg:col-span-7">
              {items.length === 0 ? (
                <div className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-10 text-center text-sm text-slate-600 dark:text-slate-400">
                  ملکی با این مشخصات یافت نشد. فیلترها یا محدوده نقشه را تغییر دهید یا{" "}
                  <Link href="/requests/new" className="font-bold text-teal-700 dark:text-teal-400 underline">
                    درخواست خرید اختصاصی ثبت کنید
                  </Link>
                  .
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  {items.map((p, idx) => (
                    <PropertyCard
                      key={p.id}
                      property={p}
                      index={idx}
                      isSelectedForCompare={compareIds.includes(p.id)}
                      onToggleCompare={toggleCompare}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : items.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-10 text-center text-sm text-slate-600 dark:text-slate-400">
            ملکی با این مشخصات یافت نشد. فیلترها را ساده‌تر کنید یا{" "}
            <Link href="/requests/new" className="font-bold text-teal-700 dark:text-teal-400 underline">
              درخواست خرید اختصاصی ثبت کنید
            </Link>
            .
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((p, idx) => (
              <PropertyCard
                key={p.id}
                property={p}
                index={idx}
                isSelectedForCompare={compareIds.includes(p.id)}
                onToggleCompare={toggleCompare}
              />
            ))}
          </div>
        )}
      </main>

      {compareIds.length > 0 && (
        <div className="sticky bottom-4 z-40 mx-auto w-full max-w-2xl px-4">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-teal-700 bg-slate-900 px-4 py-3 text-white shadow-xl">
            <div className="flex items-center gap-2 text-xs">
              <GitCompareArrows className="h-4 w-4 text-teal-400" />
              <span className="font-semibold">
                {formatNumberFa(compareIds.length)} ملک برای مقایسه انتخاب شده (حداکثر ۴ ملک)
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setCompareIds([])}
                className="inline-flex h-8 items-center gap-1 rounded-lg border border-slate-700 px-2.5 text-xs text-slate-300 hover:bg-slate-800"
              >
                <X className="h-3.5 w-3.5" />
                پاک کردن
              </button>
              {compareIds.length >= 2 ? (
                <Link
                  href={`/properties/compare?ids=${compareIds.join(",")}`}
                  className="inline-flex h-8 items-center gap-1.5 rounded-lg bg-teal-600 px-3.5 text-xs font-semibold text-white hover:bg-teal-500"
                >
                  مشاهده جدول مقایسه
                </Link>
              ) : (
                <span className="text-[11px] text-slate-400">حداقل ۱ ملک دیگر انتخاب کنید</span>
              )}
            </div>
          </div>
        </div>
      )}

      <PublicFooter />
    </div>
  );
}
