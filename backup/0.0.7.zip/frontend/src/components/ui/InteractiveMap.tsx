"use client";

import React, { useEffect, useRef } from "react";
import "leaflet/dist/leaflet.css";
import { formatMoney } from "@/lib/formatters";
import type { CurrencyCode } from "@/lib/types";

export interface MapMarkerItem {
  id: string;
  title: string;
  lat: number;
  lng: number;
  priceText?: string;
  subtitle?: string;
  hideExactAddress?: boolean;
  href?: string;
}

export function InteractiveMap({
  markers,
  center = [35.7575, 51.41],
  zoom = 12,
  heightClass = "h-[420px]",
  onBoundsChange,
  onSelectMarker,
}: {
  markers: MapMarkerItem[];
  center?: [number, number];
  zoom?: number;
  heightClass?: string;
  onBoundsChange?: (bounds: {
    min_lat: number;
    max_lat: number;
    min_lng: number;
    max_lng: number;
  }) => void;
  onSelectMarker?: (id: string) => void;
}) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<import("leaflet").Map | null>(null);
  const layerGroupRef = useRef<import("leaflet").LayerGroup | null>(null);
  const boundsCallbackRef = useRef(onBoundsChange);
  const selectCallbackRef = useRef(onSelectMarker);

  boundsCallbackRef.current = onBoundsChange;
  selectCallbackRef.current = onSelectMarker;

  useEffect(() => {
    let active = true;
    (async () => {
      if (!containerRef.current || mapRef.current) return;
      const L = await import("leaflet");
      if (!active || !containerRef.current) return;

      const map = L.map(containerRef.current, {
        center,
        zoom,
        scrollWheelZoom: false,
      });

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "&copy; OpenStreetMap",
        maxZoom: 18,
      }).addTo(map);

      const group = L.layerGroup().addTo(map);
      mapRef.current = map;
      layerGroupRef.current = group;

      map.on("moveend", () => {
        if (!boundsCallbackRef.current) return;
        const b = map.getBounds();
        boundsCallbackRef.current({
          min_lat: Number(b.getSouth().toFixed(5)),
          max_lat: Number(b.getNorth().toFixed(5)),
          min_lng: Number(b.getWest().toFixed(5)),
          max_lng: Number(b.getEast().toFixed(5)),
        });
      });
    })();

    return () => {
      active = false;
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
        layerGroupRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    let active = true;
    (async () => {
      const map = mapRef.current;
      const group = layerGroupRef.current;
      if (!map || !group) return;
      const L = await import("leaflet");
      if (!active) return;

      group.clearLayers();
      const valid = markers.filter(
        (m) => Number.isFinite(m.lat) && Number.isFinite(m.lng)
      );

      for (const m of valid) {
        if (m.hideExactAddress) {
          const circle = L.circle([m.lat, m.lng], {
            radius: 450,
            color: "#0f766e",
            fillColor: "#14b8a6",
            fillOpacity: 0.22,
            weight: 2,
          });
          circle.bindPopup(
            `<div dir="rtl" style="font-family:Vazirmatn,sans-serif;min-width:170px">
              <div style="font-weight:700;font-size:13px;margin-bottom:4px">${m.title}</div>
              ${m.subtitle ? `<div style="font-size:11px;color:#475569">${m.subtitle}</div>` : ""}
              ${m.priceText ? `<div style="font-weight:700;color:#0f766e;margin-top:4px;font-size:12px">${m.priceText}</div>` : ""}
              <div style="font-size:10px;color:#64748b;margin-top:4px">محدوده تقریبی جهت حفظ حریم خصوصی مالک</div>
            </div>`
          );
          circle.on("click", () => selectCallbackRef.current?.(m.id));
          circle.addTo(group);
        } else {
          const marker = L.circleMarker([m.lat, m.lng], {
            radius: 9,
            color: "#ffffff",
            weight: 2.5,
            fillColor: "#0f766e",
            fillOpacity: 1,
          });
          const linkHtml = m.href
            ? `<div style="margin-top:6px"><a href="${m.href}" style="color:#0f766e;font-weight:700;font-size:11px;text-decoration:underline">مشاهده ملک</a></div>`
            : "";
          marker.bindPopup(
            `<div dir="rtl" style="font-family:Vazirmatn,sans-serif;min-width:170px">
              <div style="font-weight:700;font-size:13px;margin-bottom:4px">${m.title}</div>
              ${m.subtitle ? `<div style="font-size:11px;color:#475569">${m.subtitle}</div>` : ""}
              ${m.priceText ? `<div style="font-weight:700;color:#0f766e;margin-top:4px;font-size:12px">${m.priceText}</div>` : ""}
              ${linkHtml}
            </div>`
          );
          marker.on("click", () => selectCallbackRef.current?.(m.id));
          marker.addTo(group);
        }
      }

      if (valid.length === 1) {
        map.setView([valid[0].lat, valid[0].lng], 14);
      } else if (valid.length > 1) {
        const latLngs = valid.map((m) => [m.lat, m.lng] as [number, number]);
        map.fitBounds(L.latLngBounds(latLngs), { padding: [36, 36], maxZoom: 14 });
      }
    })();
    return () => {
      active = false;
    };
  }, [markers]);

  return (
    <div
      ref={containerRef}
      className={`w-full overflow-hidden rounded-xl border border-slate-200 bg-slate-100 dark:border-slate-800 dark:bg-slate-800 ${heightClass}`}
    />
  );
}

export function buildPropertyPriceLabel(
  totalPrice: string,
  depositAmount: string,
  rentAmount: string,
  dealTypeId: string,
  currency: CurrencyCode
): string {
  if (dealTypeId === "MORTGAGE_RENT") {
    return `ودیعه: ${formatMoney(depositAmount, currency, currency)} · اجاره: ${formatMoney(
      rentAmount,
      currency,
      currency
    )}`;
  }
  return formatMoney(totalPrice, currency, currency);
}
