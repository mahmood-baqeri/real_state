# Changelog 0.1.11
- Restored footer upper content/navigation and retained compact legal/copyright row.
- Pricing cycle selector fits its container without wrapping.
- Auto-redirect to configured live payment gateway after checkout initiation (sandbox unchanged).
- Toast notifications positioned fixed at top-left.
- Columns popover waits for computed position and flips/clamps to viewport.
