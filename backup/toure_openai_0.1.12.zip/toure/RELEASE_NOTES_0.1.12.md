# Release notes — 0.1.12

Toast position and spacing fixed to physical top-left. Server requests and page navigation show distinct progress loaders. Agency managers are blocked from the platform roles/access-policy page and platform-level notification sending. Agency team/agent/employee pages are tenant-scoped to the active agency.


Build was not run because frontend dependencies are unavailable in the current environment.
