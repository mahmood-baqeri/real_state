# Toure OpenAI 0.1.10

## Changes

- Restricted platform settings, provider configurations/tests, CMS management, and audit logs to `SUPER_ADMIN` only at both navigation/UI and backend service boundaries.
- Removed CMS, system-settings, and audit navigation for agency managers; direct route screens also show an access-denied state.
- Added a lightweight animated progress indicator for dashboard route changes and upgraded shared request loading states with spinner/progress/skeleton UI.
- Simplified public footer layout and reduced legal-document links shown in the footer.
- Added subscription duration choices: 1, 2, 3, 6, and 12 months in public pricing, subscription checkout, and admin assignment. Twelve months uses annual plan pricing; shorter terms are monthly-price multiplied by months.
- Kept legacy MONTHLY/ANNUAL cycle identifiers accepted for backward compatibility.
- Added migration `0002_billing_cycle_terms.py` for subscription-cycle choice metadata.

## Verification

- Python changed modules passed `compileall`.
- Modified TS/TSX files passed TypeScript transpilation syntax checks.
- Full TypeScript type-check/build and backend tests could not be run because frontend node modules and Django dependencies are not installed in this environment.
