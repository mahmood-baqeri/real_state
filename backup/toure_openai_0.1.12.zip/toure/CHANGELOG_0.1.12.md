# TOURE OpenAI 0.1.12

## Fixes
- Toast notifications use explicit physical top-left viewport coordinates with 20px edge spacing; during server requests they stack below the request status chip.
- Server-request loader stays top-left and shows a compact status/progress indicator.
- Dashboard page-transition progress loader remains active and uses a polished animated top bar and status chip.
- Platform roles/access-policy page is restricted to SUPER_ADMIN in navigation, direct-route guard, and query activation.
- Platform access-policy read/update APIs return 403 to non-SUPER_ADMIN users.
- Custom role creation endpoint is restricted to SUPER_ADMIN.
- Global notification sending endpoint is restricted to SUPER_ADMIN; non-admins can still read their own notifications.
- Notification page hides global send controls and push management/testing panel for non-SUPER_ADMIN users.
- Agency team, agents, and employee lists continue to use the active agency context and agency-scoped endpoints.

## Verification
- Python FastAPI API modules compile with `python -m compileall`.
- TypeScript compiler was invoked for syntax diagnostics; full type/build verification is blocked by missing frontend dependencies (React/Next and other packages are not installed in this environment).
