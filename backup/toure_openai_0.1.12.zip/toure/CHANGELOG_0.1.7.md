# Changelog 0.1.7

- Fixed particles being hidden beneath route content.
- Removed blend mode that reduced visibility on bright backgrounds.
- Added smooth mouse interaction, particle twinkle/glow, and clearer network lines.
- Kept reduced-motion and tab-visibility behavior.
