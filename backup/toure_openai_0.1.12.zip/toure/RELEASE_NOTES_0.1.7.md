# TOURE OPENAI 0.1.7 — Particle Visibility & Interaction Fix

## Changes
- Particle canvas now renders above route content (z-index 7) while remaining click-through.
- Removed `screen` blending and retained normal compositing for clearer particles in light and dark themes.
- Added soft mouse repulsion within a bounded radius; particles return to their natural drift.
- Added subtle point twinkle and glow, with stronger connection visibility.
- Respects `prefers-reduced-motion` by rendering a static frame; pauses when the document is hidden.
- Kept existing particle enable setting and global visual-effects switch.


## Notes
- This is a focused frontend change. No backend behavior or settings schema changed.
- TypeScript/build verification could not be run in this environment because frontend dependencies are not installed.
