# Audit — TOURE 0.1.7

## Particle fixes
- Canvas stacking changed from z-index 2 to 7, above route content, with `pointer-events:none`.
- Removed `mix-blend-mode:screen`; canvas uses normal blending and full CSS opacity.
- Added mouse pointer tracking and bounded, smooth particle repulsion.
- Added twinkle and glow effects to points and increased connection visibility.
- Static render under `prefers-reduced-motion`; animation pauses while document is hidden.
- Existing global and particle toggles remain in place.

## Verification
- Source inspected and targeted code/CSS updated.
- Build/type-check not executed: frontend dependencies (`node_modules`) are absent in this workspace.
