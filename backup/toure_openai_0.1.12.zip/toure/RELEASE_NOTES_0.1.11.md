# TOURE OpenAI 0.1.11 — Fixes Requested

## 1. Public footer
- Restored the upper footer content and navigation columns (portal/search, agency services, support).
- Kept the lower copyright/legal area compact, showing up to two legal-document links plus careers.
- Reduced overall vertical padding compared with the original expanded footer.

## 2. Pricing billing-cycle selector
- Changed the five billing-cycle choices to a compact, non-wrapping equal-width segmented row.
- Reduced button horizontal padding and font size on narrow screens to keep choices within the selector box.

## 3. Payment gateway handoff
- On successful non-sandbox checkout initiation, automatically redirect browser to the gateway redirect_url.
- Sandbox continues to remain on the page for simulation/verification.
- Plan prices are edited in Dashboard > Subscriptions (plan create/edit form: monthly and annual prices; intermediate cycles derive from monthly pricing).

## 4. Toast placement
- Toast stack moved from bottom-left to top-left, fixed to viewport with a high z-index.

## 5. DataTable columns menu
- Prevent rendering until button-relative viewport position is calculated, eliminating the initial (0,0) flash.
- Position below button when space allows; otherwise flip above; clamp horizontal position within viewport.

## Validation
- Source-level changes applied and archive integrity checked.
- Frontend dependencies are not installed in this environment; production build and browser visual test not performed.
