# Changelog 0.1.8

- Improved particle visibility: top overlay z-index, white core, accent glow, brighter connection lines.
- Added profile-consistent actual UI treatment to controls for Aurora, Obsidian, Crystal, and Holographic profiles.
- Demo cards remain previews; selecting a profile applies its matching global profile CSS to the actual application UI.
