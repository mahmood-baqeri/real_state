# TOURE OpenAI 0.1.9

## Focused UI fixes
- Provider adapter key field in the AI/Map/SMS settings modal is now a category-aware select instead of a free-text input.
- Provider options use registered backend keys: AI `gapgpt`; maps `osm`, `carto`, `neshan`, `custom_tile`; SMS `console`, `kavenegar`, `melipayamak`, `smsir`.
- DataTable column visibility menu is rendered in a portal attached to `document.body` and positioned fixed relative to its trigger, preventing clipping by table/card containers.

## Validation
- Source changes and archive structure checked.
- Build/typecheck not run: frontend dependencies are not installed in this environment.
