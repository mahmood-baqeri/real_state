# TOURE OpenAI 0.1.8

## Fixes
- Particle canvas is forced to the top overlay layer with pointer-events disabled, preventing page content stacking from hiding it.
- Particle dots now render a white high-contrast core with palette-colored glow and stronger visible connecting lines for light and dark backgrounds.
- Profile visual treatments have more consistent styling on actual controls and common UI surfaces, not only the preview cards.

## Verification status
- Source changes applied to the 0.1.7 working tree.
- Build/type-check not yet verified in this environment; dependencies may be unavailable.
