# Changelog

## 0.1.14-phase0 — Phase 0 hardening candidate

- Fail-closed tenant context, PostgreSQL RLS policies and branch-scoped authorization.
- Private media separation and legacy document/property/virtual-tour asset migration commands.
- Production secret/encryption/payment-provider guards and encrypted-field rotation.
- CRM private-note/share-expiry and document action permission enforcement.
- Report scope, customer requirement matching, public price aggregate threshold, SSRF hardening.
- One-time WebSocket tickets and bounded upload streaming.
- Accounting reversal, commission validation, payroll eligibility/cancellation and appointment locking.
- Added Phase 0 release notes and acceptance test plan.
- Production release remains gated on staging PostgreSQL, two-agency, storage migration and full frontend build tests.

## 0.1.15-phase0
- بسته‌بندی کامل سورس Phase 0 با راهنمای تحویل فارسی و دستورهای اجرای تست PowerShell.
- ثبت شفاف اینکه تست‌ها در این نوبت به درخواست کاربر اجرا نشده‌اند.
- فایل‌های `.env` و `.env.example` بدون تغییر باقی مانده‌اند.


## 0.1.16-phase0
- اصلاح تولید SQL مربوط به RLS و جداسازی ENABLE policy از FORCE migration.
- اصلاح تست nested tenant bypass و جلوگیری از reset تنظیم transaction-local پس از aborted transaction.
- هماهنگ‌سازی انتظار تست traversal با قرارداد `ValidationDomainError` در storage.
- توقف خودکار dry-run مهاجرت فایل‌ها در صورت وجود migration معوق.
- اجرای `check_project.ps1` از داخل `check_phase0.ps1` فقط با گزینه صریح `-IncludeBaseSuite`.
- راهنمای فارسی به‌روزرسانی شد؛ فایل‌های `.env` و `.env.example` دست‌نخورده باقی ماندند.
