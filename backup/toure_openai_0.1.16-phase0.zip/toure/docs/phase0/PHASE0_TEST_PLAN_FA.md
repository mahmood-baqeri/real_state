# برنامه تست پذیرش دقیق — Phase 0

**نسخه هدف:** `0.1.16-phase0`  
**محیط الزامی:** staging با PostgreSQL، Redis/Celery، storage خصوصی/عمومی و درگاه پرداخت تستی واقعی (نه Sandbox داخلی برنامه).  
**داده تست:** دو آژانس مستقل A و B؛ حداقل دو شعبه برای A؛ مدیر آژانس، مدیر شعبه A1، مدیر شعبه A2، مشاور A1، مشاور A2، حسابدار A، مشاور B و کاربر بدون عضویت.

## ۱) آماده‌سازی داده

1. دو آژانس A و B بسازید؛ شناسه‌ها و داده‌ها را در fixture ثبت کنید.
2. برای A دو شعبه A1 و A2 و برای B یک شعبه B1 بسازید.
3. کاربران زیر را با عضویت ACTIVE ایجاد کنید:
   - `A_OWNER`: مدیر آژانس A
   - `A_BRANCH_1`: مدیر شعبه A1
   - `A_BRANCH_2`: مدیر شعبه A2
   - `A_AGENT_1`: مشاور شعبه A1
   - `A_AGENT_2`: مشاور شعبه A2
   - `A_FINANCE`: حسابدار A
   - `B_AGENT`: مشاور آژانس B
   - `NO_MEMBERSHIP`: بدون عضویت آژانس
4. برای هر آژانس ملک، مشتری، سرنخ، مذاکره، قرارداد، بازدید، سند، کمیسیون و فعالیت بسازید.
5. برای CRM، یک یادداشت private و یک سند CONFIDENTIAL بسازید.
6. برای مشتری A، share با تاریخ آینده و share منقضی‌شده ایجاد کنید.
7. برای فایل‌ها، یک فایل public و یک فایل private در هر نوع document/property-media/virtual-tour بسازید.
8. برای مالی، یک سند حسابداری posted، یک دوره بسته و یک دوره باز، کمیسیون با وضعیت‌های مختلف و دوره حقوق بسازید.

## ۲) ماتریس تست امنیت

| شناسه | گام‌های اجرا | معیار قبولی |
|---|---|---|
| T-SEC-01 Tenant isolation | با `A_AGENT_1` شناسه ملک/مشتری/قرارداد آژانس B را در list، detail، search، update، create FK و عملیات گروهی ارسال کنید. سپس DB را بررسی کنید. | همه خواندن‌ها 404/403 یا خالی؛ تمام create/updateها رد؛ هیچ FK متقاطع یا رکورد ترکیبی ایجاد نشود. |
| T-SEC-02 Private CRM | با `A_AGENT_1`، `A_BRANCH_1`، `A_OWNER` و `A_FINANCE` فهرست تعاملات و customer detail را بخوانید. | یادداشت private فقط برای creator/نقش دارای `crm.private_note.view`؛ داده محرمانه در responseهای دیگر ظاهر نشود. |
| T-SEC-03 Expired share | یک share فعال و یک share منقضی‌شده را با VIEW و EDIT امتحان کنید؛ زمان سیستم را با timezone-aware fixture کنترل کنید. | share منقضی‌شده در list/detail/edit هیچ دسترسی ندهد؛ share معتبر فقط در سطح خودش عمل کند. |
| T-SEC-04 Private files | URL مستقیم `/media/...` برای private document، private property media و private virtual-tour asset را anonymous درخواست کنید؛ سپس endpoint API را با/بدون عضویت امتحان کنید. | static مسیر private را ارائه نکند؛ API فقط به کاربر مجاز فایل بدهد؛ دانلود private در audit ثبت شود. |
| T-SEC-05 Document permission | عضو عادی در برابر مدیر، view/upload/edit/delete/download را جداگانه اجرا کند؛ تغییر `access_level` را هم امتحان کنید. | هر action مجوز مستقل داشته باشد؛ عضو عادی سند داخلی را edit/delete یا access level را ارتقا ندهد. |
| T-SEC-06 Branch scope | `A_BRANCH_1` داده A2 را از list/detail/search/matching/dashboard/report/export و عملیات bulk درخواست کند. | هیچ داده A2 ظاهر نشود؛ ایجاد/تغییر رابطه به A2 رد شود. |
| T-SEC-07 Reports scope | خروجی dashboard و operations center را برای مدیر آژانس، مدیر شعبه، حسابدار و مشاور مقایسه کنید. | مدیر شعبه فقط عملیات شعبه خود و بدون خزانه/حقوق کل آژانس؛ حسابدار فقط حوزه مالی مجاز؛ مشاور فقط داده خود؛ مدیر آژانس در محدوده A. |
| T-SEC-08 SSRF | URLهای `localhost`, `127.0.0.1`, `::1`, `169.254.169.254`, آدرس RFC1918، دامنه با A/AAAA مختلط، redirect به private و DNS rebinding شبیه‌سازی کنید. | درخواست داخلی/metadata انجام نشود؛ redirect دنبال نشود؛ پاسخ بزرگ و Content-Length نامعتبر رد شود. |
| T-SEC-09 WebSocket revoke/replay | ticket بسازید؛ یک بار وصل شوید؛ همان ticket را دوباره مصرف کنید؛ session را revoke کنید و ticket جدید/قدیمی را امتحان کنید؛ Origin نامجاز بفرستید. | ticket فقط یک‌بار و تا ۳۰ ثانیه؛ replay/expired/revoked/Origin نامجاز رد؛ token در URL وجود نداشته باشد. |
| T-SEC-10 Production config | هرکدام از `DJANGO_SECRET_KEY`, `JWT_SIGNING_KEY`, `DJANGO_FIELD_ENCRYPTION_KEY` را خالی، کوتاه، placeholder یا مشترک قرار دهید؛ provider را sandbox/غیرفعال/بدون credential کنید. | startup یا checkout/verify در Production fail شود؛ اشتراک با پرداخت Sandbox فعال نشود. |

## ۳) ماتریس مالی و گردش کار

| شناسه | گام‌های اجرا | معیار قبولی |
|---|---|---|
| T-FIN-01 Accounting reversal | سند posted متوازن ثبت کنید؛ برگشت بزنید؛ Trial Balance و General Ledger را قبل/بعد مقایسه کنید. | اثر خالص سند اصلی و معکوس صفر؛ هر دو سند در ledger قابل ردیابی. |
| T-FIN-02 Closed-period reversal | سند در دوره بسته ثبت‌شده را بدون `reversal_period` برگردانید؛ سپس حالت بدون دوره باز را امتحان کنید. | در دوره باز جاری/بعدی همان آژانس ثبت شود؛ اگر دوره باز وجود ندارد عملیات fail شود؛ دوره بسته تغییر نکند. |
| T-FIN-03 Commission formulas | FIXED، PERCENT و TIERED را با مرزهای tier، نرخ منفی، بیش از ۱۰۰، سقف تکراری، tier نهایی بسته و policy آژانس دیگر امتحان کنید. | فقط فرمول معتبر قبول؛ جمع سهم‌ها طبق فرمول؛ نسخه policy متعلق به همان آژانس؛ duplicate commission رد. |
| T-FIN-04 Payroll eligibility | سهم‌های `CALCULATED`, `FINANCE_APPROVED`, `REJECTED` و خارج از بازه دوره بسازید و payroll را محاسبه کنید. | فقط `FINANCE_APPROVED` همان بازه وارد شود؛ سهم خارج بازه یا تأییدنشده وارد نشود. |
| T-FIN-05 Payroll cancel/idempotency | دوره را محاسبه، لغو و دوباره با دوره جدید محاسبه کنید؛ سپس یک دوره PAID را لغو کنید. | لغو سهم را آزاد کند؛ فیش‌ها CANCELLED؛ پرداخت‌شده قابل لغو نباشد؛ سهم دوباره یا دو بار پرداخت نشود. |

## ۴) گردش کار، AI و Matching

| شناسه | گام‌های اجرا | معیار قبولی |
|---|---|---|
| T-FLOW-01 Appointment race | دو درخواست هم‌زمان برای یک agent/property و بازه متداخل اجرا کنید؛ یک بار با agent مشترک و یک بار با property مشترک. | حداکثر یک رزرو موفق؛ پاسخ conflict برای دیگری؛ هیچ overlap پایدار در DB. |
| T-FLOW-02 State transitions | انتقال نامعتبر task، appointment، commission و payroll را ارسال کنید؛ status دلخواه را در API بفرستید. | انتقال خارج از state machine رد؛ وضعیت نامعتبر ذخیره نشود. |
| T-AI-01 AI contract | مسیر `topic → generate → save → publish` را با موضوعات مختلف و فیلدهای optional اجرا کنید. | response schema ثابت؛ `suggested_slug`/`slug` و `keywords: string[]` سازگار؛ بدون `undefined` و 422 ناخواسته. |
| T-AI-02 Factuality | ملکی بدون پارکینگ، نورگیری، سند یا امکانات ثبت‌شده انتخاب کنید و fallback/provider را اجرا کنید. | هیچ ویژگی ثبت‌نشده به‌عنوان واقعیت تولید نشود؛ متن fallback فقط داده‌های موجود را بازتاب دهد. |
| T-AI-03 AI privacy | پرسش عمومی بدون نیاز به پرونده مشتری و درخواست خصوصی با permissionهای متفاوت اجرا کنید؛ payload provider را mock و بررسی کنید. | اطلاعات مشتری/سند/یادداشت خصوصی بدون نیاز و consent به provider ارسال نشود. |
| T-MATCH-01 Requirement | CustomerRequirement با بودجه، شهر، متراژ، اتاق، امکانات و ارزهای متفاوت بسازید. | matching از نیاز واقعی استفاده کند؛ currency متفاوت مخلوط نشود؛ hard constraintها رعایت شوند. |
| T-MATCH-02 Property scope | `ASSIGNED`, `BRANCH`, `ALL` را برای مشاور/مدیر شعبه/مدیر آژانس امتحان کنید. | فقط ملک قابل مشاهده در نتایج؛ ملک خصوصی/پیش‌نویس در قیمت عمومی وارد نشود. |

## ۵) UI، قرارداد و کارایی

| شناسه | گام‌های اجرا | معیار قبولی |
|---|---|---|
| T-UI-01 Next build | با dependency lock نصب‌شده `npm ci` و `npm run build` اجرا کنید. | build production موفق؛ route تکراری قدیمی وجود نداشته باشد؛ `use client` در ابتدای فایل باشد. |
| T-UI-02 API contract | OpenAPI را از FastAPI تولید و TypeScript client را به‌روز کنید؛ یک response field را موقتاً تغییر دهید. | drift قرارداد باعث fail تست شود؛ فرانت‌اند به فیلد undefined متکی نباشد. |
| T-PERF-01 Large upload | فایل‌های درست زیر سقف، دقیقاً برابر سقف، یک بایت بالاتر و چند upload هم‌زمان ارسال کنید؛ RSS حافظه و proxy را پایش کنید. | فایل بزرگ با 413 قبل از خواندن کامل رد؛ مصرف حافظه به تعداد کل بایت‌های فایل‌های ردشده وابسته نشود. |
| T-PERF-02 Matching scale | حداقل ۳۰ تا ۵۰ هزار ملک tenant-scoped بسازید؛ query plan و p95 را اندازه بگیرید. | فیلتر DB و pagination قبل از scoring؛ زمان پاسخ در SLO مصوب محصول؛ عدم full-table scan غیرضروری. |

## ۶) فرمان‌های اجرای تست

از ریشه پروژه:

```bash
# 1) Python syntax
python -m compileall backend

# 2) FastAPI bounded upload tests
PYTHONPATH=backend/fastapi_core pytest -q backend/fastapi_core/tests/test_upload_limits.py

# 3) Django tests (نیازمند نصب dependencies و PostgreSQL/SQLite test config)
cd backend/django_core
python manage.py check
python manage.py makemigrations --check --dry-run
python manage.py migrate --plan
pytest tests/test_phase0_security_hardening.py

# 4) Frontend
cd ../../frontend
npm ci
npm test
npm run build
```

## ۷) گیت نهایی

Phase 0 فقط زمانی قابل تأیید Production است که:
- تمام تست‌های T-SEC، T-FIN و T-FLOW پاس شوند؛
- migration RLS روی PostgreSQL staging اجرا و با runtime role غیرمالک تأیید شود؛
- سه فرمان مهاجرت private media بدون خطای unresolved اجرا شوند؛
- key rotation بدون خطای ciphertext انجام شود؛
- `npm run build` و `python manage.py check --deploy` موفق باشند؛
- backup/restore و rollback rehearsal مستند و موفق باشد.


## ۸) اجرای یک‌جای تست روی Windows

از PowerShell در ریشه پوشه پروژه اجرا کنید:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\check_phase0.ps1 -SkipDatabaseChecks
```

پس از آماده بودن PostgreSQL و سرویس‌های وابسته، اجرای کامل:

```powershell
.\check_phase0.ps1
```

برای اجرای فقط مجموعه پایه پروژه:

```powershell
.\check_project.ps1 -Mode Full -Strict
```

گزارش هر اجرا در پوشه `validation-reports` ذخیره می‌شود. محتوای `.env` توسط اسکریپت چاپ یا تغییر داده نمی‌شود. تست‌های نیازمند DB، Redis، S3 و سرویس پرداخت باید با تنظیمات آزمایشی محیط خودتان اجرا شوند.
