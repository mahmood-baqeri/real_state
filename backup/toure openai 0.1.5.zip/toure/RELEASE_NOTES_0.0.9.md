# Release 0.0.9 — Initial stability patch

## Fixed
- Corrected the `BrandMediaSlot` identifier serialization in all four branding endpoints (`GET`, `PUT`, upload, and image delete).
- Kept the existing API `id` field as a backward-compatible alias of `slot_key`; no database schema or migration change is required.

## Added
- Regression coverage for branding list and update responses.
- A root `.gitignore` that excludes local secrets, virtual environments, Python caches, Node/Next build output, logs, and local runtime artifacts while retaining `.env.example`.

## Validation performed
- Python source compilation (`compileall`): passed.
- Static model/serializer contract check: passed (all four branding serializers now use `slot_key`).
- Django-backed pytest integration test: not executable in the packaging environment because Django is not installed there. Run it in the project's Windows virtual environment using the command in `AUDIT_REPORT_0.0.9.md`.

## Compatibility
- Existing frontend code continues to use `slot_key` as its resource key.
- The optional response `id` remains available and equals `slot_key`.
- No migrations are included or required for this fix.
