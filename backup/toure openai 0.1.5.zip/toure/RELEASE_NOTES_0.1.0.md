# Release 0.1.0 — Visual Presets & Configurable Favicon

## Scope
This release is limited to the two requested branding/UI items. Existing modules and application features are retained.

## 1. Platform visual presets
- Connected `branding.default_theme_preset` from the public settings bootstrap to the document root (`data-visual-style`).
- Implemented four distinct visual systems across shared UI surfaces, colors, typography-adjacent treatment, borders, radii, and elevation:
  - `architectural` — modern architectural teal/stone
  - `executive` — premium navy/champagne
  - `editorial` — editorial indigo/coral
  - `sand` — warm organic olive/sand
- Each preset has a visual preview card in the settings registry rather than an indistinguishable raw select value.
- Added the missing BRANDING category filter so visual identity settings are directly discoverable.
- Visual preset remains independent of the user's light/dark preference; both luminance modes are supported for all four presets.

## 2. Configurable favicon
- The public bootstrap's existing `favicon` BrandMediaSlot is now applied to the browser's icon link.
- Uploading a favicon in Settings → Branding updates the browser favicon after the public bootstrap refreshes.
- Empty or legacy invalid `/images/brand-mark.svg` values fall back to the bundled `/icon.svg`.
- New seed data uses `/icon.svg` as the valid default favicon path.

## Files changed
- `frontend/src/lib/public-config-context.tsx`
- `frontend/src/components/settings/GeneralSettingsTab.tsx`
- `frontend/src/components/settings/BrandingContentTab.tsx`
- `frontend/src/app/globals.css`
- `backend/django_core/apps/settings/seeding.py`

## Validation
- Backend Python bytecode compilation: passed.
- Full frontend TypeScript/build validation: not completed in this environment because `frontend/node_modules` is not present; the global TypeScript invocation reports missing React/Next/type packages. Run `npm ci` then `npm run lint` and `npm run build` on the Windows development machine.
- Existing deployments do not require a database migration. The legacy favicon path is handled by a frontend fallback.
