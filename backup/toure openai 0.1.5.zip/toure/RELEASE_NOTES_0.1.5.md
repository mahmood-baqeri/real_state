# TOURE 0.1.5 — Global Visual Experience

## سراسری‌سازی موتور جلوه‌ها
- موتور Visual Experience در `Providers` ریشه برنامه قرار دارد؛ بنابراین تمام مسیرهای Next.js شامل صفحات عمومی، صفحه اصلی، ورود/ثبت‌نام، جست‌وجو و املاک، پنل کاربری و پنل مدیریت از یک لایه بصری مشترک استفاده می‌کنند.
- لایه‌های محیطی به‌صورت واقعی در DOM رندر می‌شوند: نورپردازی Ambient، Canvas ذرات متصل، امواج SVG چندلایه، Grain سینمایی و Video Background با Overlay تیره.
- تنظیمات پروفایل و افکت‌ها در مرورگر ذخیره می‌شوند و پس از Refresh باقی می‌مانند.

## پروفایل‌ها
- Aurora Immersive
- Obsidian Luxury
- Crystal Infinity
- Holographic Vision
- حالت بدون پروفایل

## کنترل مستقل
- کلید فعال/غیرفعال‌سازی موتور
- کلیدهای مستقل Particles، SVG Waves، Grain و Video Background
- کنترل شدت افکت‌ها
- ورودی URL مستقیم MP4/WebM برای ویدیو؛ ویدیو تنها پس از فعال‌سازی و واردکردن آدرس معتبر بارگذاری می‌شود.

## عملکرد و دسترس‌پذیری
- Canvas ذرات با تعداد محدود و سقف DPR، توقف رندر در تب غیرفعال و احترام به `prefers-reduced-motion`.
- ویدیو با `muted`, `loop`, `playsInline` و `preload="metadata"`.
- انیمیشن مسیرها و reveal با Motion و IntersectionObserver.
- پروفایل‌ها از توکن‌های رنگ فعال استفاده می‌کنند و تنظیمات روشن/تاریک را بازنویسی نمی‌کنند.

## اعتبارسنجی
- سینتکس TSX سه فایل تغییرکرده با TypeScript transpile بررسی شد.
- توازن آکولادهای CSS بررسی شد.
- به علت نبود `node_modules` در محیط بسته‌بندی، build کامل Next.js در این محیط اجرا نشده است.
