# TOURE OPENAI — Release 0.1.3

## Visual experience
- Kept the three visual design presets (Luxury Glass, Neo Future, Organic Premium) and the fourth Custom palette option.
- Added an independent Signature Effects engine with Luxury Atmosphere, Aurora Flow, Crystal Studio, Cinematic Depth and Off modes.
- Effects apply independently from the palette and light/dark mode, and persist per browser.
- Added ambient lighting, glass blur, card elevation, refined hover/press response, focus glow, table-row feedback and reduced-motion support.

## Error fixes
- Security events now serialize `LoginAttemptLog.identifier` instead of the nonexistent `phone_number` field; the frontend uses the matching `identifier` property.
- Normal backend startup applies pending Django migrations before starting Django/FastAPI servers, preventing requests from racing a missing table after upgrades.
- Notifications WebSocket tolerates a transient missing-table database error and retries rather than terminating the socket task.
- Contract start/end datetimes are made timezone-aware before saving, removing the naive datetime warning.

## Database
- No new database migration. Normal `python backend/run.py` startup now runs `manage.py migrate --noinput`; it does not drop or reset data.
- `--reset-db` remains destructive and is only for an intentional full database reset.

## Verification status
- Python `compileall`: passed.
- TypeScript/TSX transpile syntax checks for the changed frontend files: passed.
- CSS block structure check: passed.
- Full Next.js typecheck/build and Django integration tests were not run because this packaging environment has no frontend `node_modules` and no Django installation.
