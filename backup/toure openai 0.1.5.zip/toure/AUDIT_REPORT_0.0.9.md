# Initial audit and repair report — 0.0.9

## Confirmed root cause
`backend/django_core/apps/settings/models.py` defines `BrandMediaSlot.slot_key` as the model's primary key. Django therefore does not provide an implicit `id` attribute for this model.

## Scope of repair
The incorrect `s.id` access existed in four response serializers in `backend/fastapi_core/app/api/v1/settings.py`:
- `list_branding_endpoint`
- `update_branding_slot_endpoint`
- `upload_branding_slot_endpoint`
- `delete_branding_slot_image_endpoint`

All four now serialize `id` from `s.slot_key`. The `id` response property is retained as a compatibility alias; `slot_key` remains the canonical identifier.

## Files changed
- `backend/fastapi_core/app/api/v1/settings.py`
- `backend/fastapi_core/tests/test_governance_settings_suite.py`
- `frontend/src/lib/types.ts` (contract documentation only)
- `.gitignore` (new)
- `RELEASE_NOTES_0.0.9.md` (new)

## Validation status
- Python compilation: PASS.
- Static primary-key/serializer consistency check: PASS.
- Integration test collection: BLOCKED in the packaging runtime because Django is absent (`ModuleNotFoundError: No module named 'django'`). This is an environment limitation, not a passing test. The user's local project environment should contain Django via `backend/requirements.txt`.

## Run the focused regression test on Windows
From the project root, with the project's virtual environment activated:

```powershell
python -m pytest backend/fastapi_core/tests/test_governance_settings_suite.py -k branding_endpoints -q
```

If dependencies are missing, install the project's pinned requirements first:

```powershell
pip install -r backend/requirements.txt
```

## Safety / release packaging
- The local `.env` file is intentionally not included in this release archive. Keep real credentials only in your local environment and rotate any credentials that were exposed in the original archive.
- `.env.example` is retained as the configuration template.
- No database migrations were generated or applied.

## Remaining work
This is the first incremental stability release, not a completed production certification or a full rewrite. The next step is to run the focused test in the user's Windows environment, then continue the broader backend/frontend architecture, security, and regression audit without removing existing product modules.
