# Release 0.1.1 — Eight Visual Design Systems

## Scope
Expands the platform's default visual identity from four palette-like presets to eight distinct UI design languages. Existing routes, modules, data models, and business behavior are retained.

## Eight visual styles
1. `architectural` — Architectural Minimal: mineral surfaces, disciplined grid, fine borders, calm teal accents.
2. `executive` — Executive Luxury: midnight navigation, champagne/gold details, premium elevation.
3. `glass` — Glassmorphism: translucent panels, ambient gradients, blur and layered depth.
4. `neo` — Neo Future: futuristic purple/cyan lighting, glow edges, deep-space dark mode and a coordinated light mode.
5. `soft` — Soft Neumorphism: tactile raised/recessed surfaces and soft shadows.
6. `editorial` — Editorial: strong typographic hierarchy, asymmetric accents and magazine-inspired framing.
7. `organic` — Organic: botanical/earth palette, warm atmospheric gradients and generous organic radii.
8. `swiss` — Swiss Modern: precise geometry, grid texture, sharp corners and high contrast.

All styles support both light and dark luminance modes. Visual identity is independent of the user's light/dark preference.

## Implementation
- Expanded the Settings → General → Branding preset chooser to eight visually differentiated preview cards.
- Updated the public bootstrap allowlist to recognize all eight preset identifiers.
- Added root-level visual tokens and design-specific styling for shared application surfaces, dashboard navigation/header, cards, forms, focus states and interactive surfaces.
- Added stable dashboard data hooks to target shell elements without changing component behavior.
- Updated the seed catalog's description and validation choices for new installations and future seed runs.
- Updated backend setting validation to accept the eight identifiers even on existing databases whose stored validation schema still contains the old four choices. This avoids requiring a seed run or database migration just to select a new style.
- Added an integration regression test that saves each of the eight presets and verifies the public bootstrap value.

## Database / compatibility
- No database migration is required.
- Existing selected preset remains unchanged until an administrator selects and saves another style.
- Existing light/dark preference remains separate.
- No application modules or routes were intentionally removed.

## Validation
- Backend Python compileall: passed.
- TypeScript/TSX syntax transpilation for changed TSX files: passed.
- CSS parser validation: passed.
- Full TypeScript typecheck / Next.js production build: not completed; dependency installation timed out in the packaging environment and `node_modules` was incomplete. Run `npm ci`, `npm run lint`, and `npm run build` on the Windows development machine.
- Django integration test: added but not executed in this environment because Django dependencies are not installed here.
