# TOURE OPENAI — Release 0.1.2

## Visual identity redesign

- Replaced the previous eight mostly palette-driven choices with three curated visual languages: Luxury Glass, Neo Future, and Organic Premium.
- Added a Custom palette option with four user-controlled colors: primary accent, secondary accent, page canvas, and card surface.
- Custom colors are stored in browser local storage and applied as global design tokens; choosing a custom color also marks the Custom preset for saving in platform settings.
- Kept light/dark mode independent from the visual-style selector.
- Added a separate signature-effects layer across the application: ambient page lighting, elevated interactive cards, refined hover/press motion, button sheen, focus rings, table-row feedback, glass blur, Neo grid atmosphere, and organic surface motion.
- Respects `prefers-reduced-motion` to avoid unwanted animation for users who request reduced motion.
- Updated backend setting validation and seeding choices to accept the four supported visual styles.

## Compatibility and verification

- No database migration is required; the existing setting key remains `branding.default_theme_preset`.
- Existing platform settings may still contain a legacy preset value. The frontend safely falls back to Luxury Glass until a new supported value is selected and saved.
- Python syntax compilation passed for the modified backend modules and test file.
- A full frontend TypeScript/build check could not be completed in this workspace because frontend dependencies (`node_modules`) are not installed. Install dependencies with `npm ci` before running `npm run lint` and `npm run build`.
