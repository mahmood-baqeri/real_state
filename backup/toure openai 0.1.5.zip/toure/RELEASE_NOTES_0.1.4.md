# TOURE 0.1.4 — Motion & Atmosphere Upgrade

## Visual system
- Kept the three curated color presets and the custom palette separate from the visual-effects selector.
- Expanded the visual-effects selector to eight distinct looks plus Off: Luxury Atmosphere, Aurora Flow, Crystal Studio, Cinematic Depth, Holographic Bloom, Soft Depth, Obsidian Elite, and Editorial Motion. Added pointer-following ambient spotlight, aurora atmosphere, subtle grain, stronger glass/crystal surfaces, cinematic depth, and broader card coverage.
- Effects continue to inherit the selected palette and light/dark mode through design tokens rather than replacing them.

## Motion and interaction
- Added a shared route-transition layer using the already-installed `motion` package (`AnimatePresence` and `motion.div`).
- Added viewport reveal for content sections/cards using `IntersectionObserver` and a mutation observer for dynamically rendered content.
- Added pointer-following ambient light, smooth scrolling, stronger focus-visible states, and restrained press/hover feedback.
- Honors `prefers-reduced-motion`; reveal animations are disabled when the OS requests reduced motion.

## Notes
- No additional runtime dependency was introduced; `motion` was already listed in the frontend dependencies.
- A full Next.js production build was not run in this environment because frontend dependencies are not installed (`node_modules` is absent). TypeScript transpile syntax checks and CSS brace validation passed.
