# برنامه تست Phase 0

نسخه کامل و به‌روز در `docs/phase0/PHASE0_TEST_PLAN_FA.md` قرار دارد.
