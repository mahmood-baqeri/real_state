# بنیان ملک — تحویل فاز صفر (Phase 0)

**نسخه کد:** `0.1.15-phase0`  
**وضعیت:** بسته تحویل کد و آزمون فاز صفر؛ تأیید Production منوط به اجرای تست‌های محیط مقصد است.  
**مبنای کار:** سند «گزارش تطبیق سورس با سند پایه و نقشه راه اجرایی»، نسخه ۱.۰، و سورس `toure_openai_0.1.13.zip`.

## ۱) هدف فاز صفر

فاز صفر برای تثبیت امنیت، جداسازی tenant، محرمانگی فایل‌ها و CRM، اصلاح دسترسی گزارش‌ها، جلوگیری از پرداخت آزمایشی در Production، اصلاح چند ایراد مالی بحرانی و آماده‌سازی آزمون‌های پذیرش اجرا شده است. بازنویسی معماری یا توسعه قابلیت‌های فازهای بعدی در دامنه این تحویل نیست.

## ۲) تغییرات پیاده‌سازی‌شده

### امنیت و چندمستاجری
- Tenant manager در نبود `agency_id` به‌صورت fail-closed عمل می‌کند؛ bypass فقط با reasonهای allowlistشده و در transaction مجاز است.
- migration جدید `settings.0004_enable_tenant_rls` برای فعال‌سازی PostgreSQL RLS روی مدل‌های tenant-scoped و مدل‌های فرزند دارای FK به رکورد tenant-scoped اضافه شده است.
- RLS برای عضویت آژانس، نقش‌ها، مجوزهای نقش و overrideهای عضویت به‌صورت اختصاصی تعریف شده است.
- `run_django` و middleware، `app.current_agency_id` و `app.current_user_id` را transaction-local تنظیم می‌کنند.
- روابط حساس در ایجاد/ویرایش مشتری، ملک، مذاکره، قرارداد، معامله، بازدید و اسناد با agency/branch/عضویت مقصد تطبیق داده می‌شوند.
- دسترسی مدیر شعبه به شعبه خودش محدود شده و مجوزهای all-agency ناخواسته در seeding حذف می‌شوند.

### کلیدها و رمزنگاری
- Production با کلید خالی، کوتاه، پیش‌فرض یا شناخته‌شده توسعه بالا نمی‌آید.
- کلید Django، JWT و رمزنگاری فیلدها مستقل هستند.
- رمزگشایی با کلیدهای fallback/legacy برای مهاجرت امن داده‌های قدیمی حفظ شده است.
- فرمان `rotate_encrypted_fields` برای چرخش ciphertextها با `--dry-run` اضافه شده است.

### فایل‌های خصوصی
- `MEDIA_ROOT` عمومی و `PRIVATE_MEDIA_ROOT` خصوصی جدا شده‌اند؛ مسیر خصوصی mount عمومی ندارد.
- ذخیره‌سازی local و S3 بر اساس prefix خصوصی/عمومی، root یا bucket مناسب را انتخاب می‌کند.
- مسیر فایل با containment واقعی کنترل می‌شود؛ `file_key` از ورودی ساخت سند حذف شده و کلید توسط سرور ساخته می‌شود.
- فایل خصوصی ملک از endpoint مجاز و audit‌شده ارائه می‌شود؛ فایل خصوصی سند و دارایی تور مجازی از مسیر عمومی static قابل دریافت نیست.
- فرمان‌های مهاجرت فایل‌های قدیمی:
  - `migrate_private_documents`
  - `migrate_private_property_media`
  - `migrate_private_virtual_tour_assets`
- برای کلیدهای قدیمی که prefix `private/` دارند اما در public root/bucket ذخیره شده‌اند، مسیر خواندن/حذف legacy-public نیز اضافه شده است.

### CRM و اسناد
- یادداشت خصوصی CRM در فهرست تعاملات فیلتر می‌شود.
- جزئیات مشتری، فعالیت‌ها، قراردادها، مذاکره‌ها، بازدیدها و اسناد بر اساس نقش، تخصیص و شعبه scope می‌شوند.
- اشتراک مشتری تاریخ انقضا را در مسیرهای view/edit رعایت می‌کند؛ ایجاد share به مجوز مستقل و عضویت فعال همان آژانس نیاز دارد.
- مجوزهای view/upload/edit/delete/download اسناد مستقل و در service layer کنترل می‌شوند.

### گزارش‌ها و matching
- داشبورد، مرکز عملیات و analytics بر اساس نقش/شعبه scope شده‌اند.
- داده خزانه، چک، حقوق و کمیسیون به نقش‌های مالی مجاز محدود شده است؛ مدیر شعبه خروجی مالی کل آژانس دریافت نمی‌کند.
- matching برای مشتری از `CustomerRequirement` واقعی استفاده می‌کند و ابتدا scope مشاهده ملک را اعمال می‌کند.
- تحلیل قیمت عمومی فقط ملک `PUBLISHED + PUBLIC_PORTAL` را در نظر می‌گیرد و حداقل ۵ نمونه در هر گروه لازم دارد.
- پرونده اعتبارسنجی ملک از `can_view_property` عبور می‌کند.

### SSRF، WebSocket و آپلود
- RSS fetch فقط HTTPS استاندارد را می‌پذیرد، مقصدهای private/loopback/link-local/metadata را رد می‌کند، DNS را بررسی می‌کند، اتصال را به IP اعتبارسنجی‌شده pin می‌کند و redirect را دنبال نمی‌کند.
- WebSocket از ticket کوتاه‌عمر، یک‌بارمصرف و متصل به session استفاده می‌کند؛ ticket در URL قرار نمی‌گیرد، replay و session revokeشده رد می‌شود و Origin بررسی می‌شود.
- خواندن UploadFile به chunkهای محدود و سقف قابل تنظیم `MAX_UPLOAD_FILE_BYTES` تغییر کرده است.

### مالی و گردش کار
- برگشت سند حسابداری در دوره بسته، در صورت وجود، به دوره باز جاری/بعدی همان آژانس منتقل می‌شود؛ سند معکوس در Trial Balance و General Ledger لحاظ می‌شود.
- محاسبه کمیسیون درصدها و پله‌های tiered را validate می‌کند و نسخه policy باید متعلق به همان آژانس معامله باشد.
- حقوق فقط سهم `FINANCE_APPROVED` در بازه دوره را وارد می‌کند؛ لغو دوره سهم‌ها را آزاد می‌کند، فیش‌ها را CANCELLED می‌کند و دوره پرداخت‌شده قابل لغو نیست.
- رزرو بازدید با lock ترتیبی منابع agent/property و اعتبارسنجی state انجام می‌شود.

### رابط کاربری و قرارداد API
- `use client` در صفحات گزارش‌شده در ابتدای فایل قرار دارد.
- WebSocket فرانت‌اند از ticket استفاده می‌کند.
- نقش‌های navigation با محدودیت شعبه/مالی هم‌راستا شده‌اند.
- runner تست واحد فرانت‌اند با Node test runner اضافه شده است.

## ۳) فایل‌ها و فرمان‌های عملیاتی جدید

- `backend/django_core/apps/settings/migrations/0004_enable_tenant_rls.py`
- `backend/django_core/apps/accounts/migrations/0004_websocketticket.py`
- `backend/django_core/apps/payroll/migrations/0002_payroll_cancellation_states.py`
- `backend/django_core/apps/settings/management/commands/rotate_encrypted_fields.py`
- `backend/django_core/apps/documents/management/commands/migrate_private_documents.py`
- `backend/django_core/apps/properties/management/commands/migrate_private_property_media.py`
- `backend/django_core/apps/virtual_tours/management/commands/migrate_private_virtual_tour_assets.py`
- `backend/fastapi_core/app/core/uploads.py`
- `backend/fastapi_core/tests/test_upload_limits.py`
- `frontend/scripts/run-unit-tests.mjs`

## ۴) وضعیت اعتبارسنجی

در این نوبت، بنا به درخواست کارفرما هیچ تستی اجرا نشده است. وضعیت زیر صرفاً سوابق ثبت‌شده در نسخه مبناست و نتیجه اجرای نسخه 0.1.15 محسوب نمی‌شود.

## ۴-الف) وضعیت اعتبارسنجی اجراشده در محیط تحویل

| بررسی | نتیجه |
|---|---|
| Python `compileall` روی backend | موفق |
| Parse نحوی تمام فایل‌های Python | موفق |
| FastAPI upload-limit tests | ۲ تست موفق |
| Frontend unit tests با transpile و Node test runner | ۱۲ تست Node موفق؛ typecheck کامل به‌دلیل نبود `node_modules/@types/node` تأیید نشد |
| اجرای تست‌های Django/ORM | اجرا نشد؛ `Django` و `pytest-django` در محیط تحویل نصب نبودند |
| اجرای migration روی PostgreSQL واقعی | اجرا نشد |
| Next.js production build | اجرا نشد؛ `node_modules` موجود نبود |
| آزمون دوآژانسی end-to-end، Redis/Celery، S3 و درگاه واقعی | اجرا نشد |

**نتیجه مهم:** کد از نظر syntax بررسی شده و تست‌های قابل اجرای محیط موفق‌اند؛ اما معیار خروج سند برای Phase 0 هنوز تأیید نشده است. این بسته یک release candidate است و تا عبور از گیت‌های بخش ۵ نباید به Production منتقل شود.

## ۵) گیت‌های اجباری پیش از Production

1. Backup کامل PostgreSQL و هر دو storage root/bucket.
2. اجرای migrationها روی staging PostgreSQL با کاربر migration/owner.
3. اتصال runtime با DB role مستقل که `NOBYPASSRLS` است و مالک جدول‌ها نیست.
4. اجرای dry-run و سپس migration واقعی اسناد، property media و virtual-tour assets.
5. اجرای dry-run و سپس چرخش کلیدهای رمزنگاری؛ نگه‌داشتن کلید قبلی در fallback تا تأیید کامل.
6. تکمیل T-SEC-01 تا T-SEC-10 با دو آژانس و نقش‌های متفاوت.
7. تکمیل T-FIN-01 تا T-FIN-05 و T-FLOW-01 تا T-FLOW-02.
8. اجرای `npm ci`, `npm test`, `npm run build` و `python manage.py check --deploy`.
9. تست پرداخت واقعی در staging؛ هرگونه Sandbox در Production باید رد شود.
10. تأیید نهایی backup/rollback توسط مسئول عملیات.

## ۶) محدودیت و مرزبندی

- هیچ تضمین «نبود مطلق باگ» ارائه نمی‌شود.
- اجرای تست‌هایی که به PostgreSQL، Redis، Celery، S3 و gateway واقعی نیاز دارند به محیط staging وابسته است.
- تغییرات Phase 1 تا Phase 9، از جمله CRM timeline کامل، Daily Work Hub، AI features جدید، client portal و Deal Room، عمداً در این نسخه توسعه داده نشده‌اند.
