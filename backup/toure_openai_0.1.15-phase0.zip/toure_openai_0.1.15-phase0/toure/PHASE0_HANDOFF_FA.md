# تحویل کد Phase 0 — نسخه 0.1.15

این بسته شامل کل سورس پروژه و تغییرات فاز صفر است. فایل‌های `.env` و `.env.example` دست‌کاری نشده‌اند و مقادیر نمونه فعلی به‌عنوان placeholder باقی می‌مانند؛ مقادیر واقعی را بعداً در محیط خودتان تنظیم کنید.

## اجرای تست‌ها در Windows PowerShell

از ریشه همین پوشه:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\check_phase0.ps1 -SkipDatabaseChecks
```

اجرای کامل با PostgreSQL و سرویس‌های آماده:

```powershell
.\check_phase0.ps1
```

مجموعه رگرسیون کل پروژه:

```powershell
.\check_project.ps1 -Mode Full -Strict
```

گزارش‌ها در `validation-reports/` تولید می‌شوند. تست‌ها در این تحویل اجرا نشده‌اند، چون طبق درخواست قرار است در محیط شما اجرا شوند.

## نکته عملیاتی

پیش از اجرای migrationهای RLS و انتقال فایل‌های قدیمی، از دیتابیس و storage نسخه پشتیبان بگیرید. اجرای dry-run فرمان‌های انتقال فایل در برنامه تست فاز صفر آمده است. این بسته را ابتدا روی staging اجرا کنید؛ برای Production تا زمانی که تست‌های پذیرش، migration و بازیابی backup موفق نشده‌اند تأیید نکنید.
