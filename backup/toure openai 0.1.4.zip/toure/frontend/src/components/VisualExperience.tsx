"use client";

import React, { useEffect } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { usePathname } from "next/navigation";

/** Global interaction and motion layer. Palette and light/dark mode remain untouched. */
export function VisualExperience({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const reduceMotion = useReducedMotion();

  useEffect(() => {
    const root = document.documentElement;
    const onPointerMove = (event: PointerEvent) => {
      if (event.pointerType === "touch") return;
      root.style.setProperty("--fx-pointer-x", `${event.clientX}px`);
      root.style.setProperty("--fx-pointer-y", `${event.clientY}px`);
    };
    window.addEventListener("pointermove", onPointerMove, { passive: true });

    if (reduceMotion) {
      root.dataset.motionPreference = "reduced";
      return () => {
        window.removeEventListener("pointermove", onPointerMove);
        delete root.dataset.motionPreference;
      };
    }

    root.dataset.motionPreference = "full";
    const selector = ".surface-card, [data-visual-surface='card'], main section, main article, [data-fx-reveal]";
    const observed = new WeakSet<Element>();
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.setAttribute("data-fx-visible", "true");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: "0px 0px -36px 0px" });

    const scan = (scope: ParentNode) => {
      scope.querySelectorAll(selector).forEach((element) => {
        if (observed.has(element)) return;
        observed.add(element);
        element.setAttribute("data-fx-reveal", "true");
        observer.observe(element);
      });
    };
    scan(document);
    const mutationObserver = new MutationObserver((records) => {
      records.forEach((record) => record.addedNodes.forEach((node) => {
        if (node instanceof HTMLElement) {
          if (node.matches(selector)) scan(node.parentElement || document);
          else scan(node);
        }
      }));
    });
    mutationObserver.observe(document.body, { childList: true, subtree: true });

    return () => {
      window.removeEventListener("pointermove", onPointerMove);
      observer.disconnect();
      mutationObserver.disconnect();
      delete root.dataset.motionPreference;
    };
  }, [pathname, reduceMotion]);

  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.div
        key={pathname}
        className="visual-route-layer"
        initial={reduceMotion ? false : { opacity: 0, y: 9, filter: "blur(5px)" }}
        animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
        exit={reduceMotion ? undefined : { opacity: 0, y: -5, filter: "blur(3px)" }}
        transition={{ duration: reduceMotion ? 0 : 0.34, ease: [0.22, 1, 0.36, 1] }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}
