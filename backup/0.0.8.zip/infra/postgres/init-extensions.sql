-- Enable required PostgreSQL extensions for Enterprise Real Estate Platform
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
-- PostGIS is optional in local minimal setups; enable when PostGIS image is used
-- CREATE EXTENSION IF NOT EXISTS "postgis";
