# سند معماری قطعی و مرزبندی مسئولیت‌های پلتفرم سازمانی «بنیان ملک»

**نسخه:** 2.0 (معماری یکپارچه Django Core + FastAPI Web API — بدون DRF)  
**وضعیت:** فعال و عملیاتی در فاز ۱

---

## ۱. ساختار قطعی Monorepo و Backend Core

```text
├── backend/
│   ├── django_core/          # تنها هسته منطق تجاری، ORM، Migration، Multi-Tenancy و حسابداری
│   │   ├── config/           # تنظیمات پایه، توسعه، تست، تولید، WSGI/ASGI و Celery
│   │   ├── apps/             # ماژول‌های ۲۴+ گانه دامنه املاک، CRM، مالی، حقوق و پورتال
│   │   ├── core/             # ابزارهای بنیادین Tenant، RBAC، رمزنگاری PII و بومی‌سازی
│   │   ├── services/         # نمای سرویس‌های دامنه و ممیزی (Audit)
│   │   ├── common/           # استثنائات دامنه، مبدل تاریخ شمسی/میلادی و ریال/تومان
│   │   ├── integrations/     # آداپتورهای درگاه پرداخت، پیامک، نقشه و ذخیره‌سازی
│   │   └── tests/            # تست‌های هسته Django و قوانین تجاری/مالی
│   └── fastapi/              # تنها لایه Web API عمومی و سازمانی (/api/v1/*)
│       ├── app/              # اپلیکیشن FastAPI، راه‌اندازی django.setup() و lifespan
│       ├── api/              # روترهای نسخه‌بندی‌شده /api/v1/*
│       ├── dependencies/     # احراز هویت PyJWT، UserSession و تزریق کانتکست Tenant
│       ├── schemas/          # قراردادهای ورودی/خروجی Pydantic v2
│       ├── middleware/       # Request ID، تایمینگ، هدرهای امنیتی و مدیریت خطا
│       ├── services/         # سرویس‌های ارکستراسیون و تطبیق
│       ├── main.py           # نقطه ورود سرور FastAPI (uvicorn main:app)
│       └── tests/            # تست‌های یکپارچه FastAPI روی Django ORM
└── frontend/                 # Next.js App Router + React + TypeScript + Tailwind CSS
```

### اصول قطعی معماری Backend
1. **ممنوعیت مطلق Django REST Framework (DRF):** هیچ وابستگی به `rest_framework`، Serializer، ViewSet یا Router DRF در پروژه وجود ندارد و نخواهد داشت.
2. **Django Core به‌عنوان Single Source of Truth:** تمام مدل‌ها، روابط دیتابیس، Migrationها، Multi-Tenancy (`TenantScopedManager`)، منطق مالی/حسابداری دوبل (`Decimal` و `@transaction.atomic`) و Audit Log منحصراً در `backend/django_core` قرار دارند.
3. **FastAPI به‌عنوان تنها لایه Web API:** تمام درخواست‌های Frontend منحصراً به `/api/v1/*` در FastAPI ارسال می‌شوند. FastAPI در زمان راه‌اندازی (`lifespan`) هسته Django را از طریق `django.setup()` بارگذاری کرده و عملیات همگام ORM و سرویس‌های Django را از طریق `run_in_threadpool` همراه با `close_old_connections()` فراخوانی می‌کند (بدون SQLAlchemy یا دیتابیس موازی).
4. **احراز هویت و امنیت یکپارچه:** صدور و چرخش JWT با `PyJWT` روی مدل‌های `User` و `UserSession` در Django انجام می‌شود و هش رمز عبور از `django.contrib.auth.hashers` استفاده می‌کند.

---

## ۲. بومی‌سازی، Multi-Tenancy و آداپتورها
- تاریخ‌ها در دیتابیس به‌صورت UTC (`TIMESTAMPTZ`) ذخیره و از طریق `CalendarAdapter` (شمسی/میلادی) نمایش داده می‌شوند.
- مبالغ مالی منحصراً با `Decimal` همراه با `currency_code` (`IRT`/`IRR` با ضریب صریح `1 IRT = 10 IRR`) ذخیره می‌شوند.
- جداسازی داده‌های هر آژانس (`Tenant Isolation`) در `TenantScopedManager` و سرویس‌های Django + Dependencyهای FastAPI با ۱۰ سیاست دسترسی در `AgencyAccessPolicy` اعمال می‌شود.
- سرویس‌های خارجی (درگاه پرداخت، پیامک، نقشه، پوش نوتیفیکیشن، انالیتیکس) بر پایه Adapter Pattern و آماده محیط تست/Sandbox هستند.

---

## ۳. پایگاه داده PostgreSQL و سیدر کامل (Seed All)

- **اتصال اصلی دیتابیس:** از طریق متغیر محیطی `DATABASE_URL` (شامل پشتیبانی از پارامترهایی مانند `?sslmode=require`) به PostgreSQL متصل می‌شود. در محیط پیش‌نمایش که سرویس PostgreSQL خارجی راه‌اندازی نشده باشد، اسکریپت `scripts/dev-monorepo.sh` به‌صورت خودکار و ایمن به دیتابیس سندباکس محلی سوییچ می‌کند (مگر آنکه `FORCE_POSTGRESQL=1` تنظیم شده باشد).
- **سیدر جامع تمام جداول (Django ORM):** دستور `python manage.py seed_all` هر **۹۴ مدل در ۲۹ اپلیکیشن** پلتفرم را به‌صورت Idempotent مقداردهی و راستی‌آزمایی می‌کند.
- **اسکریپت مستقل PostgreSQL SQL:** فایل `scripts/seed_all.sql` حاوی دستورهای `INSERT ... ON CONFLICT DO NOTHING` به ترتیب صحیح کلیدهای خارجی برای اجرای مستقیم روی PostgreSQL است:
  ```bash
  psql "$DATABASE_URL" -f scripts/seed_all.sql
  ```
- **حساب‌های کاربری ۷ نقش فعال:**
  - مدیر کل پلتفرم (`09120000001` / `Admin@12345`)
  - مدیر آژانس پارس نگین (`09121111111` / `Manager@12345`)
  - مدیر آژانس آریا (`09123333333` / `Manager@12345`)
  - مدیر شعبه نیاوران (`09125555555` / `Branch@12345`)
  - مشاور املاک (`09122222222` / `Agent@12345`)
  - حسابدار آژانس (`09126666666` / `Accountant@12345`)
  - مشتری / متقاضی (`09124444444` / `Customer@12345`)

